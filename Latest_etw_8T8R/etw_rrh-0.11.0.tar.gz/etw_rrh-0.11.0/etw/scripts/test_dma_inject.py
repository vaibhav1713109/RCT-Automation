import etw.lib
import target
from etwmodel import EtwModel
from etw.lib.etwproxy import IpcLink
from etw.lib.etwproxy import EtwProxy
from dmachannel import DmaChannel
from testsignal import TestSignal
import sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        # Connect to target
        try:
            ipcLink.connect()
        except Exception as e:
            print(f'error: could not connect to target: {e}')
            sys.exit(1)
    etwProxy = EtwProxy(ipcLink=ipcLink)

    if argumentList is None:
        argumentList = sys.argv[1:]
        
    DMA_BASE_ADDRESS = 0x00A0120000
    
    # Check file name
    try:
        filename = argumentList[0]
        try:
            print('Reading signal file...')
            test_signal = TestSignal(signal_file = filename)
        except Exception as e:
            print(f'error: could not read signal file: {e}')
            sys.exit(1)
    except Exception as e:
        print(f'No signal file provided, using dummy test signal')
        # Create dummy test signal
        #   i: positive ramp
        #   q: negative ramp
        i = []
        q = []
        for n in range(8192):
            i.append(n)
            q.append(-n)
        test_signal = TestSignal()
        test_signal.from_i_q_c(i, q)
    
    # Create model and append dma instance
    model = EtwModel(proxy=etwProxy)
    dma_name = "dma-0"
    model.model['devices'][dma_name] = {'name' : dma_name, 'type' : "axi_dma", 'base' : DMA_BASE_ADDRESS }
    dma_regs, _ = model.getDeviceRegisters(model.model['devices'][dma_name])
    model.model['devices'][dma_name]['registers'] = dma_regs
   
    # Free all DDR buffers
    model.proxy.freeAll()
    
    # allocate DDR memory buffer and store signal vector
    try:
        print('Converting test signal...')
        data = test_signal.to_bytes()
        print(f'Signal size: {int(len(data) / 4)} samples')
        vector_size = len(data)
        vector_ptr = model.proxy.allocBuf(vector_size)
        print(f'DDR Address: 0x{vector_ptr:08X}')
        print('Writing test signal...')
        model.proxy.writeToBuf(vector_ptr, data)
    except Exception as e:
        print(f'error: could not allocate and write to DDR buffer: {e}')
        sys.exit(1)
    
    # Turn on logging
    model.log_write = True
    
    # Create DMA proxy
    dma = DmaChannel(model, dma_name)
    dma.reset()
    
    # Transfer data from DDR
    print("Start transfer...")
    dma.transferFromDDR(vector_ptr, vector_size, cyclic=True)
    
    # Sleep for a while
    print("Sleeping...")
    time.sleep(1)
    
    # Dump DMA registers
    print("Register dump (mm2s)...")
    dma_regs = dma.readAllRegisters()
    for reg in dma_regs:
        if not "mm2s" in reg:
            continue
        for field in dma_regs[reg]:
            val = dma_regs[reg][field]
            print(f'{reg}.{field} = {val}')
    
if __name__=="__main__":
    main()
