#!/usr/bin/python

# Example usage (refer to help and run() function).
# python3 set_rfdc_mm.py
# python3 set_rfdc_mm.py -d
# python3 set_rfdc_mm.py -f 4950
# python3 set_rfdc_mm.py -f 4950,4950,4950,4950,4950,4950,4750.08,5149.02,4950,4950,4950,4950,4950,4950,4950,4950
# python3 set_rfdc_mm.py -f 4950 -n
# python3 set_rfdc_mm.py -f 4950 -d

import getopt, os, sys, time

import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rfdc_pb2
from etw.lib import rfdc

ipcLink = IpcLink(target.ip_address, target.port)
rfdcProxy = rfdc.RfdcProxy(ipcLink)
rfdcProxy.connect()
rfdc.debug_on = 0

XRFDC_EVNT_SRC_IMMEDIATE = int('0x00000000', 16)
XRFDC_EVNT_SRC_SLICE     = int('0x00000001', 16)
XRFDC_EVNT_SRC_TILE      = int('0x00000002', 16)
XRFDC_EVNT_SRC_SYSREF    = int('0x00000003', 16)
XRFDC_EVNT_SRC_MARKER    = int('0x00000004', 16)
XRFDC_EVNT_SRC_PL        = int('0x00000005', 16)

XRFDC_EVENT_MIXER    = int('0x00000001', 16)
XRFDC_EVENT_CRSE_DLY = int('0x00000002', 16)
XRFDC_EVENT_QMC      = int('0x00000004', 16)

XRFDC_MIXER_TYPE_OFF      = int('0x0', 16)
XRFDC_MIXER_TYPE_COARSE   = int('0x1', 16)
XRFDC_MIXER_TYPE_FINE     = int('0x2', 16)
XRFDC_MIXER_TYPE_DISABLED = int('0x3', 16)

XRFDC_COARSE_MIX_OFF                     = int('0x0' , 16)
XRFDC_COARSE_MIX_SAMPLE_FREQ_BY_TWO      = int('0x2' , 16)
XRFDC_COARSE_MIX_SAMPLE_FREQ_BY_FOUR     = int('0x4' , 16)
XRFDC_COARSE_MIX_MIN_SAMPLE_FREQ_BY_FOUR = int('0x8' , 16)
XRFDC_COARSE_MIX_BYPASS                  = int('0x10', 16)

XRFDC_MIXER_MODE_OFF = int('0x0', 16)
XRFDC_MIXER_MODE_C2C = int('0x1', 16)
XRFDC_MIXER_MODE_C2R = int('0x2', 16)
XRFDC_MIXER_MODE_R2C = int('0x3', 16)
XRFDC_MIXER_MODE_R2R = int('0x4', 16)

XRFDC_MIXER_SCALE_AUTO = int('0x0', 16)
XRFDC_MIXER_SCALE_1P0  = int('0x1', 16)
XRFDC_MIXER_SCALE_0P7  = int('0x2', 16)

XRFDC_ODD_NYQUIST_ZONE  = int('0x1', 16)
XRFDC_EVEN_NYQUIST_ZONE = int('0x2', 16)

FS_DAC = 7864.32 # MHz
FS_ADC = 3932.16 # MHz

N_DAC_ADC_TILES     = 4
N_DAC_DUCS_PER_TILE = 4
N_ADCS_PER_TILE     = 2
N_DAC_DUCS          = N_DAC_ADC_TILES*N_DAC_DUCS_PER_TILE
N_ADCS              = N_DAC_ADC_TILES*N_ADCS_PER_TILE

def run(fc):
    fcDac = fc
    fcAdc = [0.0]*N_ADCS
    for i in range(0, len(fc), 2): # 4 DAC DUCs per tile, 2 ADCs per tile
        fcAdc[int(i/2)] = (fc[i]+fc[i+1])/2 # Assign average center freqs ((even+odd DAC)/2) to ADCs.
    try:
        ######################################################################
        # MIXER + NYQUIST ZONE SETTINGS ######################################
        ######################################################################
        for i in range (0, N_DAC_ADC_TILES):
            block_type = rfdc.BlockType_DAC
            for j in range (0, N_DAC_DUCS_PER_TILE):
                fNco = (fcDac[i*N_DAC_DUCS_PER_TILE+j]-FS_DAC) if j%2 else -(fcDac[i*N_DAC_DUCS_PER_TILE+j]-FS_DAC)
                print('= DAC TILE#' + str(i) + ' BLOCK#' + str(j) + ' ================')
                print('1.1 Get current mixer settings')
                settings = rfdcProxy.getMixerSettings(block_type = block_type,
                                                      device_id  = 0         ,
                                                      tile_id    = i         ,
                                                      block_id   = j         )
                print(settings)
                print('1.2 Get current Nyquist zone settings')
                zone = rfdcProxy.getNyquistZone(block_type = block_type,
                                                tile_id    = i         ,
                                                block_id   = j         )
                print(zone)
                print('2.1 Set new mixer settings')
                rfdcProxy.setMixerSettings(block_type       = block_type            ,
                                           tile_id          = i                     ,
                                           block_id         = j                     ,
                                           freq             = fNco                  ,
                                           phase_offs       = 0                     ,
                                           event_source     = XRFDC_EVNT_SRC_TILE   ,
                                           mixer_type       = XRFDC_MIXER_TYPE_FINE ,
                                           coarse_mix_freq  = XRFDC_COARSE_MIX_OFF  ,
                                           mixer_mode       = XRFDC_MIXER_MODE_C2R  ,
                                           fine_mixer_scale = XRFDC_MIXER_SCALE_AUTO)
                print('2.2 Set new Nyquist zone settings')
                if not (j % 2):
                    rfdcProxy.setNyquistZone(block_type = block_type             ,
                                             tile_id    = i                      ,
                                             block_id   = j                      ,
                                             zone       = XRFDC_EVEN_NYQUIST_ZONE)
                else:
                    print('No settings for this block.')
                print('3.1 Get new mixer settings')
                settings = rfdcProxy.getMixerSettings(block_type = block_type,
                                                      device_id  = 0         ,
                                                      tile_id    = i         ,
                                                      block_id   = j         )
                print(settings)
                print('3.2 Get new Nyquist zone settings')
                zone = rfdcProxy.getNyquistZone(block_type = block_type,
                                                tile_id    = i         ,
                                                block_id   = j         )
                print(zone)
            block_type = rfdc.BlockType_ADC
            for k in range (0, N_ADCS_PER_TILE):
                fNco = FS_ADC-fcAdc[i*N_ADCS_PER_TILE+k]
                print('= ADC TILE#' + str(i) + ' BLOCK#' + str(k) + ' ================')
                print('1.1 Get current mixer settings')
                settings = rfdcProxy.getMixerSettings(block_type = block_type,
                                                      device_id  = 0         ,
                                                      tile_id    = i         ,
                                                      block_id   = k         )
                print(settings)
                print('1.2 Get current Nyquist zone settings')
                zone = rfdcProxy.getNyquistZone(block_type = block_type,
                                                tile_id    = i         ,
                                                block_id   = k         )
                print(zone)
                print('2.1 Set new mixer settings')
                rfdcProxy.setMixerSettings(block_type       = block_type            ,
                                           tile_id          = i                     ,
                                           block_id         = k                     ,
                                           freq             = fNco                  ,
                                           phase_offs       = 0                     ,
                                           event_source     = XRFDC_EVNT_SRC_TILE   ,
                                           mixer_type       = XRFDC_MIXER_TYPE_FINE ,
                                           coarse_mix_freq  = XRFDC_COARSE_MIX_OFF  ,
                                           mixer_mode       = XRFDC_MIXER_MODE_R2C  ,
                                           fine_mixer_scale = XRFDC_MIXER_SCALE_AUTO)
                print('2.2 Set new Nyquist zone settings')
                rfdcProxy.setNyquistZone(block_type = block_type            ,
                                         tile_id    = i                     ,
                                         block_id   = k                     ,
                                         zone       = XRFDC_ODD_NYQUIST_ZONE)
                print('3.1 Get new mixer settings')
                settings = rfdcProxy.getMixerSettings(block_type = block_type,
                                                      device_id  = 0         ,
                                                      tile_id    = i         ,
                                                      block_id   = k         )
                print(settings)
                print('3.2 Get new Nyquist zone settings')
                zone = rfdcProxy.getNyquistZone(block_type = block_type,
                                                tile_id    = i         ,
                                                block_id   = k         )
                print(zone)

        for i in range (0, 4):
            block_type = rfdc.BlockType_DAC
            for j in range (0, 4):
                print('= DAC TILE#' + str(i) + ' BLOCK#' + str(j) + ' ================')
                print('1.1 Issue mixer event')
                rfdcProxy.updateEvent(block_type = block_type        ,
                                      tile_id    = i                 ,
                                      block_id   = j                 ,
                                      event      = XRFDC_EVENT_MIXER )
            block_type = rfdc.BlockType_ADC
            for k in range (0, 2):
                print('= ADC TILE#' + str(i) + ' BLOCK#' + str(k) + ' ================')
                print('1.2 Issue mixer event')
                rfdcProxy.updateEvent(block_type = block_type       ,
                                      tile_id    = i                ,
                                      block_id   = k                ,
                                      event      = XRFDC_EVENT_MIXER)
        print('PASSED!')

    except Exception as e:
        print('FAILED!')
        print(e.message)

def main():
    # Get and parse CMD arguments.
    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hdnf:', ['help', 'debug', 'fc='])
    except getopt.error as err:
        # output error, and return with an error code
        print (str(err))
        sys.exit(2)

    # Default values.
    fc = [4950.00]*N_DAC_DUCS
    # Override default values if passed via CMD arguments.
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('==============================')
            print ('Help Menu')
            print ('------------------------------')
            print ('-h, --help  : option list')
            print ('-d, --debug : debug')
            print ('-f, --fc    : center frequency')
            print ('==============================')
            sys.exit(2)
        elif currentArgument in ('-d', '--debug'):
            rfdc.debug_on = 1
        elif currentArgument in ('-f', '--fc'):
            fcs = currentValue.split(',')
            if len(fcs) == 1:
                for i in range(N_DAC_DUCS):
                    fc[i] = float(fcs[0])
            else:
                nDacDucsProvided = len(fcs)
                if not(nDacDucsProvided == N_DAC_DUCS):
                    print('Not all ' + str(N_DAC_DUCS) + ' DAC DUC values entered! Only ' + str(nDacDucsProvided) + ' provided!')
                    sys.exit(2)
                for i in range(N_DAC_DUCS):
                    fc[i] = float(fcs[i])

    # Run program.
    run(fc)

    return

# Call main()
if __name__=="__main__":
    main()
