import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'htrp:s:',
                                          ['help', 'tx', 'rx',
                                           'port=', 'subFrame='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    measTxPower = 0
    measRxPower = 0
    subFrameMode = 0   # 0: Not specify subframe number, 1: specify subframe number
    subFrameNum = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-t, --tx             : measure TX & ORx power for a specific subframe (default 0), ')
            print ('                       require argument -p, optional argument -s')
            print ('-r, --rx             : measure RX power for a specific subframe (default 0), ')
            print ('                       require argument -p, optional argument -s')
            print ('------ parameter specification ------')
            print ('-p, --port           : specify port number for measurement')
            print ('-s, --subFrame       : specify subframe number for measurement, default is 0')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-t', '--tx'):
            measTxPower = 1
        elif currentArgument in ('-r', '--rx'):
            measRxPower = 1
        elif currentArgument in ('-p', '--port'):
            port = int(currentValue)
        elif currentArgument in ('-s', '--subFrame'):
            subFrameMode = 1
            subFrameNum = int(currentValue)

    try:
        if measTxPower == 1:
            print(f'Performing TX & ORx power measurement for port {port} on subframe {subFrameNum}.')
            rrhDfeProxy.performTxPowerMeasurement(port, subFrameMode, subFrameNum)
            rsp = rrhDfeProxy.getTxAntDigPowerDbfs()
            print(f'TX Antenna Power for port {port} is {rsp.antPwrDbfs:.2f} dBFS.')
            rsp = rrhDfeProxy.getOrxDigPowerDbfs()
            print(f'ORx Power for port {port} is {rsp.pwrDbfs:.2f} dBFS.\n')
        elif measRxPower == 1:
            print(f'Performing RX power measurement for port {port} on subframe {subFrameNum}.')
            rrhDfeProxy.performRxPowerMeasurement(port, subFrameMode, subFrameNum)
            rsp = rrhDfeProxy.getRxAntDigPowerDbfs()
            print(f'RX Antenna Power for port {port} is {rsp.antPwrDbfs:.2f} dBFS.\n')
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
