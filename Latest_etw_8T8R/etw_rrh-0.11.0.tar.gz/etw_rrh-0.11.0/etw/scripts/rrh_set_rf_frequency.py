import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList= None):         
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'htrof:',
                                          ['help', 'tx', 'rx', 'orx', 'centerFreqKhz='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    set_tx_freq = 0
    set_rx_freq = 0
    set_orx_freq = 0

    if target.RRH_HW_VERSION == '0':
        dacAdcRefClock = 1       # 245.76MHz for ZCU670
    elif target.RRH_HW_VERSION == '1':
        dacAdcRefClock = 2       # 491.52MHz for VVDN P0 (TRx)
    elif target.RRH_HW_VERSION == '2':
        dacAdcRefClock = 2       # 491.52MHz for VVDN E1

    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-t, --tx             : set TX RF center frequency, require arguments -f')
            print ('-r, --rx             : set RX RF center frequency, require arguments -f')
            print ('-o, --orx            : set ORX RF center frequency, require arguments -f')
            print ('------ parameter specification ------')
            print ('-f, --centerFreqKhz  : specify center frequency (in kHz)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-t', '--tx'):
            set_tx_freq = 1
        elif currentArgument in ('-r', '--rx'):
            set_rx_freq = 1
        elif currentArgument in ('-o', '--orx'):
            set_orx_freq = 1
        elif currentArgument in ('-f', '--centerFreqKhz'):
            centerFreqKhz = int(currentValue)

    try:
        if set_tx_freq == 1:
            print(f'Setting TX center frequency {centerFreqKhz/1000000}GHz to all {rrh_dfe.NUM_OF_TX_PORTS} TX ports.\n')
            for port in range(rrh_dfe.NUM_OF_TX_PORTS):
                rrhDfeProxy.rfControlSetTxCenterFreqKhz(port, centerFreqKhz, dacAdcRefClock)
        elif set_rx_freq == 1:
            print(f'Setting RX center frequency {centerFreqKhz/1000000}GHz to all {rrh_dfe.NUM_OF_RX_PORTS} RX ports.\n')
            for port in range(rrh_dfe.NUM_OF_RX_PORTS):
                rrhDfeProxy.rfControlSetRxCenterFreqKhz(port, centerFreqKhz, dacAdcRefClock)
        elif set_orx_freq == 1:
            print(f'Setting ORX center frequency {centerFreqKhz/1000000}GHz to all {rrh_dfe.NUM_OF_ORX_PORTS} ORX ports.\n')
            for port in range(rrh_dfe.NUM_OF_ORX_PORTS):
                rrhDfeProxy.rfControlSetORxCenterFreqKhz(port, centerFreqKhz, dacAdcRefClock)
        else:
            print('Either TX, RX or ORX must be specified.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
