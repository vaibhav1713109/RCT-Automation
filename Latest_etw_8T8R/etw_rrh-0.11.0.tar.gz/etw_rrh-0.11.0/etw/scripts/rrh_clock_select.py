import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList= None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hc:',
                                          ['help', 'clockSource='])
    except getopt.error as err:
        print(str(err))
        sys.exit(2)

    CLOCK_SOURCE = ['Clk104 - 156.25 MHz from 10G Ethernet',
                    'Clk104 - 390.625 MHz from 25G Ethernet',
                    'Clk104 - External 10 MHz',
                    'Clk104 - Internal 10.8 MHz TCXO',
                    'Si5381 - External 10 MHz',
                    'Si5518 - External 10 MHz',
                    'Si5518 - Pre-programmed for PTP']
        
    setClockSource = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-c, --clockSource    : select clock source')
            print ('                     : 0 - Clk104 - 156.25 MHz from 10G Ethernet')
            print ('                     : 1 - Clk104 - 390.625 MHz from 25G Ethernet')
            print ('                     : 2 - Clk104 - External 10 MHz')
            print ('                     : 3 - Clk104 - Internal 10.8 MHz TCXO')
            print ('                     : 4 - Si5381 - External 10 MHz')
            print ('                     : 5 - Si5518 - External 10 MHz')
            print ('                     : 6 - Si5518 - Pre-programmed for PTP')  
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-c', '--clockSource'):
            setClockSource = 1
            clockSource = int(currentValue)
            
    try:
        if setClockSource == 1:
            print(f'Setting {CLOCK_SOURCE[clockSource]} as the clock source for the system.\n')
            rrhDfeProxy.rfClockSelect(clockSource)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
