import pandas as pd
import sys

# Read input file
try:
    filename = sys.argv[1]
    try:
        infile = open(filename, "rb")
        print('Reading signal file...')
        data = bytearray(infile.read())
    except Exception as e:
        print(f'error: could not read signal file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no signal file provided')
    sys.exit(1)

# Open output file
try:
    filename = sys.argv[2]
    try:
        outfile = open(filename, "w")
    except Exception as e:
        print(f'error: could not open output file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no output file provided')
    sys.exit(1)

def to_s16(v):
    return (v & 0x7fff) - (v & 0x8000)
    
print('Converting...')
len = int(len(data) / 8)
for i in range(len):
    i0 = to_s16(data[i*8 + 0] + (data[i*8 + 1] << 8));
    q0 = to_s16(data[i*8 + 2] + (data[i*8 + 3] << 8));
    i1 = to_s16(data[i*8 + 4] + (data[i*8 + 5] << 8));
    q1 = to_s16(data[i*8 + 6] + (data[i*8 + 7] << 8));

    print(f'{i0} {q0}', file=outfile)
    print(f'{i1} {q1}', file=outfile)

