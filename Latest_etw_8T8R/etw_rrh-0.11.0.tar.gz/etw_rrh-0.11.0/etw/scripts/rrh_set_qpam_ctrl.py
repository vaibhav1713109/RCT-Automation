import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hie:d:v:tms:guxcrzap:q:o:f:b:',
                                          ['help', 'init', 'enable=', 'disable=', 'paVdd=',
                                           'tddMode', 'orxMux', 'setPaBias=', 'getPaBias',
                                           'paSetOn', 'paSetOff', 'getPaCurrent',
                                           'readTemp', 'getStepSize', 'paMonAvail', 'port=',
                                           'qpamId=', 'opMode=', 'fwdRev=', 'biasVolt='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    qpamCtrlInit = 0
    enableQpam = 0
    disableQpam = 0
    setPaVdd = 0
    setTddMode = 0
    setORxMux = 0
    setPaBiasDefault = 0
    setPaBias = 0
    getPaBias = 0
    paSetOn = 0
    paSetOff = 0
    getPaCurrent = 0
    readTemp = 0
    getStepSize = 0
    checkPaMonAvail = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help         : option list')
            print ('-i, --init         : initialize QPAM MAX Chips, require argument -q')
            print ('-e, --enable       : enable QPAM port (choose from 1-Tx, 2-Rx), require argument -p')
            print ('-d, --disable      : disable QPAM port (choose from 1-Tx, 2-Rx), require argument -p')
            print ('-v, --paVdd        : configure PA VDD (choose from 0-disable. 1-enable), require argument -q')
            print ('-t, --tddMode      : set TDD mode, require arguments -q, -o')
            print ('-m, --orxMux       : set ORx Mux, require arguments -p, -f')
            print ('-s, --setPaBias    : set PA bias voltage (choose from 0-default and 1-specific)')
            print ('                   : default option sets -8V to all chips/ports of a QPAM, requires arguments -q')
            print ('                   : specific option requires arguments -p, -b')
            print ('-g, --getPaBias    : get PA bias voltage, require arguments -p')
            print ('-u, --paSetOn      : set PA ON for specified port, require argument -p')
            print ('-x, --paSetOff     : set PA OFF for all ports')
            print ('-c, --getPaCurrent : get PA current, require argument -p')
            print ('-r, --readTemp     : read temperature from TX port, require argument -p')
            print ('-z, --getStepSize  : get PA bias step size')
            print ('-a, --paMonAvail   : check PA current monitor availability')
            print ('------ parameter specification ------')
            print ('-p, --port         : specify port number, valid range [0,7]')
            print ('-q, --qpamId       : specify QPAM ID (0 or 1)')
            print ('-o, --opMode       : specify opMode (0-TDD, 1-Tx Only, 2-Rx Only)')
            print ('-f, --fwdRev       : specify DPD feedback forward/reverse power sniff select (0-OBS, 1-VSWR)')
            print ('-b, --biasVolt     : specify bias voltage set in format of 7 float values in a string,')
            print ('                   : e.g. \'1.0 2.0 3.0 4.0 5.0 6.0 7.0\' to represent \'preDriver, driverMainAmplifier,')
            print ('                   : driverPeakingAmplifier, finalMainAmplifier1, finalMainAmplifier2,')
            print ('                   : finalPeakingAmplifier1, finalPeakingAmplifier2\' in order.')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-i', '--init'):
            qpamCtrlInit = 1
        elif currentArgument in ('-e', '--enable'):
            enableQpam = 1
            enableSel = int(currentValue)
        elif currentArgument in ('-d', '--disable'):
            disableQpam = 1
            disableSel = int(currentValue)
        elif currentArgument in ('-v', '--paVdd'):
            setPaVdd = 1
            paVddEnable = int(currentValue)
        elif currentArgument in ('-t', '--tddMode'):
            setTddMode = 1
        elif currentArgument in ('-m', '--orxMux'):
            setORxMux = 1
        elif currentArgument in ('-s', '--setPaBias'):
            if int(currentValue) == 0:
                setPaBiasDefault = 1
            elif int(currentValue) == 1:
                setPaBias = 1
            else:
                print('Invalid option. -h for help.')
                sys.exit(2)
        elif currentArgument in ('-g', '--getPaBias'):
            getPaBias = 1
        elif currentArgument in ('-u', '--paSetOn'):
            paSetOn = 1
        elif currentArgument in ('-x', '--paSetOff'):
            paSetOff = 1
        elif currentArgument in ('-c', '--getPaCurrent'):
            getPaCurrent = 1
        elif currentArgument in ('-r', '--readTemp'):
            readTemp = 1
        elif currentArgument in ('-z', '--getStepSize'):
            getStepSize = 1
        elif currentArgument in ('-a', '--paMonAvail'):
            checkPaMonAvail = 1
        elif currentArgument in ('-p', '--port'):
            port = int(currentValue)
        elif currentArgument in ('-q', '--qpamId'):
            qpamId = int(currentValue)
        elif currentArgument in ('-o', '--opMode'):
            opMode = int(currentValue)
        elif currentArgument in ('-f', '--fwdRev'):
            fwdRev = int(currentValue)
        elif currentArgument in ('-b', '--biasVolt'):
            preDriver, driverMainAmplifier, driverPeakingAmplifier, \
            finalMainAmplifier1, finalMainAmplifier2, finalPeakingAmplifier1, \
            finalPeakingAmplifier2 = currentValue.split()

    try:
        if qpamCtrlInit == 1:
            print(f'Initializing QPAM MAX Chips on QPAM with ID={qpamId}.\n')
            rrhDfeProxy.mavu8t8rQpamMaxChipControlInit(qpamId)
        elif enableQpam == 1:
            if enableSel == 1:
                print(f'Enabling QPAM Tx port {port}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetTxKey(port, 1)
            elif enableSel == 2:
                print(f'Enabling QPAM Rx port {port}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetRxKey(port, 1)
            else:
                print('Invalid option. -h for help.')
        elif disableQpam == 1:
            if disableSel == 1:
                print(f'Disabling QPAM Tx port {port}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetTxKey(port, 0)
            elif disableSel == 2:
                print(f'Disabling QPAM Rx port {port}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetRxKey(port, 0)
            else:
                print('Invalid option. -h for help.')
        elif setPaVdd == 1:
            if paVddEnable == 0:
                print(f'Disabling QPAM PA VDD on QPAM with ID={qpamId}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetPaVdd(qpamId, 0)
            elif paVddEnable == 1:
                print(f'Enabling QPAM PA VDD on QPAM with ID={qpamId}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetPaVdd(qpamId, 1)
            else:
                print('Invalid option. -h for help.')
        elif setTddMode == 1:
            if opMode == 0:
                print(f'Setting QPAM to TDD mode on QPAM with ID={qpamId}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetTddMode(qpamId, opMode)
            elif opMode == 1:
                print(f'Setting QPAM to Tx Only mode on QPAM with ID={qpamId}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetTddMode(qpamId, opMode)
            elif opMode == 2:
                print(f'Setting QPAM to Rx Only mode on QPAM with ID={qpamId}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetTddMode(qpamId, opMode)
            else:
                print('Invalid option. -h for help.')
        elif setORxMux == 1:
            rsp = rrhDfeProxy.mavu8t8rTrxControlGetSwitchManager()
            if rsp.managerSelect == 0:
                print(f'Switch Manager is set to PL. ORx Mux cannot be controlled.\n')
            elif rsp.managerSelect == 1:
                fwdRevString = 'OBS' if fwdRev == 0 else 'VSWR'
                print(f'Switch Manager is set to PS. Setting ORx Mux to {fwdRevString} on port {port}.\n')
                rrhDfeProxy.mavu8t8rQpamControlSetORxMuxCtrl(port, fwdRev)
            else:
                print('Invalid selected manager option.')
        elif setPaBiasDefault == 1:
            if qpamId == 0:
                print(f'Setting default bias voltage (-8V) to all chips/ports of a QPAM (ID={qpamId}).\n')
                rrhDfeProxy.mavu8t8rQpam1SetDefaultBiasVoltage()
            elif qpamId == 1:
                print(f'Setting default bias voltage (-8V) to all chips/ports of a QPAM (ID={qpamId}).\n')
                rrhDfeProxy.mavu8t8rQpam2SetDefaultBiasVoltage()
            else:
                print('Invalid value for QPAM ID. -h for help.')
        elif setPaBias == 1:
            print(f'Setting PA bias voltage to port {port}.')
            print(f'PreDriver={preDriver}V,  DriverMainAmplifier={driverMainAmplifier}V,')
            print(f'DriverPeakingAmplifier={driverPeakingAmplifier}V,  FinalMainAmplifier1={finalMainAmplifier1}V,')
            print(f'FinalMainAmplifier2={finalMainAmplifier2}V,  FinalPeakingAmplifier1={finalPeakingAmplifier1}V,')
            print(f'FinalPeakingAmplifier2={finalPeakingAmplifier2}V.\n')
            rrhDfeProxy.mavu8t8rQpamControlSetPaBias(port, float(preDriver), float(driverMainAmplifier), float(driverPeakingAmplifier),
                                                     float(finalMainAmplifier1), float(finalMainAmplifier2), float(finalPeakingAmplifier1),
                                                     float(finalPeakingAmplifier2))
        elif getPaBias == 1:
            print(f'Getting PA bias voltage from port {port}.')
            rsp = rrhDfeProxy.mavu8t8rQpamControlGetPaBias(port)
            preDriver = rsp.preDriver
            driverMainAmplifier = rsp.driverMainAmplifier
            driverPeakingAmplifier = rsp.driverPeakingAmplifier
            finalMainAmplifier1 = rsp.finalMainAmplifier1
            finalMainAmplifier2 = rsp.finalMainAmplifier2
            finalPeakingAmplifier1 = rsp.finalPeakingAmplifier1
            finalPeakingAmplifier2 = rsp.finalPeakingAmplifier2
            print(f'PreDriver={preDriver}V,  DriverMainAmplifier={driverMainAmplifier}V,')
            print(f'DriverPeakingAmplifier={driverPeakingAmplifier}V,  FinalMainAmplifier1={finalMainAmplifier1}V,')
            print(f'FinalMainAmplifier2={finalMainAmplifier2}V,  FinalPeakingAmplifier1={finalPeakingAmplifier1}V,')
            print(f'FinalPeakingAmplifier2={finalPeakingAmplifier2}V.\n')
        elif paSetOn == 1:
            print(f'Setting PA ON on port {port}.\n')
            rrhDfeProxy.mavu8t8rQpamControlPASetOn(port)
        elif paSetOff == 1:
            print(f'Setting PA OFF on all ports.\n')
            rrhDfeProxy.mavu8t8rQpamControlPASetOff()
        elif getPaCurrent == 1:
            print(f'Getting PA current from port {port}.')
            rsp = rrhDfeProxy.mavu8t8rQpamControlGetPaCurrentMonitorVoltage(port)
            driverMainAmplifier = rsp.driverMainAmplifier
            finalMainAmplifier = rsp.finalMainAmplifier
            print(f'DriverMainAmplifier current is {driverMainAmplifier},')
            print(f'FinalMainAmplifier current is {finalMainAmplifier}.\n')
        elif readTemp == 1:
            print(f'Reading temperature from TX port {port}.')
            rsp = rrhDfeProxy.mavu8t8rQpamControlTxPortReadTemp(port)
            print(f'Temperature is {rsp.readTemp}\n')
        elif getStepSize == 1:
            print(f'Getting PA bias step size.')
            rsp = rrhDfeProxy.mavu8t8rQpamControlGetPaBiasStepSize()
            print(f'Step size is {rsp.stepSize}.\n')
        elif checkPaMonAvail == 1:
            print(f'Checking PA current monitor availability.')
            rsp = rrhDfeProxy.mavu8t8rQpamControlHasPaCurrentMonitor()
            if rsp.paCurrentMontiorExist:
                print(f'PA current monitor is existing.\n')
            else:
                print(f'PA current monitor is NOT existing.\n')
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
