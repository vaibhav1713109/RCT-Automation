import pandas as pd
import sys

# Read input file
try:
    filename = sys.argv[1]
    try:
        print('Reading signal file...')
        data = pd.read_csv(filename, delim_whitespace=True, header=None)
    except Exception as e:
        print(f'error: could not read signal file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no signal file provided')
    sys.exit(1)

# Open output file
try:
    filename = sys.argv[2]
    try:
        outfile = open(filename, "wb")
    except Exception as e:
        print(f'error: could not open output file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no output file provided')
    sys.exit(1)
    
print('Converting...')
value = 0
result = bytearray()
for index, i, q in data.itertuples(name=None):
    value = (value >> 32) & 0xffffffff
    value |= ((q & 0xffff) << 48) | ((i & 0xffff) << 32)
    if index % 2:
        result += value.to_bytes(8, 'little')
        value = 0

outfile.write(result)
