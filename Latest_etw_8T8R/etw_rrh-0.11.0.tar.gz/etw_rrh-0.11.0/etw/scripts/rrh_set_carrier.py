import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hilaedmgt:j:k:xn:s:f:b:c:u:p:',
                                          ['help', 'init', 'list', 'add', 'enable', 'delete', 'modify',
                                           'getDfeStatus', 'chFiltMode=', 'gain=', 'ducInputSelect=', 'close',
                                           'name=', 'scs_u=', 'fftSize=', 'chBwMhz=', 'centerFreqKhz=',
                                           'ducDdc=', 'prachType='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    DucInputChain = ['DIDM/ORAN->DL LPHY->DUC',
                     'ETAP DIDM->DL LPHY->DUC',
                     'ETAP ORAN->DL LPHY->DUC',
                     'U-Plane Memory Load->DL LPHY->DUC',
                     'UL LPHY->DL LPHY->DUC',
                     'ETAP TDM->DUC',
                     'DDC->DUC']

    initCarrier = 0
    listAllCarriers = 0
    addCarrier = 0
    enableCarrier = 0
    deleteCarrier = 0
    modifyCarrier = 0
    getDfeStatus = 0
    setChFiltMode = 0
    setGain = 0
    setDucInputSelect = 0
    closeCarrier = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-i, --init           : carrier initialization, require argument -p')
            print ('-l, --list           : list all carriers')
            print ('-a, --add            : add carrier, require arguments -n, -s, -f, -b, -c')
            print ('-e, --enable         : enable carrier, require argument -n')
            print ('-d, --delete         : delete carrier, require argument -n')
            print ('-m, --modify         : modify carrier TX center frequency, require arguments -n, -c')
            print ('-g, --getDfeStatus   : get carrier\'s DFE Mixer status, require argument -n')
            print ('-t, --chFiltMode     : set channel filter mode for a carrier (0 for enable and 1 for bypass)')
            print ('                     : require arguments -n, -u')
            print ('-j, --gain           : set DUC/DDC gain for a carrier (specify float value in dB, e.g. 2.5)')
            print ('                     : require arguments -n, -u')
            print ('-k, --ducInputSelect : select DUC input chain, choose from:')
            print ('                       0 - DIDM/ORAN->DL LPHY->DUC')
            print ('                       1 - ETAP DIDM->DL LPHY->DUC')
            print ('                       2 - ETAP ORAN->DL LPHY->DUC')
            print ('                       3 - U-Plane Memory Load->DL LPHY->DUC')
            print ('                       4 - UL LPHY->DL LPHY->DUC')
            print ('                       5 - ETAP TDM->DUC')
            print ('                       6 - DDC->DUC')
            print ('-x, --close          : close carriers')
            print ('------ parameter specification ------')
            print ('-n, --name           : specify carrier name')
            print ('-s, --scs_u          : specify subcarrier spacing (0 for 15kHz, 1 for 30kHz)')
            print ('-f, --fftSize        : specify FFT size')
            print ('-b, --chBwMhz        : specify channel bandwidth (in MHz)')
            print ('-c, --centerFreqKhz  : specify center frequency (in kHz)')
            print ('-u, --ducDdc         : specify where to apply operation (0 for DUC and 1 for DDC)')
            print ('-p, --prachType      : specify type of PRACH (0 for dynamic and 1 for static)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-i', '--init'):
            initCarrier = 1
        elif currentArgument in ('-l', '--list'):
            listAllCarriers = 1
        elif currentArgument in ('-a', '--add'):
            addCarrier = 1
        elif currentArgument in ('-e', '--enable'):
            enableCarrier = 1
        elif currentArgument in ('-d', '--delete'):
            deleteCarrier = 1
        elif currentArgument in ('-m', '--modify'):
            modifyCarrier = 1
        elif currentArgument in ('-g', '--getDfeStatus'):
            getDfeStatus = 1
        elif currentArgument in ('-t', '--chFiltMode'):
            setChFiltMode = 1
            chFiltMode = int(currentValue)
        elif currentArgument in ('-j', '--gain'):
            setGain = 1
            gain = float(currentValue)
        elif currentArgument in ('-k', '--ducInputSelect'):
            setDucInputSelect = 1
            ducInputSelect = int(currentValue)
        elif currentArgument in ('-x', '--close'):
            closeCarrier = 1
        elif currentArgument in ('-n', '--name'):
            carrierName = currentValue
        elif currentArgument in ('-s', '--scs_u'):
            scs_u = int(currentValue)
        elif currentArgument in ('-f', '--fftSize'):
            fftSize = int(currentValue)
        elif currentArgument in ('-b', '--chBwMhz'):
            chBwMhz = int(currentValue)
        elif currentArgument in ('-c', '--centerFreqKhz'):
            centerFreqKhz = int(currentValue)
        elif currentArgument in ('-u', '--ducDdc'):
            ducDdc = int(currentValue)
        elif currentArgument in ('-p', '--prachType'):
            enableStaticPrach = int(currentValue)
            
    try:
        if initCarrier == 1:
            if enableStaticPrach == 1:
                print('Initializing carriers in static prach mode.\n')
            else:
                print('Initializing carriers in dynamic prach mode.\n')
            rrhDfeProxy.carrierInit(enableStaticPrach)
        elif listAllCarriers == 1:
            print('Listing all carriers on target.\n')
            rrhDfeProxy.carrierListAll()
        elif addCarrier == 1:
            if scs_u == 0:
                scs_str = '15kHz'
            elif scs_u == 1:
                scs_str = '30kHz'
            print(f'Adding carrier {carrierName} (SCS={scs_str}, FFT size={fftSize}, Channel bandwidth={chBwMhz}MHz, Center frequency={centerFreqKhz/1000000}GHz).\n')
            rrhDfeProxy.carrierAdd(carrierName, scs_u, fftSize, chBwMhz, centerFreqKhz)
        elif enableCarrier == 1:
            print(f'Enabling carrier {carrierName}.\n')
            rrhDfeProxy.carrierEnable(carrierName)
        elif deleteCarrier == 1:
            print(f'Deleting carrier {carrierName}.\n')
            rrhDfeProxy.carrierDelete(carrierName)
        elif modifyCarrier == 1:
            print(f'Modifying TX frequency for carrier {carrierName} to {centerFreqKhz/1000000}GHz.\n')
            rrhDfeProxy.carrierModifyTxFreq(carrierName, centerFreqKhz)
        elif getDfeStatus == 1:
            print(f'Getting DFE status for carrier {carrierName}.\n')
            rrhDfeProxy.carrierGetMixerEventStatus(carrierName)
        elif setChFiltMode == 1:
            print(f'Setting channel filter mode to carrier {carrierName}.\n')
            rrhDfeProxy.carrierSetChFiltBypass(carrierName, ducDdc, chFiltMode)
        elif setGain == 1:
            if ducDdc == 0:
                print(f'Setting carrier {carrierName} DUC gain to {gain}dB.\n')
                rrhDfeProxy.carrierModifyGain(carrierName, ducDdc, gain)
            elif ducDdc == 1:
                print(f'Setting carrier {carrierName} DDC gain to {gain}dB.\n')
                rrhDfeProxy.carrierModifyGain(carrierName, ducDdc, gain)
            else:
                print('Invalid DUC/DDC selection. -h for help.')
        elif setDucInputSelect == 1:
            print(f'Setting DUC input chain to {ducInputSelect}:{DucInputChain[ducInputSelect]}.\n')
            rrhDfeProxy.carrierSetDucInput(ducInputSelect)
        elif closeCarrier == 1:
            print('Closing all carriers.\n')
            rrhDfeProxy.carrierClose()
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
