import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main():
    ipcLink = IpcLink(target.ip_address, target.port)
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrhDfeProxy.connect()
    rrh_dfe.debug_on = 0

    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hscp:a:y:t:b:r:',
                                          ['help', 'set', 'clear',
                                           'peak=', 'attenStep=', 'hysteresis=',
                                           'tileId=', 'blockId=', 'thresholdSelect='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    setThreshold = 0
    clrThresholdEvent = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help            : option list')
            print ('-s, --set             : set Rx AGC threshold, require arguments -p, -a, -y')
            print ('-c, --clear           : clear Rx AGC threshold event, require arguments -t, -b, -r')
            print ('------ parameter specification ------')
            print ('-p, --peak            : specify Rx AGC peak (less than 0, in dBFS)')
            print ('-a, --attenStep       : specify Rx AGC CG attenuation step (greater than 0, in dB)')
            print ('-y, --hysteresis      : specify Rx AGC hysteresis (greater than 0, in dB)')
            print ('-t, --tileId          : specify ADC tile ID')
            print ('-b, --blockId         : specify ADC block ID')
            print ('-r, --thresholdSelect : specify ADC threshold select (0 or 1)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-s', '--set'):
            setThreshold = 1
        elif currentArgument in ('-c', '--clear'):
            clrThresholdEvent = 1
        elif currentArgument in ('-p', '--peak'):
            peak = float(currentValue)
        elif currentArgument in ('-a', '--attenStep'):
            attenStep = float(currentValue)
        elif currentArgument in ('-y', '--hysteresis'):
            hysteresis = float(currentValue)
        elif currentArgument in ('-t', '--tileId'):
            tileId = int(currentValue)
        elif currentArgument in ('-b', '--blockId'):
            blockId = int(currentValue)
        elif currentArgument in ('-r', '--thresholdSelect'):
            thresholdSelect = int(currentValue)

    try:
        if setThreshold == 1:
            print(f'Setting Rx AGC threshold: peak = {peak}dBFS, attenStep = {attenStep}dB, hysteresis = {hysteresis}dB.\n')
            rrhDfeProxy.rxAgcSetThresholds(peak, attenStep, hysteresis)
        elif clrThresholdEvent == 1:
            print(f'Clearing Rx AGC threshold event: tileId = {tileId}, blockId = {blockId}, selected threshold {thresholdSelect}.\n')
            rrhDfeProxy.rxAgcClrThresholdEvent(tileId, blockId, thresholdSelect)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
