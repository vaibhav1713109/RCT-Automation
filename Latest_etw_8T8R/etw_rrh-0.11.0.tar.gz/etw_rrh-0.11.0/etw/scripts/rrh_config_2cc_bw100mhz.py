import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time
import subprocess as sp

def main():        
    ipcLink = IpcLink(target.ip_address, target.port)
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrhDfeProxy.connect()
    rrh_dfe.debug_on = 0

    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hc:',
                                          ['help', 'centerFreqKhz='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    # default settings
    enableStaticPrach = 1    # static
    numCarriers = 2          # number of component carriers
    carrierNames = ['CC0', 'CC1']
    scs_u = 1                # 30kHz
    fftSize = 4096
    chBwMhz = 100            # 100MHz
    centerFreqKhz = 3450000  # 3.45GHz
    dacAtten = 0
    dacAttenPort = 7
    adcAtten = 0
    adcAttenPort = 7

    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('------ parameter specification ------')
            print ('-c, --centerFreqKhz  : specify TX/RX RF center frequency (in kHz)')
            print ('=====================================')
            sys.exit()
        elif currentArgument in ('-c', '--centerFreqKhz'):
            centerFreqKhz = int(currentValue)
            
    try:
        print('======== Started setting up 2CC test case ========\n')

        # Initialize carrier
        sp.run(f'python3 rrh_set_carrier.py -i -p {enableStaticPrach}', shell=True)
          
        # Set TX RF frequency
        sp.run(f'python3 rrh_set_rf_frequency.py -t -f {centerFreqKhz}', shell=True)

        # Set RX RF frequency
        sp.run(f'python3 rrh_set_rf_frequency.py -r -f {centerFreqKhz}', shell=True)

        # Set DAC attenuation
        sp.run(f'python3 rrh_set_attenuation.py -d -p {dacAttenPort} -s {dacAtten}', shell=True)

        # Set ADC attenuation
        sp.run(f'python3 rrh_set_attenuation.py -a -p {adcAttenPort} -s {adcAtten}', shell=True)

        # Add carriers
        carrierFreqKhz = [centerFreqKhz-50000, centerFreqKhz+50000]  # centerFreq-50MHz for CC0 and centerFreq+50MHz for CC1
        for ccid in range(numCarriers):
            sp.run(f'python3 rrh_set_carrier.py -a -n {carrierNames[ccid]} -s {scs_u} -f {fftSize} -b {chBwMhz} -c {carrierFreqKhz[ccid]}', shell=True)

        # Enable carriers
        for ccid in range(numCarriers):
            sp.run(f'python3 rrh_set_carrier.py -e -n {carrierNames[ccid]}', shell=True)

        print('======== Completed setting up 2CC test case ========\n')
        
    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
