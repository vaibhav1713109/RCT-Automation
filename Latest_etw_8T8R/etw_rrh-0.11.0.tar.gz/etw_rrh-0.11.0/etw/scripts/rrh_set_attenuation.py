import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main():        
    ipcLink = IpcLink(target.ip_address, target.port)
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrhDfeProxy.connect()
    rrh_dfe.debug_on = 0

    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hdap:s:',
                                          ['help', 'dac', 'adc',
                                           'port=', 'scale='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    setDacAtten = 0
    setAdcAtten = 0

    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-d, --dac            : set DAC attenuation, require arguments -p, -s')
            print ('-a, --adc            : set ADC attenuation, require arguments -p, -s')
            print ('------ parameter specification ------')
            print ('-p, --port           : specify port number')
            print ('-s, --scale          : specify attenuation scale (in dB)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-d', '--dac'):
            setDacAtten = 1
        elif currentArgument in ('-a', '--adc'):
            setAdcAtten = 1
        elif currentArgument in ('-p', '--port'):
            port = int(currentValue)
        elif currentArgument in ('-s', '--scale'):
            atten = float(currentValue)

    try:
        if setDacAtten == 1:
            print(f'Setting DAC attenuation {atten}dB to port {port}.\n')
            rrhDfeProxy.rfControlSetDacAtten(port, atten)
        elif setAdcAtten == 1:
            print(f'Setting ADC attenuation {atten}dB to port {port}.\n')
            rrhDfeProxy.rfControlSetAdcAtten(port, atten)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
