import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main():
    ipcLink = IpcLink(target.ip_address, target.port)
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrhDfeProxy.connect()
    rrh_dfe.debug_on = 0

    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hw:r:a:d:',
                                          ['help', 'write=', 'read=', 'addr=', 'data='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    CHIP_NAME = ['Undefined', 'QPAM1_SPI_LE_A','QPAM1_SPI_LE_B','QPAM2_SPI_LE_A','QPAM2_SPI_LE_B']

    spiWrite = 0
    spiRead = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help         : option list')
            print ('-w, --write        : write to MAX chip registers')
            print ('                   : (choose from 1-QPAM1_SPI_LE_A, 2-QPAM1_SPI_LE_B,')
            print ('                   :              3-QPAM2_SPI_LE_A, 4-QPAM2_SPI_LE_B)')
            print ('                   : require arguments -a, -d')
            print ('-r, --read         : read from MAX chip registers')
            print ('                   : (choose from 1-QPAM1_SPI_LE_A, 2-QPAM1_SPI_LE_B,')
            print ('                   :              3-QPAM2_SPI_LE_A, 4-QPAM2_SPI_LE_B)')
            print ('                   : require argument -a')
            print ('------ parameter specification ------')
            print ('-a, --addr         : specify SPI address (in Hex, e.g. 0x123)')
            print ('-d, --data         : specify write data (in Hex, e.g. 0x456)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-w', '--write'):
            spiWrite = 1
            maxChipId = int(currentValue)
        elif currentArgument in ('-r', '--read'):
            spiRead = 1
            maxChipId = int(currentValue)
        elif currentArgument in ('-a', '--addr'):
            if currentValue[0:2] == '0x' or currentValue[0:2] == '0X':
                addr = int(currentValue[2:], 16)
            else:
                print('Invalid format for address. -h for help.')
                sys.exit()
        elif currentArgument in ('-d', '--data'):
            if currentValue[0:2] == '0x' or currentValue[0:2] == '0X':
                wdata = int(currentValue[2:], 16)
            else:
                print('Invalid format for data. -h for help.')
                sys.exit()

    try:
        if spiWrite == 1:
            print(f'Writing to QPAM MAXChip {maxChipId}-{CHIP_NAME[maxChipId]} register (ADDR={hex(addr)}, DATA={hex(wdata)}).\n')
            rrhDfeProxy.mavu8t8rQpamControlMax11300SpiWrite(maxChipId, addr, wdata)
        elif spiRead == 1:
            print(f'Reading from QPAM MAXChip {maxChipId}-{CHIP_NAME[maxChipId]} register (ADDR={hex(addr)}).')
            rsp = rrhDfeProxy.mavu8t8rQpamControlMax11300SpiRead(maxChipId, addr)
            rdata = rsp.rdata
            print(f'Read value: DATA={hex(rdata)}.\n')
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
