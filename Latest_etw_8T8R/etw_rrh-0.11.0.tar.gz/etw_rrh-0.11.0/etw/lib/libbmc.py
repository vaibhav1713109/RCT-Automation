from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libbmc_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libbmcProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibbmc", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def MAVU_8T8R_Trx_Digital_SettempThreshold(self, warn_level, fault_level):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SettempThresholdReq()
        _req.warn_level = warn_level
        _req.fault_level = fault_level
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SettempThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SettempThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SettempThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SettempThreshold failed: no valid response found (mAVU_8T8R_Trx_Digital_SettempThreshold)")
        return _rsp.mAVU_8T8R_Trx_Digital_SettempThresholdRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_SettempThresholdRsp.temp_sensor_id, _rsp.mAVU_8T8R_Trx_Digital_SettempThresholdRsp._ret

    def MAVU_8T8R_Trx_Digital_GettempThreshold(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GettempThresholdReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GettempThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GettempThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GettempThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GettempThreshold failed: no valid response found (mAVU_8T8R_Trx_Digital_GettempThreshold)")
        return _rsp.mAVU_8T8R_Trx_Digital_GettempThresholdRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GettempThresholdRsp.temp_sensor_id, _rsp.mAVU_8T8R_Trx_Digital_GettempThresholdRsp.warn_level, _rsp.mAVU_8T8R_Trx_Digital_GettempThresholdRsp.fault_level, _rsp.mAVU_8T8R_Trx_Digital_GettempThresholdRsp._ret

    def MAVU_8T8R_Trx_Digital_GetTempStatus(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetTempStatusReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetTempStatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetTempStatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetTempStatus failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetTempStatus failed: no valid response found (mAVU_8T8R_Trx_Digital_GetTempStatus)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetTempStatusRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetTempStatusRsp.temp_status, _rsp.mAVU_8T8R_Trx_Digital_GetTempStatusRsp._ret

    def MAVU_8T8R_Trx_Digital_GetTempSensorValue(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetTempSensorValueReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetTempSensorValueReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetTempSensorValueRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetTempSensorValue failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetTempSensorValue failed: no valid response found (mAVU_8T8R_Trx_Digital_GetTempSensorValue)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetTempSensorValueRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetTempSensorValueRsp.temp_value, _rsp.mAVU_8T8R_Trx_Digital_GetTempSensorValueRsp._ret

    def MAVU_8T8R_Trx_Digital_SetTempHystersis(self, hyst_limit):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetTempHystersisReq()
        _req.hyst_limit = hyst_limit
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetTempHystersisReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetTempHystersisRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetTempHystersis failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetTempHystersis failed: no valid response found (mAVU_8T8R_Trx_Digital_SetTempHystersis)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetTempHystersisRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_SetTempHystersisRsp._ret

    def MAVU_8T8R_Trx_Digital_GetHystersisvalue(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetHystersisvalueReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetHystersisvalueReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetHystersisvalueRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetHystersisvalue failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetHystersisvalue failed: no valid response found (mAVU_8T8R_Trx_Digital_GetHystersisvalue)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetHystersisvalueRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetHystersisvalueRsp.hyst_value, _rsp.mAVU_8T8R_Trx_Digital_GetHystersisvalueRsp._ret

    def MAVU_8T8R_Trx_Digital_writeEeprom(self, w_addr_off, byte_count):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_writeEepromReq()
        _req.w_addr_off = w_addr_off
        _req.byte_count = byte_count
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_writeEepromReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_writeEepromRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_writeEeprom failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_writeEeprom failed: no valid response found (mAVU_8T8R_Trx_Digital_writeEeprom)")
        return _rsp.mAVU_8T8R_Trx_Digital_writeEepromRsp.data_buff, _rsp.mAVU_8T8R_Trx_Digital_writeEepromRsp._ret

    def MAVU_8T8R_Trx_Digital_ReadEeprom(self, r_addr_off, byte_count):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_ReadEepromReq()
        _req.r_addr_off = r_addr_off
        _req.byte_count = byte_count
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_ReadEepromReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_ReadEepromRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_ReadEeprom failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_ReadEeprom failed: no valid response found (mAVU_8T8R_Trx_Digital_ReadEeprom)")
        return _rsp.mAVU_8T8R_Trx_Digital_ReadEepromRsp.data_buff, _rsp.mAVU_8T8R_Trx_Digital_ReadEepromRsp._ret

    def MAVU_8T8R_Trx_Digital_GetMacAddr(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetMacAddrReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetMacAddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetMacAddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetMacAddr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetMacAddr failed: no valid response found (mAVU_8T8R_Trx_Digital_GetMacAddr)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetMacAddrRsp.intf, _rsp.mAVU_8T8R_Trx_Digital_GetMacAddrRsp.mac, _rsp.mAVU_8T8R_Trx_Digital_GetMacAddrRsp._ret

    def MAVU_8T8R_Trx_Digital_SetMacAddr(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetMacAddrReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetMacAddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetMacAddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetMacAddr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetMacAddr failed: no valid response found (mAVU_8T8R_Trx_Digital_SetMacAddr)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetMacAddrRsp.password, _rsp.mAVU_8T8R_Trx_Digital_SetMacAddrRsp.ethIntf, _rsp.mAVU_8T8R_Trx_Digital_SetMacAddrRsp.mac, _rsp.mAVU_8T8R_Trx_Digital_SetMacAddrRsp._ret

    def MAVU_8T8R_Trx_Digital_SetSnumber(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetSnumberReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetSnumberReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetSnumberRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetSnumber failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetSnumber failed: no valid response found (mAVU_8T8R_Trx_Digital_SetSnumber)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetSnumberRsp.password, _rsp.mAVU_8T8R_Trx_Digital_SetSnumberRsp.sNum, _rsp.mAVU_8T8R_Trx_Digital_SetSnumberRsp._ret

    def MAVU_8T8R_Trx_Digital_GetSnumber(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetSnumberReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetSnumberReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetSnumberRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetSnumber failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetSnumber failed: no valid response found (mAVU_8T8R_Trx_Digital_GetSnumber)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetSnumberRsp.sno, _rsp.mAVU_8T8R_Trx_Digital_GetSnumberRsp._ret

    def MAVU_8T8R_Trx_Digital_SetPassword(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetPasswordReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetPasswordReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetPasswordRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetPassword failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetPassword failed: no valid response found (mAVU_8T8R_Trx_Digital_SetPassword)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetPasswordRsp.password, _rsp.mAVU_8T8R_Trx_Digital_SetPasswordRsp._ret

    def MAVU_8T8R_Trx_Digital_ChangePassword(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_ChangePasswordReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_ChangePasswordReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_ChangePasswordRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_ChangePassword failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_ChangePassword failed: no valid response found (mAVU_8T8R_Trx_Digital_ChangePassword)")
        return _rsp.mAVU_8T8R_Trx_Digital_ChangePasswordRsp.oldpassword, _rsp.mAVU_8T8R_Trx_Digital_ChangePasswordRsp.newpassword, _rsp.mAVU_8T8R_Trx_Digital_ChangePasswordRsp._ret

    def MAVU_8T8R_Trx_Digital_SetModelNumber(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetModelNumberReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetModelNumberReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetModelNumberRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetModelNumber failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetModelNumber failed: no valid response found (mAVU_8T8R_Trx_Digital_SetModelNumber)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetModelNumberRsp.password, _rsp.mAVU_8T8R_Trx_Digital_SetModelNumberRsp.mNum, _rsp.mAVU_8T8R_Trx_Digital_SetModelNumberRsp._ret

    def MAVU_8T8R_Trx_Digital_GetModelNumber(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetModelNumberReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetModelNumberReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetModelNumberRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetModelNumber failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetModelNumber failed: no valid response found (mAVU_8T8R_Trx_Digital_GetModelNumber)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetModelNumberRsp.mno, _rsp.mAVU_8T8R_Trx_Digital_GetModelNumberRsp._ret

    def MAVU_8T8R_Trx_Digital_GetCurrent(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetCurrentReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetCurrentReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetCurrentRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetCurrent failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetCurrent failed: no valid response found (mAVU_8T8R_Trx_Digital_GetCurrent)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetCurrentRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetCurrentRsp.current, _rsp.mAVU_8T8R_Trx_Digital_GetCurrentRsp._ret

    def MAVU_8T8R_Trx_Digital_GetPower(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetPowerReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetPowerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetPowerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetPower failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetPower failed: no valid response found (mAVU_8T8R_Trx_Digital_GetPower)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetPowerRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetPowerRsp.power, _rsp.mAVU_8T8R_Trx_Digital_GetPowerRsp._ret

    def MAVU_8T8R_Trx_Digital_GetPowerStatus(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetPowerStatusReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetPowerStatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetPowerStatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetPowerStatus failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetPowerStatus failed: no valid response found (mAVU_8T8R_Trx_Digital_GetPowerStatus)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetPowerStatusRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetPowerStatusRsp.pStatus, _rsp.mAVU_8T8R_Trx_Digital_GetPowerStatusRsp._ret

    def MAVU_8T8R_Trx_Digital_SetInaThreshold(self, threshold):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_SetInaThresholdReq()
        _req.threshold = threshold
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_SetInaThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_SetInaThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_SetInaThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_SetInaThreshold failed: no valid response found (mAVU_8T8R_Trx_Digital_SetInaThreshold)")
        return _rsp.mAVU_8T8R_Trx_Digital_SetInaThresholdRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_SetInaThresholdRsp.curr_sensor_id, _rsp.mAVU_8T8R_Trx_Digital_SetInaThresholdRsp._ret

    def MAVU_8T8R_Trx_Digital_GetInaThreshold(self):
        _req = libbmc_pb2.MAVU_8T8R_Trx_Digital_GetInaThresholdReq()
        _inMsg = libbmc_pb2.libbmcIn()
        _inMsg.mAVU_8T8R_Trx_Digital_GetInaThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libbmc_pb2.libbmcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_Trx_Digital_GetInaThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_Trx_Digital_GetInaThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_Trx_Digital_GetInaThreshold failed: no valid response found (mAVU_8T8R_Trx_Digital_GetInaThreshold)")
        return _rsp.mAVU_8T8R_Trx_Digital_GetInaThresholdRsp.boardType, _rsp.mAVU_8T8R_Trx_Digital_GetInaThresholdRsp.curr_sensor_id, _rsp.mAVU_8T8R_Trx_Digital_GetInaThresholdRsp.current_value, _rsp.mAVU_8T8R_Trx_Digital_GetInaThresholdRsp._ret

