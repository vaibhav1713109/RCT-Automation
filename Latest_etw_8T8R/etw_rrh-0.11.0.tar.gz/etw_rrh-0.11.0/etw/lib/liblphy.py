from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import liblphy_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class liblphyProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwliblphy", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = liblphy_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def LPhy_Init(self):
        _req = liblphy_pb2.LPhy_InitReq()
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.lPhy_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "lPhy_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("LPhy_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("LPhy_Init failed: no valid response found (lPhy_Init)")
        return self.returnStatusType_toDict(_rsp.lPhy_InitRsp._ret)

    def LPhy_Deinit(self):
        _req = liblphy_pb2.LPhy_DeinitReq()
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.lPhy_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "lPhy_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("LPhy_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("LPhy_Deinit failed: no valid response found (lPhy_Deinit)")
        return self.returnStatusType_toDict(_rsp.lPhy_DeinitRsp._ret)

    def DlLowPhyOpen(self, DlLowPhyIndexInChain, DlLowPhyBaseAddr, beamformEnabled):
        _req = liblphy_pb2.DlLowPhyOpenReq()
        _req.DlLowPhyIndexInChain = DlLowPhyIndexInChain
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _req.beamformEnabled = beamformEnabled
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyOpenReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyOpenRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyOpen failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyOpen failed: no valid response found (dlLowPhyOpen)")
        return self.returnStatusType_toDict(_rsp.dlLowPhyOpenRsp._ret)

    def DlLowPhyAddCc(self, DlLowPhyBaseAddr, CCID, oranCCID, ifftSizeCtrl, ccUramStartAddr, UPlaneDataStartAddr, numOfPrbs):
        _req = liblphy_pb2.DlLowPhyAddCcReq()
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _req.CCID = CCID
        _req.oranCCID = oranCCID
        _req.ifftSizeCtrl = ifftSizeCtrl
        _req.ccUramStartAddr = ccUramStartAddr
        _req.UPlaneDataStartAddr = UPlaneDataStartAddr
        _req.numOfPrbs = numOfPrbs
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyAddCcReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyAddCcRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyAddCc failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyAddCc failed: no valid response found (dlLowPhyAddCc)")
        return self.returnStatusType_toDict(_rsp.dlLowPhyAddCcRsp._ret)

    def DlLowPhyEnableLayer(self, DlLowPhyBaseAddr, layerNumber):
        _req = liblphy_pb2.DlLowPhyEnableLayerReq()
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _req.layerNumber = layerNumber
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyEnableLayerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyEnableLayerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyEnableLayer failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyEnableLayer failed: no valid response found (dlLowPhyEnableLayer)")

    def DlLowPhyLoadUPlaneStart(self, DlLowPhyBaseAddr):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneStartReq()
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneStartReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneStartRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneStart failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneStart failed: no valid response found (dlLowPhyLoadUPlaneStart)")

    def DlLowPhyLoadUPlaneEnd(self, DlLowPhyBaseAddr):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneEndReq()
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneEndReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneEndRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneEnd failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneEnd failed: no valid response found (dlLowPhyLoadUPlaneEnd)")

    def DlLowPhyLoadUPlaneDataWord(self, DlLowPhyBaseAddr, UPlaneDataStartAddr, reNumber, ReDataI, ReDataQ):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneDataWordReq()
        _req.DlLowPhyBaseAddr = DlLowPhyBaseAddr
        _req.UPlaneDataStartAddr = UPlaneDataStartAddr
        _req.reNumber = reNumber
        _req.ReDataI = ReDataI
        _req.ReDataQ = ReDataQ
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneDataWordReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneDataWordRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneDataWord failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneDataWord failed: no valid response found (dlLowPhyLoadUPlaneDataWord)")

