from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libpowmeas_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libpowmeasProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibpowmeas", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def GetTxAntDigitalPower(self, port, subFrameMode, subFrameNumber):
        _req = libpowmeas_pb2.GetTxAntDigitalPowerReq()
        _req.port = port
        _req.subFrameMode = subFrameMode
        _req.subFrameNumber = subFrameNumber
        _inMsg = libpowmeas_pb2.libpowmeasIn()
        _inMsg.getTxAntDigitalPowerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libpowmeas_pb2.libpowmeasOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getTxAntDigitalPowerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetTxAntDigitalPower failed: " + _rsp.zzerr_msg)
            raise EtwError("GetTxAntDigitalPower failed: no valid response found (getTxAntDigitalPower)")
        return _rsp.getTxAntDigitalPowerRsp._ret

    def GetRxAntDigitalPower(self, port, subFrameMode, subFrameNumber):
        _req = libpowmeas_pb2.GetRxAntDigitalPowerReq()
        _req.port = port
        _req.subFrameMode = subFrameMode
        _req.subFrameNumber = subFrameNumber
        _inMsg = libpowmeas_pb2.libpowmeasIn()
        _inMsg.getRxAntDigitalPowerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libpowmeas_pb2.libpowmeasOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getRxAntDigitalPowerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetRxAntDigitalPower failed: " + _rsp.zzerr_msg)
            raise EtwError("GetRxAntDigitalPower failed: no valid response found (getRxAntDigitalPower)")
        return _rsp.getRxAntDigitalPowerRsp._ret

