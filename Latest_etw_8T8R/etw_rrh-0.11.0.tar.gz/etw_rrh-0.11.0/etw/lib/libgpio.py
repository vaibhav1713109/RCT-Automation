from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libgpio_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libgpioProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibgpio", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def GpioDirection(self, gpio, direction):
        _req = libgpio_pb2.GpioDirectionReq()
        _req.gpio = gpio
        _req.direction = direction
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioDirectionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioDirectionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioDirection failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioDirection failed: no valid response found (gpioDirection)")
        return _rsp.gpioDirectionRsp._ret

    def GpioExport(self, gpio):
        _req = libgpio_pb2.GpioExportReq()
        _req.gpio = gpio
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioExportReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioExportRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioExport failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioExport failed: no valid response found (gpioExport)")
        return _rsp.gpioExportRsp._ret

    def GpioInit(self, gpio, direction):
        _req = libgpio_pb2.GpioInitReq()
        _req.gpio = gpio
        _req.direction = direction
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioInitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioInitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioInit failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioInit failed: no valid response found (gpioInit)")
        return _rsp.gpioInitRsp._ret

    def GpioUnexport(self, gpio):
        _req = libgpio_pb2.GpioUnexportReq()
        _req.gpio = gpio
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioUnexportReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioUnexportRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioUnexport failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioUnexport failed: no valid response found (gpioUnexport)")

    def GpioWrite(self, gpio, val):
        _req = libgpio_pb2.GpioWriteReq()
        _req.gpio = gpio
        _req.val = val
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioWriteReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioWriteRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioWrite failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioWrite failed: no valid response found (gpioWrite)")
        return _rsp.gpioWriteRsp._ret

    def GpioRead(self, epfd, gpio):
        _req = libgpio_pb2.GpioReadReq()
        _req.epfd = epfd
        _req.gpio = gpio
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.gpioReadReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "gpioReadRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GpioRead failed: " + _rsp.zzerr_msg)
            raise EtwError("GpioRead failed: no valid response found (gpioRead)")
        return _rsp.gpioReadRsp._ret

    def read_from_gpio_base_file(self):
        _req = libgpio_pb2.read_from_gpio_base_fileReq()
        _inMsg = libgpio_pb2.libgpioIn()
        _inMsg.read_from_gpio_base_fileReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libgpio_pb2.libgpioOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "read_from_gpio_base_fileRsp":
            if _rsp.zzerr_msg:
                raise EtwError("read_from_gpio_base_file failed: " + _rsp.zzerr_msg)
            raise EtwError("read_from_gpio_base_file failed: no valid response found (read_from_gpio_base_file)")
        return _rsp.read_from_gpio_base_fileRsp._ret

