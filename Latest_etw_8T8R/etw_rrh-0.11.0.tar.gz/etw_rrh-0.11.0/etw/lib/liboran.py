from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import liboran_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class liboranProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwliboran", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = liboran_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def Struct_oran_caps_fromDict(self, dict):
        x = liboran_pb2.Struct_oran_caps()
        if not dict: return x
        setattr(x, "max_cc", dict.get("max_cc", 0))
        setattr(x, "num_eth_ports", dict.get("num_eth_ports", 0))
        setattr(x, "max_tx_ss", dict.get("max_tx_ss", 0))
        setattr(x, "max_rx_ss", dict.get("max_rx_ss", 0))
        setattr(x, "max_prach_ss", dict.get("max_prach_ss", 0))
        setattr(x, "num_sym", dict.get("num_sym", 0))
        setattr(x, "cp_adv_sym", dict.get("cp_adv_sym", 0))
        setattr(x, "dl_up_uram", dict.get("dl_up_uram", 0))
        setattr(x, "ul_cp_sym", dict.get("ul_cp_sym", 0))
        setattr(x, "iq_de_comp_methods", dict.get("iq_de_comp_methods", 0))
        setattr(x, "iq_de_comp_bfp_widths", dict.get("iq_de_comp_bfp_widths", 0))
        setattr(x, "iq_de_comp_mod_widths", dict.get("iq_de_comp_mod_widths", 0))
        setattr(x, "iq_comp_methods", dict.get("iq_comp_methods", 0))
        setattr(x, "iq_comp_bfp_widths", dict.get("iq_comp_bfp_widths", 0))
        return x

    def Struct_oran_fhi_eth_stats_fromDict(self, dict):
        x = liboran_pb2.Struct_oran_fhi_eth_stats()
        if not dict: return x
        setattr(x, "oran_rx_on_time", dict.get("oran_rx_on_time", 0))
        setattr(x, "oran_rx_early", dict.get("oran_rx_early", 0))
        setattr(x, "oran_rx_late", dict.get("oran_rx_late", 0))
        setattr(x, "oran_rx_corrupt", dict.get("oran_rx_corrupt", 0))
        setattr(x, "oran_rx_total_c", dict.get("oran_rx_total_c", 0))
        setattr(x, "oran_rx_on_time_c", dict.get("oran_rx_on_time_c", 0))
        setattr(x, "oran_rx_early_c", dict.get("oran_rx_early_c", 0))
        setattr(x, "oran_rx_late_c", dict.get("oran_rx_late_c", 0))
        setattr(x, "oran_rx_error_drop", dict.get("oran_rx_error_drop", 0))
        setattr(x, "oran_tx_total", dict.get("oran_tx_total", 0))
        setattr(x, "oran_tx_total_c", dict.get("oran_tx_total_c", 0))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def Struct_oran_caps_toDict(self, v):
        dict = {}
        dict["max_cc"] = getattr(v, "max_cc")
        dict["num_eth_ports"] = getattr(v, "num_eth_ports")
        dict["max_tx_ss"] = getattr(v, "max_tx_ss")
        dict["max_rx_ss"] = getattr(v, "max_rx_ss")
        dict["max_prach_ss"] = getattr(v, "max_prach_ss")
        dict["num_sym"] = getattr(v, "num_sym")
        dict["cp_adv_sym"] = getattr(v, "cp_adv_sym")
        dict["dl_up_uram"] = getattr(v, "dl_up_uram")
        dict["ul_cp_sym"] = getattr(v, "ul_cp_sym")
        dict["iq_de_comp_methods"] = getattr(v, "iq_de_comp_methods")
        dict["iq_de_comp_bfp_widths"] = getattr(v, "iq_de_comp_bfp_widths")
        dict["iq_de_comp_mod_widths"] = getattr(v, "iq_de_comp_mod_widths")
        dict["iq_comp_methods"] = getattr(v, "iq_comp_methods")
        dict["iq_comp_bfp_widths"] = getattr(v, "iq_comp_bfp_widths")
        return dict

    def Struct_oran_fhi_eth_stats_toDict(self, v):
        dict = {}
        dict["oran_rx_on_time"] = getattr(v, "oran_rx_on_time")
        dict["oran_rx_early"] = getattr(v, "oran_rx_early")
        dict["oran_rx_late"] = getattr(v, "oran_rx_late")
        dict["oran_rx_corrupt"] = getattr(v, "oran_rx_corrupt")
        dict["oran_rx_total_c"] = getattr(v, "oran_rx_total_c")
        dict["oran_rx_on_time_c"] = getattr(v, "oran_rx_on_time_c")
        dict["oran_rx_early_c"] = getattr(v, "oran_rx_early_c")
        dict["oran_rx_late_c"] = getattr(v, "oran_rx_late_c")
        dict["oran_rx_error_drop"] = getattr(v, "oran_rx_error_drop")
        dict["oran_tx_total"] = getattr(v, "oran_tx_total")
        dict["oran_tx_total_c"] = getattr(v, "oran_tx_total_c")
        return dict

    def MAVU_8T8R_ORAN_Init(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_InitReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Init failed: no valid response found (mAVU_8T8R_ORAN_Init)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_InitRsp._ret)

    def MAVU_8T8R_ORAN_Get_Capabilities(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_CapabilitiesReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_CapabilitiesReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_CapabilitiesRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Capabilities failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Capabilities failed: no valid response found (mAVU_8T8R_ORAN_Get_Capabilities)")
        return self.Struct_oran_caps_toDict(_rsp.mAVU_8T8R_ORAN_Get_CapabilitiesRsp.oran_cap), self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_CapabilitiesRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_Addr(self, ethPortId, macAddr):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _req.macAddr = macAddr
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Set_Src_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_Addr(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Clear_Src_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_Addr(self, ethPortId, macAddr):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _req.macAddr = macAddr
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Set_Dest_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_Addr(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Clear_Dest_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Set_Vlan(self, ethPortId, vlan):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Set_VlanReq()
        _req.ethPortId = ethPortId
        _req.vlan = vlan
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Set_VlanReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Set_VlanRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Vlan failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Vlan failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Set_Vlan)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Set_VlanRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Clear_Vlan(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Clear_VlanReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Clear_VlanReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Clear_VlanRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Vlan failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Vlan failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Clear_Vlan)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Clear_VlanRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Set_Filter_Config(self, ethPortId, filterConfigMask):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Set_Filter_ConfigReq()
        _req.ethPortId = ethPortId
        _req.filterConfigMask = filterConfigMask
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Set_Filter_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Set_Filter_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Filter_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Set_Filter_Config failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Set_Filter_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Set_Filter_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_U_Plane_Clear_Filter_Config(self, ethPortId, filterConfigMask):
        _req = liboran_pb2.MAVU_8T8R_ORAN_U_Plane_Clear_Filter_ConfigReq()
        _req.ethPortId = ethPortId
        _req.filterConfigMask = filterConfigMask
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_U_Plane_Clear_Filter_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_U_Plane_Clear_Filter_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Filter_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_U_Plane_Clear_Filter_Config failed: no valid response found (mAVU_8T8R_ORAN_U_Plane_Clear_Filter_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_U_Plane_Clear_Filter_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_Addr(self, ethPortId, macAddr):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _req.macAddr = macAddr
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Set_Src_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_Addr(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Clear_Src_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_Addr(self, ethPortId, macAddr):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _req.macAddr = macAddr
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Set_Dest_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_Addr(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_AddrReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_AddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_AddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_Addr failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_Addr failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_Addr)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Clear_Dest_Mac_AddrRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Set_Vlan(self, ethPortId, vlan):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Set_VlanReq()
        _req.ethPortId = ethPortId
        _req.vlan = vlan
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Set_VlanReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Set_VlanRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Vlan failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Vlan failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Set_Vlan)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Set_VlanRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Clear_Vlan(self, ethPortId):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Clear_VlanReq()
        _req.ethPortId = ethPortId
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Clear_VlanReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Clear_VlanRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Vlan failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Vlan failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Clear_Vlan)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Clear_VlanRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Set_Filter_Config(self, ethPortId, filterConfigMask):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Set_Filter_ConfigReq()
        _req.ethPortId = ethPortId
        _req.filterConfigMask = filterConfigMask
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Set_Filter_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Set_Filter_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Filter_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Set_Filter_Config failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Set_Filter_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Set_Filter_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_C_Plane_Clear_Filter_Config(self, ethPortId, filterConfigMask):
        _req = liboran_pb2.MAVU_8T8R_ORAN_C_Plane_Clear_Filter_ConfigReq()
        _req.ethPortId = ethPortId
        _req.filterConfigMask = filterConfigMask
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_C_Plane_Clear_Filter_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_C_Plane_Clear_Filter_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Filter_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_C_Plane_Clear_Filter_Config failed: no valid response found (mAVU_8T8R_ORAN_C_Plane_Clear_Filter_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_C_Plane_Clear_Filter_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_Set_DL_Eaxc_Id(self, cc_id, ss_id, eaxc_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_DL_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.eaxc_id = eaxc_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_DL_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_DL_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_DL_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_DL_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Set_DL_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_DL_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Clear_DL_Eaxc_Id(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Clear_DL_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Clear_DL_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Clear_DL_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Clear_DL_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Clear_DL_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Clear_DL_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Clear_DL_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Set_UL_Eaxc_Id(self, cc_id, ss_id, eaxc_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_UL_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.eaxc_id = eaxc_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_UL_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_UL_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_UL_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_UL_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Set_UL_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_UL_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Clear_UL_Eaxc_Id(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Clear_UL_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Clear_UL_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Clear_UL_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Clear_UL_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Clear_UL_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Clear_UL_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Clear_UL_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Set_PRACH_Eaxc_Id(self, cc_id, ss_id, eaxc_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_PRACH_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.eaxc_id = eaxc_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_PRACH_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_PRACH_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Set_PRACH_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_PRACH_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Clear_PRACH_Eaxc_Id(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Clear_PRACH_Eaxc_IdReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Clear_PRACH_Eaxc_IdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Clear_PRACH_Eaxc_IdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Clear_PRACH_Eaxc_Id failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Clear_PRACH_Eaxc_Id failed: no valid response found (mAVU_8T8R_ORAN_Clear_PRACH_Eaxc_Id)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Clear_PRACH_Eaxc_IdRsp._ret)

    def MAVU_8T8R_ORAN_Set_DL_IQ_Compression(self, cc_id, ss_id, iq_width, comp_method):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_DL_IQ_CompressionReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.iq_width = iq_width
        _req.comp_method = comp_method
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_DL_IQ_CompressionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_DL_IQ_CompressionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_DL_IQ_Compression failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_DL_IQ_Compression failed: no valid response found (mAVU_8T8R_ORAN_Set_DL_IQ_Compression)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_DL_IQ_CompressionRsp._ret)

    def MAVU_8T8R_ORAN_Enable_DL_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Enable_DL_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Enable_DL_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Enable_DL_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Enable_DL_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Enable_DL_Port failed: no valid response found (mAVU_8T8R_ORAN_Enable_DL_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Enable_DL_PortRsp._ret)

    def MAVU_8T8R_ORAN_Disable_DL_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Disable_DL_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Disable_DL_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Disable_DL_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Disable_DL_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Disable_DL_Port failed: no valid response found (mAVU_8T8R_ORAN_Disable_DL_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Disable_DL_PortRsp._ret)

    def MAVU_8T8R_ORAN_Set_UL_IQ_Compression(self, cc_id, ss_id, iq_width, comp_method):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_UL_IQ_CompressionReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.iq_width = iq_width
        _req.comp_method = comp_method
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_UL_IQ_CompressionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_UL_IQ_CompressionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_UL_IQ_Compression failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_UL_IQ_Compression failed: no valid response found (mAVU_8T8R_ORAN_Set_UL_IQ_Compression)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_UL_IQ_CompressionRsp._ret)

    def MAVU_8T8R_ORAN_Enable_UL_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Enable_UL_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Enable_UL_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Enable_UL_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Enable_UL_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Enable_UL_Port failed: no valid response found (mAVU_8T8R_ORAN_Enable_UL_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Enable_UL_PortRsp._ret)

    def MAVU_8T8R_ORAN_Disable_UL_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Disable_UL_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Disable_UL_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Disable_UL_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Disable_UL_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Disable_UL_Port failed: no valid response found (mAVU_8T8R_ORAN_Disable_UL_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Disable_UL_PortRsp._ret)

    def MAVU_8T8R_ORAN_Set_PRACH_IQ_Compression(self, cc_id, ss_id, iq_width, comp_method):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_PRACH_IQ_CompressionReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _req.iq_width = iq_width
        _req.comp_method = comp_method
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_PRACH_IQ_CompressionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_PRACH_IQ_CompressionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_IQ_Compression failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_IQ_Compression failed: no valid response found (mAVU_8T8R_ORAN_Set_PRACH_IQ_Compression)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_PRACH_IQ_CompressionRsp._ret)

    def MAVU_8T8R_ORAN_Enable_PRACH_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Enable_PRACH_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Enable_PRACH_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Enable_PRACH_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Enable_PRACH_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Enable_PRACH_Port failed: no valid response found (mAVU_8T8R_ORAN_Enable_PRACH_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Enable_PRACH_PortRsp._ret)

    def MAVU_8T8R_ORAN_Disable_PRACH_Port(self, cc_id, ss_id):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Disable_PRACH_PortReq()
        _req.cc_id = cc_id
        _req.ss_id = ss_id
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Disable_PRACH_PortReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Disable_PRACH_PortRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Disable_PRACH_Port failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Disable_PRACH_Port failed: no valid response found (mAVU_8T8R_ORAN_Disable_PRACH_Port)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Disable_PRACH_PortRsp._ret)

    def MAVU_8T8R_ORAN_Clear_Stats(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Clear_StatsReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Clear_StatsReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Clear_StatsRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Clear_Stats failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Clear_Stats failed: no valid response found (mAVU_8T8R_ORAN_Clear_Stats)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Clear_StatsRsp._ret)

    def MAVU_8T8R_ORAN_Get_Stats(self, port):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_StatsReq()
        _req.port = port
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_StatsReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_StatsRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Stats failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Stats failed: no valid response found (mAVU_8T8R_ORAN_Get_Stats)")
        return self.Struct_oran_fhi_eth_stats_toDict(_rsp.mAVU_8T8R_ORAN_Get_StatsRsp.ptr), self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_StatsRsp._ret)

    def MAVU_8T8R_ORAN_Deinit(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_DeinitReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Deinit failed: no valid response found (mAVU_8T8R_ORAN_Deinit)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_DeinitRsp._ret)

    def MAVU_8T8R_ORAN_Get_Num_Eth_Ports(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_Num_Eth_PortsReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_Num_Eth_PortsReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_Num_Eth_PortsRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Num_Eth_Ports failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Num_Eth_Ports failed: no valid response found (mAVU_8T8R_ORAN_Get_Num_Eth_Ports)")
        return _rsp.mAVU_8T8R_ORAN_Get_Num_Eth_PortsRsp.num_eth_ports, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_Num_Eth_PortsRsp._ret)

    def MAVU_8T8R_ORAN_Get_Num_CC(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_Num_CCReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_Num_CCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_Num_CCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Num_CC failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Num_CC failed: no valid response found (mAVU_8T8R_ORAN_Get_Num_CC)")
        return _rsp.mAVU_8T8R_ORAN_Get_Num_CCRsp.num_cc, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_Num_CCRsp._ret)

    def MAVU_8T8R_ORAN_Get_Num_DL_SS(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_Num_DL_SSReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_Num_DL_SSReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_Num_DL_SSRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Num_DL_SS failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Num_DL_SS failed: no valid response found (mAVU_8T8R_ORAN_Get_Num_DL_SS)")
        return _rsp.mAVU_8T8R_ORAN_Get_Num_DL_SSRsp.num_dl_ss, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_Num_DL_SSRsp._ret)

    def MAVU_8T8R_ORAN_Get_Num_UL_SS(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_Num_UL_SSReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_Num_UL_SSReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_Num_UL_SSRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Num_UL_SS failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Num_UL_SS failed: no valid response found (mAVU_8T8R_ORAN_Get_Num_UL_SS)")
        return _rsp.mAVU_8T8R_ORAN_Get_Num_UL_SSRsp.num_ul_ss, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_Num_UL_SSRsp._ret)

    def MAVU_8T8R_ORAN_Get_Num_PRACH_SS(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Get_Num_PRACH_SSReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Get_Num_PRACH_SSReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Get_Num_PRACH_SSRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Get_Num_PRACH_SS failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Get_Num_PRACH_SS failed: no valid response found (mAVU_8T8R_ORAN_Get_Num_PRACH_SS)")
        return _rsp.mAVU_8T8R_ORAN_Get_Num_PRACH_SSRsp.num_prach_ss, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Get_Num_PRACH_SSRsp._ret)

    def MAVU_8T8R_ORAN_Buffer_Config_Get_Num_Sym(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Buffer_Config_Get_Num_SymReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Buffer_Config_Get_Num_SymReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Buffer_Config_Get_Num_SymRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_Num_Sym failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_Num_Sym failed: no valid response found (mAVU_8T8R_ORAN_Buffer_Config_Get_Num_Sym)")
        return _rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_Num_SymRsp.num_sym, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_Num_SymRsp._ret)

    def MAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_Sym(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_SymReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_SymReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_SymRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_Sym failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_Sym failed: no valid response found (mAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_Sym)")
        return _rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_SymRsp.cp_adv_sym, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_CP_Adv_SymRsp._ret)

    def MAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAM(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAMReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAMReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAMRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAM failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAM failed: no valid response found (mAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAM)")
        return _rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAMRsp.dl_up_uram, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_DL_UP_URAMRsp._ret)

    def MAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_Sym(self):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_SymReq()
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_SymReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_SymRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_Sym failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_Sym failed: no valid response found (mAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_Sym)")
        return _rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_SymRsp.dl_up_uram, self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Buffer_Config_Get_UL_CP_SymRsp._ret)

    def MAVU_8T8R_ORAN_Set_Num_CC(self, num_cc):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_Num_CCReq()
        _req.num_cc = num_cc
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_Num_CCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_Num_CCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_Num_CC failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_Num_CC failed: no valid response found (mAVU_8T8R_ORAN_Set_Num_CC)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_Num_CCRsp._ret)

    def MAVU_8T8R_ORAN_Set_DL_Offset(self, start_ts):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_DL_OffsetReq()
        _req.start_ts = start_ts
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_DL_OffsetReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_DL_OffsetRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_DL_Offset failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_DL_Offset failed: no valid response found (mAVU_8T8R_ORAN_Set_DL_Offset)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_DL_OffsetRsp._ret)

    def MAVU_8T8R_ORAN_Set_UL_Offset(self, start_ts):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_UL_OffsetReq()
        _req.start_ts = start_ts
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_UL_OffsetReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_UL_OffsetRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_UL_Offset failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_UL_Offset failed: no valid response found (mAVU_8T8R_ORAN_Set_UL_Offset)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_UL_OffsetRsp._ret)

    def MAVU_8T8R_ORAN_Set_PRACH_Offset(self, start_ts):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_PRACH_OffsetReq()
        _req.start_ts = start_ts
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_PRACH_OffsetReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_PRACH_OffsetRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_Offset failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_PRACH_Offset failed: no valid response found (mAVU_8T8R_ORAN_Set_PRACH_Offset)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_PRACH_OffsetRsp._ret)

    def MAVU_8T8R_ORAN_Set_CC_Config_SCS(self, cc_id, scs):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_CC_Config_SCSReq()
        _req.cc_id = cc_id
        _req.scs = scs
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_CC_Config_SCSReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_CC_Config_SCSRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_CC_Config_SCS failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_CC_Config_SCS failed: no valid response found (mAVU_8T8R_ORAN_Set_CC_Config_SCS)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_CC_Config_SCSRsp._ret)

    def MAVU_8T8R_ORAN_Set_DL_U_Plane_Config(self, cc_id, offset, block_size):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_DL_U_Plane_ConfigReq()
        _req.cc_id = cc_id
        _req.offset = offset
        _req.block_size = block_size
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_DL_U_Plane_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_DL_U_Plane_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_DL_U_Plane_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_DL_U_Plane_Config failed: no valid response found (mAVU_8T8R_ORAN_Set_DL_U_Plane_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_DL_U_Plane_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_Set_DL_C_Plane_Config(self, cc_id, offset, block_size):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_DL_C_Plane_ConfigReq()
        _req.cc_id = cc_id
        _req.offset = offset
        _req.block_size = block_size
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_DL_C_Plane_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_DL_C_Plane_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_DL_C_Plane_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_DL_C_Plane_Config failed: no valid response found (mAVU_8T8R_ORAN_Set_DL_C_Plane_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_DL_C_Plane_ConfigRsp._ret)

    def MAVU_8T8R_ORAN_Set_UL_C_Plane_Config(self, cc_id, offset, block_size):
        _req = liboran_pb2.MAVU_8T8R_ORAN_Set_UL_C_Plane_ConfigReq()
        _req.cc_id = cc_id
        _req.offset = offset
        _req.block_size = block_size
        _inMsg = liboran_pb2.liboranIn()
        _inMsg.mAVU_8T8R_ORAN_Set_UL_C_Plane_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liboran_pb2.liboranOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_ORAN_Set_UL_C_Plane_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_ORAN_Set_UL_C_Plane_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_ORAN_Set_UL_C_Plane_Config failed: no valid response found (mAVU_8T8R_ORAN_Set_UL_C_Plane_Config)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_ORAN_Set_UL_C_Plane_ConfigRsp._ret)

