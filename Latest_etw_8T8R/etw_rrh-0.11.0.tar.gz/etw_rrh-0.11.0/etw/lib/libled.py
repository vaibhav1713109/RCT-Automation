from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libled_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libledProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibled", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def initialiseLed(self, led, status):
        _req = libled_pb2.initialiseLedReq()
        _req.led = led
        _req.status = status
        _inMsg = libled_pb2.libledIn()
        _inMsg.initialiseLedReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libled_pb2.libledOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "initialiseLedRsp":
            if _rsp.zzerr_msg:
                raise EtwError("initialiseLed failed: " + _rsp.zzerr_msg)
            raise EtwError("initialiseLed failed: no valid response found (initialiseLed)")
        return _rsp.initialiseLedRsp._ret

    def deinitialiseLed(self):
        _req = libled_pb2.deinitialiseLedReq()
        _inMsg = libled_pb2.libledIn()
        _inMsg.deinitialiseLedReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libled_pb2.libledOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "deinitialiseLedRsp":
            if _rsp.zzerr_msg:
                raise EtwError("deinitialiseLed failed: " + _rsp.zzerr_msg)
            raise EtwError("deinitialiseLed failed: no valid response found (deinitialiseLed)")

    def generatePin(self, led):
        _req = libled_pb2.generatePinReq()
        _req.led = led
        _inMsg = libled_pb2.libledIn()
        _inMsg.generatePinReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libled_pb2.libledOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "generatePinRsp":
            if _rsp.zzerr_msg:
                raise EtwError("generatePin failed: " + _rsp.zzerr_msg)
            raise EtwError("generatePin failed: no valid response found (generatePin)")
        return _rsp.generatePinRsp._ret

    def set_Led(self, led, color):
        _req = libled_pb2.set_LedReq()
        _req.led = led
        _req.color = color
        _inMsg = libled_pb2.libledIn()
        _inMsg.set_LedReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libled_pb2.libledOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "set_LedRsp":
            if _rsp.zzerr_msg:
                raise EtwError("set_Led failed: " + _rsp.zzerr_msg)
            raise EtwError("set_Led failed: no valid response found (set_Led)")
        return _rsp.set_LedRsp._ret

