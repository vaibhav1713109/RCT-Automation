import os, time

class Lock:
    def __init__(self, lock_name, max_age_sec=30):
        self.lock_path = lock_name + '_lockdir'
        self.is_locked = False
        self.lock_time = 0.0
        self.max_age_sec = max_age_sec

    def try_get(self, break_if_expired = True):
        if self.is_locked:
            return True
        
        try:
            os.mkdir(self.lock_path)
            self.lock_time = os.path.getctime(self.lock_path)
            self.is_locked = True
            return True
        except FileExistsError as e:
            return False

    def validate(self):
        if self.is_locked:
            try:
                ct = os.path.getctime(self.lock_path)
                if ct != self.lock_time:
                    self.is_locked = False
            except Exception as e:
                self.is_locked = False
        return self.is_locked
    
    def expired(self):
        try:
            ct = os.path.getctime(self.lock_path)
            now = time.time()
            if ct < (now - self.max_age_sec):
                return True
            else:
                return False
        except Exception as e:
            return False

    def locked_by_other(self):
        if not self.is_locked and os.path.exists(self.lock_path):
            return True
        else:
            return False

    def break_lock(self):
        try:
            os.rmdir(self.lock_path)
        except FileNotFoundError as e:
            pass
        self.is_locked = False
        
    def release(self):
        if not (self.is_locked and os.path.exists(self.lock_path)):
            return False
        
        try:
            os.rmdir(self.lock_path)
        except FileNotFoundError as e:
            pass
        self.is_locked = False
        return True

    def wait_get(self, wait_time_sec=5):
        while not self.is_locked and wait_time_sec > 0:
            if not self.try_get():
                time.sleep(1)
                wait_time_sec -= 1
        return self.is_locked
