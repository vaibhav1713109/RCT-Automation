import sys

from threading import Thread
from typing import Any, Dict
from os import listdir, stat, mkdir, getcwd, environ
from os.path import split, isfile, join
from time import sleep
from etw.lib.board_pb2 import SwImageStatus, SwImageState

class SwMgr:
    """
    Sw Manager class.

    """
    def __init__(self, etw_proxy=None, board_proxy=None):
        if etw_proxy is None:
            try:
                etw_proxy = self.etw_proxy
            except:
                etw_proxy = self
        self.etw_proxy = etw_proxy
            
        if board_proxy is None:
            try:
                board_proxy = self.board_proxy
            except:
                board_proxy = self
        self.board_proxy = board_proxy

    def connect(self):
        self.etw_proxy.connect()
        
    def update_sw(self, sw_path: str, sw_slot: int, wait_result: bool = False, activate: bool = True):
        def install_activate():
            install_result = \
                self.install_sw_image(file_path, sw_slot, wait_result=True)
            if not install_result.succeed:
                return install_result
            if activate:
                activated = \
                    self.set_sw_image_status(sw_slot=sw_slot, activate=True)
                return activated
            return Result()

        file_path = self.download_file(client_path=sw_path)
        if wait_result:
            install_activate()
        else:
            instalation = Thread(target=install_activate)
            instalation.start()

    def upload_file(self, target_path: str, client_path: str = None) -> str:
        _, file_name = split(target_path)
        addr, len = self.etw_proxy.loadFileToBuf(target_path)
        data = self.etw_proxy.readFromBuf(addr, len)
        self.etw_proxy.freeBuf(addr)
        if client_path:
            if isfile(client_path):
                file_path = client_path
            else:
                file_path = join(client_path, file_name)
        else:
            client_path = getcwd()
            file_path = join(client_path, file_name)
        with open(file_path, 'wb') as file:
            file.write(data)
        return file_path

    def download_file(
            self, client_path: str, target_path: str = None,
            force_save: bool = True, safe_file: bool = False) -> str:
        def file_exists():
            target_dir, file = split(target_path)
            list_command = f'ls -l {target_dir} | egrep -v "^d"'
            exit_code, output = self.etw_proxy.execCmd(list_command)
            files_names = []
            files_rows = [row.strip() for row in output.split('\n')]
            for row in files_rows:
                if row and not row.lower().startswith('total'):
                    files_names.append(row.split(' ')[-1])
            return file in files_names
        if target_path is None:
            _, file_name = split(client_path)
            target_path = '/tmp/' + file_name
        if not force_save:
            if file_exists():
                raise EtwError('File already exist on target')
        image_size = stat(client_path).st_size
        buffer_addr = self.etw_proxy.allocBuf(image_size)
        with open(client_path, 'rb') as image:
            num_bytes = self.etw_proxy.writeToBuf(buffer_addr, image.read())
        if safe_file:
            self.etw_proxy.execCmd('chmod', params=f'-f 644 {target_path}')
            self.etw_proxy.saveBufToFile(target_path, buffer_addr, num_bytes)
            self.etw_proxy.execCmd('chmod', params=f'444 {target_path}')
        else:
            self.etw_proxy.saveBufToFile(target_path, buffer_addr, num_bytes)
        self.etw_proxy.freeBuf(buffer_addr)
        return target_path

    def install_sw_image(self, target_path: str, sw_slot: int, wait_result: bool = False):
        """
        Install a downloaded SW image into a SW slot in flash memory on the target

        :param target_path: The path to the file name on the target machine
            (e.g. /tmp/boot.bin)
        :type target_path: str
        :param sw_slot: The SW slot in flash memory where the image shall be
            installed (0..1)
        :type sw_slot: int
        :param wait_result: Wait for result
        :type wait_result: bool, optional
        :rtype: _common.Result
        """
        def progress(i):
            if i == 0:
                sys.stdout.write('SW Upgrade in Progress')
            if not i % 5:
                sys.stdout.write('.')
                sys.stdout.flush()

        self.board_proxy.updateSwImage(image_id=sw_slot,
                                       filename=target_path)
        if wait_result:
            in_progress = True
            iteration=0
            while in_progress:
                progress(iteration)
                sleep(2)
                sw_info = self.sw_info
                in_progress = sw_info.get('sw_upgrade_in_progress', False)
                iteration += 1

    def set_sw_image_status(self, sw_slot: int, status: str = None, activate: bool = False):
        """
        Mark which SW slot shall be used at next reboot and which SW slot is
        valid or invalid

        :param sw_slot: The SW slot in flash memory where the image shall be
            installed (0..1)
        :type sw_slot: int
        :param status: Set status for the image. Acceptable values is:
            invalid, unverified, verified, failed. Default value is None
        :type status: str, optional
        :param activate: Set to true if the image shall be activated and used
            for next restart. False means it will be used as backup
            (if it is valid). False is default value
        :type activate: bool, optional
        :rtype: _common.Result
        """
        if status is not None:
            self.board_proxy.setSwImageStatus(sw_slot, status)
        if activate:
            self.board_proxy.setActiveSwImageIndex(sw_slot)

    @property
    def sw_info(self) -> Dict[str, Any]:
        """
        Get information about installed and running SW

        :return: Software info
        :rtype: dict
        """
        sw = self.board_proxy.getSwStatus()
        info = {'running_image_index': sw.running_image_index,
                'image_to_run': sw.image_to_run,
                'sw_upgrade_in_progress': sw.sw_upgrade_in_progress,
                'sw_upgrade_result': sw.sw_upgrade_result,
                'image_info': {}
                }
        for image in sw.sw_images:
            info['image_info'][image.sw_image_index] = \
                {'version': image.version,
                 'status': SwImageStatus.Name(image.status),
                 'state': SwImageState.Name(image.state)}
        return info

