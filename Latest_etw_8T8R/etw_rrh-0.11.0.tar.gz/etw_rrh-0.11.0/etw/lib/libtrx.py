from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libtrx_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libtrxProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibtrx", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = libtrx_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def MAVU_8T8R_TRx_Control_Init(self):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_InitReq()
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_Init failed: no valid response found (mAVU_8T8R_TRx_Control_Init)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_InitRsp._ret)

    def MAVU_8T8R_TRx_Control_SetTxLnaEnable(self, port_pair, enableDisable):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetTxLnaEnableReq()
        _req.port_pair = port_pair
        _req.enableDisable = enableDisable
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetTxLnaEnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetTxLnaEnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetTxLnaEnable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetTxLnaEnable failed: no valid response found (mAVU_8T8R_TRx_Control_SetTxLnaEnable)")

    def MAVU_8T8R_TRx_Control_SetRxLnaEnable(self, port_pair, enableDisable):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetRxLnaEnableReq()
        _req.port_pair = port_pair
        _req.enableDisable = enableDisable
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetRxLnaEnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetRxLnaEnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetRxLnaEnable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetRxLnaEnable failed: no valid response found (mAVU_8T8R_TRx_Control_SetRxLnaEnable)")

    def MAVU_8T8R_TRx_Control_SetORxLnaEnable(self, port, enableDisable):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetORxLnaEnableReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetORxLnaEnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetORxLnaEnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetORxLnaEnable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetORxLnaEnable failed: no valid response found (mAVU_8T8R_TRx_Control_SetORxLnaEnable)")

    def MAVU_8T8R_TRx_Control_SetTxDsaAtten(self, port, atten):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetTxDsaAttenReq()
        _req.port = port
        _req.atten = atten
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetTxDsaAttenReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetTxDsaAttenRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetTxDsaAtten failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetTxDsaAtten failed: no valid response found (mAVU_8T8R_TRx_Control_SetTxDsaAtten)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetTxDsaAttenRsp._ret)

    def MAVU_8T8R_TRx_Control_SetRxDsaAtten(self, port, atten):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetRxDsaAttenReq()
        _req.port = port
        _req.atten = atten
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetRxDsaAttenReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetRxDsaAttenRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetRxDsaAtten failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetRxDsaAtten failed: no valid response found (mAVU_8T8R_TRx_Control_SetRxDsaAtten)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetRxDsaAttenRsp._ret)

    def MAVU_8T8R_TRx_Control_SetORxDsaAtten(self, port, atten):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetORxDsaAttenReq()
        _req.port = port
        _req.atten = atten
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetORxDsaAttenReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetORxDsaAttenRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetORxDsaAtten failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetORxDsaAtten failed: no valid response found (mAVU_8T8R_TRx_Control_SetORxDsaAtten)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetORxDsaAttenRsp._ret)

    def MAVU_8T8R_TRx_Control_SetSwitchManager(self, managerSelect):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetSwitchManagerReq()
        _req.managerSelect = managerSelect
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetSwitchManagerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetSwitchManagerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetSwitchManager failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetSwitchManager failed: no valid response found (mAVU_8T8R_TRx_Control_SetSwitchManager)")

    def MAVU_8T8R_TRx_Control_GetSwitchManager(self):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_GetSwitchManagerReq()
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_GetSwitchManagerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_GetSwitchManagerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_GetSwitchManager failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_GetSwitchManager failed: no valid response found (mAVU_8T8R_TRx_Control_GetSwitchManager)")
        return _rsp.mAVU_8T8R_TRx_Control_GetSwitchManagerRsp._ret

    def MAVU_8T8R_TRx_Control_SetBfCalSpdtSwitch(self, opMode):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetBfCalSpdtSwitchReq()
        _req.opMode = opMode
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetBfCalSpdtSwitchReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetBfCalSpdtSwitchRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetBfCalSpdtSwitch failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetBfCalSpdtSwitch failed: no valid response found (mAVU_8T8R_TRx_Control_SetBfCalSpdtSwitch)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetBfCalSpdtSwitchRsp._ret)

    def MAVU_8T8R_TRx_Control_SetBfCalSp3tSwitch(self, opMode):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetBfCalSp3tSwitchReq()
        _req.opMode = opMode
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetBfCalSp3tSwitchReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetBfCalSp3tSwitchRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetBfCalSp3tSwitch failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetBfCalSp3tSwitch failed: no valid response found (mAVU_8T8R_TRx_Control_SetBfCalSp3tSwitch)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetBfCalSp3tSwitchRsp._ret)

    def MAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitch(self, opMode):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitchReq()
        _req.opMode = opMode
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitchReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitchRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitch failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitch failed: no valid response found (mAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitch)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetORxBfCalSpdtSwitchRsp._ret)

    def MAVU_8T8R_TRx_Control_SetRxLNA(self, port, enableDisable):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetRxLNAReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetRxLNAReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetRxLNARsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetRxLNA failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetRxLNA failed: no valid response found (mAVU_8T8R_TRx_Control_SetRxLNA)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetRxLNARsp._ret)

    def MAVU_8T8R_TRx_Control_SetRxAgc_DSA(self, port, atten):
        _req = libtrx_pb2.MAVU_8T8R_TRx_Control_SetRxAgc_DSAReq()
        _req.port = port
        _req.atten = atten
        _inMsg = libtrx_pb2.libtrxIn()
        _inMsg.mAVU_8T8R_TRx_Control_SetRxAgc_DSAReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtrx_pb2.libtrxOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_TRx_Control_SetRxAgc_DSARsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_TRx_Control_SetRxAgc_DSA failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_TRx_Control_SetRxAgc_DSA failed: no valid response found (mAVU_8T8R_TRx_Control_SetRxAgc_DSA)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_TRx_Control_SetRxAgc_DSARsp._ret)

