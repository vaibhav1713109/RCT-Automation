from etw.lib.etwproxy import EtwError
import pandas as pd

class TestSignal:
    def __init__(self, signal_data = None, signal_file = None, format=None, sampleType='data_32bit'):
        if sampleType != 'data_32bit':
            raise EtwError("not supported sample type: " + str(sampleType))
        sources = signal_data is not None
        sources += signal_file is not None
        if sources > 1:
            raise EtwError("only one signal source allowed")

        if signal_data is not None:
            self.data = bytearray(signal_data)
        elif signal_file is not None:
            if format is None:
                if signal_file.endswith('.bin'):
                    format = 'bin'
                else:
                    format = 'dec'
            if format == 'dec':
                self.from_dec_file(signal_file)
            elif format == 'bin':
                self.from_bin_file(signal_file)
            else:
                raise EtwError("illegal signal file format: " + str(format))
        else:
            self.data = bytearray()

    def from_i_q(self, i_values, q_values = None):
        self.data = bytearray()
        if q_values is None:
            q_values = [0] * len(i_values)
        value = 0
        for n in range(len(i_values)):
            i = i_values[n]
            q = q_values[n]
            value = (value >> 32) & 0xffffffff
            value |= ((q & 0xffff) << 48) | ((i & 0xffff) << 32)
            if n % 2:
                self.data += value.to_bytes(8, 'little')
                value = 0
            
    def from_i_q_c(self, i_values, q_values = None, c_values = None):
        if c_values is not None:
            raise EtwError("control values supported")
        return self.from_i_q(i_values, q_values)
            
    def to_bytes(self, format='ddr', sampleType = "data_32bit"):
        if format != 'ddr':
            raise EtwError("not supported format: " + str(format))
        if sampleType != 'data_32bit':
            raise EtwError("not supported sample type: " + str(sampleType))
        return bytes(self.data)

    def to_u64_array(self):
        # Convert data to u64 array
        result = []
        length = int(len(self.data) / 8)

        for i in range(length):
            v = 0
            for j in range (8):
                v = v | (self.data[i*8+j] << (j*8))

            # Extract I/Q samples and remove control info
            q1 = (v >> 52) & 0xffff
            i1 = (v >> 36) & 0xffff
            q0 = (v >> 16) & 0xffff
            i0 = (v >> 0) & 0xffff
            v = (q1 << 48) | (i1 << 32) | (q0 << 16) | (i0 << 0)
            result.append(v)
        return result

    def to_s16(self, v):
        return (v & 0x7fff) - (v & 0x8000)
    
    def to_i_q(self):
        i_val = []
        q_val = []
        data_len = int(len(self.data) / 4)
        for i in range(data_len):
            i_val.append(self.to_s16(self.data[i*4 + 0] + (self.data[i*4 + 1] << 8)));
            q_val.append(self.to_s16(self.data[i*4 + 2] + (self.data[i*4 + 3] << 8)));
        return i_val, q_val
    
    def to_i_q_c(self):
        i, q = self.to_i_q()
        return i, q, [0]*len(i)
    
    def from_dec_file(self, filename):
        data = pd.read_csv(filename, delim_whitespace=True, header=None)
        self.data = bytearray()
        value = 0
        for index, i, q in data.itertuples(name=None):
            value = (value >> 32) & 0xffffffff
            value |= ((q & 0xffff) << 48) | ((i & 0xffff) << 32)
            if index % 2:
                self.data += value.to_bytes(8, 'little')
                value = 0

    def from_bin_file(self, filename):
        infile = open(filename, "rb")
        self.data = bytearray(infile.read())
        
    def to_string_list(self):
        i, q = self.to_i_q()
        result = []
        for x in range(len(i)):
            result.append(f'i={i[x]}, q={q[x]}')
        return result

