from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libqpam_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libqpamProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibqpam", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = libqpam_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def current_monitorType_fromDict(self, dict):
        x = libqpam_pb2.current_monitorType()
        if not dict: return x
        setattr(x, "Driver_Main_Amplifier", dict.get("Driver_Main_Amplifier", 0))
        setattr(x, "Final_Main_Amplifier", dict.get("Final_Main_Amplifier", 0))
        return x

    def PA_BiasType_fromDict(self, dict):
        x = libqpam_pb2.PA_BiasType()
        if not dict: return x
        setattr(x, "Pre_driver", dict.get("Pre_driver", 0))
        setattr(x, "Driver_Main_Amplifier", dict.get("Driver_Main_Amplifier", 0))
        setattr(x, "Driver_Peaking_Amplifier", dict.get("Driver_Peaking_Amplifier", 0))
        setattr(x, "Final_Main_Amplifier_1", dict.get("Final_Main_Amplifier_1", 0))
        setattr(x, "Final_Main_Amplifier_2", dict.get("Final_Main_Amplifier_2", 0))
        setattr(x, "Final_Peaking_Amplifier_1", dict.get("Final_Peaking_Amplifier_1", 0))
        setattr(x, "Final_Peaking_Amplifier_2", dict.get("Final_Peaking_Amplifier_2", 0))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def current_monitorType_toDict(self, v):
        dict = {}
        dict["Driver_Main_Amplifier"] = getattr(v, "Driver_Main_Amplifier")
        dict["Final_Main_Amplifier"] = getattr(v, "Final_Main_Amplifier")
        return dict

    def PA_BiasType_toDict(self, v):
        dict = {}
        dict["Pre_driver"] = getattr(v, "Pre_driver")
        dict["Driver_Main_Amplifier"] = getattr(v, "Driver_Main_Amplifier")
        dict["Driver_Peaking_Amplifier"] = getattr(v, "Driver_Peaking_Amplifier")
        dict["Final_Main_Amplifier_1"] = getattr(v, "Final_Main_Amplifier_1")
        dict["Final_Main_Amplifier_2"] = getattr(v, "Final_Main_Amplifier_2")
        dict["Final_Peaking_Amplifier_1"] = getattr(v, "Final_Peaking_Amplifier_1")
        dict["Final_Peaking_Amplifier_2"] = getattr(v, "Final_Peaking_Amplifier_2")
        return dict

    def MAVU_8T8R_QPAM_MaxChip_Control_Init(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_MaxChip_Control_InitReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_MaxChip_Control_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_MaxChip_Control_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_MaxChip_Control_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_MaxChip_Control_Init failed: no valid response found (mAVU_8T8R_QPAM_MaxChip_Control_Init)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_MaxChip_Control_InitRsp._ret)

    def MAVU_8T8R_QPAM1_Setdefault_Bias_voltage(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM1_Setdefault_Bias_voltageReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM1_Setdefault_Bias_voltageReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM1_Setdefault_Bias_voltageRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM1_Setdefault_Bias_voltage failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM1_Setdefault_Bias_voltage failed: no valid response found (mAVU_8T8R_QPAM1_Setdefault_Bias_voltage)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM1_Setdefault_Bias_voltageRsp._ret)

    def MAVU_8T8R_QPAM2_Setdefault_Bias_voltage(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM2_Setdefault_Bias_voltageReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM2_Setdefault_Bias_voltageReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM2_Setdefault_Bias_voltageRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM2_Setdefault_Bias_voltage failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM2_Setdefault_Bias_voltage failed: no valid response found (mAVU_8T8R_QPAM2_Setdefault_Bias_voltage)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM2_Setdefault_Bias_voltageRsp._ret)

    def MAVU_8T8R_QPAM_Control_SetTxKey(self, port, enableDisable):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetTxKeyReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetTxKeyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetTxKeyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetTxKey failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetTxKey failed: no valid response found (mAVU_8T8R_QPAM_Control_SetTxKey)")

    def MAVU_8T8R_QPAM_Control_SetRxKey(self, port, enableDisable):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetRxKeyReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetRxKeyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetRxKeyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetRxKey failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetRxKey failed: no valid response found (mAVU_8T8R_QPAM_Control_SetRxKey)")

    def MAVU_8T8R_QPAM_Control_SetPaVdd(self, qpamID, enableDisable):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetPaVddReq()
        _req.qpamID = qpamID
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetPaVddReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetPaVddRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetPaVdd failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetPaVdd failed: no valid response found (mAVU_8T8R_QPAM_Control_SetPaVdd)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_SetPaVddRsp._ret)

    def MAVU_8T8R_QPAM_Control_SetTddMode(self, qpamID, mode):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetTddModeReq()
        _req.qpamID = qpamID
        _req.mode = mode
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetTddModeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetTddModeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetTddMode failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetTddMode failed: no valid response found (mAVU_8T8R_QPAM_Control_SetTddMode)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_SetTddModeRsp._ret)

    def MAVU_8T8R_QPAM_Control_SetORxMuxCtrl(self, port, fwdRev):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetORxMuxCtrlReq()
        _req.port = port
        _req.fwdRev = fwdRev
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetORxMuxCtrlReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetORxMuxCtrlRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetORxMuxCtrl failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetORxMuxCtrl failed: no valid response found (mAVU_8T8R_QPAM_Control_SetORxMuxCtrl)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_SetORxMuxCtrlRsp._ret)

    def MAVU_8T8R_QPAM_Control_PASetOn(self, port):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_PASetOnReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_PASetOnReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_PASetOnRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_PASetOn failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_PASetOn failed: no valid response found (mAVU_8T8R_QPAM_Control_PASetOn)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_PASetOnRsp._ret)

    def MAVU_8T8R_QPAM_Control_PASetOff(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_PASetOffReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_PASetOffReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_PASetOffRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_PASetOff failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_PASetOff failed: no valid response found (mAVU_8T8R_QPAM_Control_PASetOff)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_PASetOffRsp._ret)

    def MAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltage(self, port):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltageReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltageReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltageRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltage failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltage failed: no valid response found (mAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltage)")
        return self.current_monitorType_toDict(_rsp.mAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltageRsp.Current_Mon), self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_GetPaCurrentMonitorVoltageRsp._ret)

    def MAVU_8T8R_QPAM_Control_SetPaBias(self, port):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_SetPaBiasReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_SetPaBiasReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_SetPaBiasRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_SetPaBias failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_SetPaBias failed: no valid response found (mAVU_8T8R_QPAM_Control_SetPaBias)")
        return self.PA_BiasType_toDict(_rsp.mAVU_8T8R_QPAM_Control_SetPaBiasRsp.PA_Bias_voltage), self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_SetPaBiasRsp._ret)

    def MAVU_8T8R_QPAM_Control_GetPaBias(self, port):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_GetPaBiasReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_GetPaBiasReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_GetPaBiasRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_GetPaBias failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_GetPaBias failed: no valid response found (mAVU_8T8R_QPAM_Control_GetPaBias)")
        return self.PA_BiasType_toDict(_rsp.mAVU_8T8R_QPAM_Control_GetPaBiasRsp.PA_Bias_voltage), self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_GetPaBiasRsp._ret)

    def MAVU_8T8R_QPAM_Control_TxPortReadTemp(self, port):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_TxPortReadTempReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_TxPortReadTempReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_TxPortReadTempRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_TxPortReadTemp failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_TxPortReadTemp failed: no valid response found (mAVU_8T8R_QPAM_Control_TxPortReadTemp)")
        return _rsp.mAVU_8T8R_QPAM_Control_TxPortReadTempRsp.TempData, self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_TxPortReadTempRsp._ret)

    def MAVU_8T8R_QPAM_Control_GetPaBiasStepSize(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_GetPaBiasStepSizeReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_GetPaBiasStepSizeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_GetPaBiasStepSizeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_GetPaBiasStepSize failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_GetPaBiasStepSize failed: no valid response found (mAVU_8T8R_QPAM_Control_GetPaBiasStepSize)")
        return _rsp.mAVU_8T8R_QPAM_Control_GetPaBiasStepSizeRsp._ret

    def MAVU_8T8R_QPAM_Control_HasPaCurrentMonitor(self):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_HasPaCurrentMonitorReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_HasPaCurrentMonitorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_HasPaCurrentMonitorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_HasPaCurrentMonitor failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_HasPaCurrentMonitor failed: no valid response found (mAVU_8T8R_QPAM_Control_HasPaCurrentMonitor)")
        return _rsp.mAVU_8T8R_QPAM_Control_HasPaCurrentMonitorRsp.paCurrentMontiorExist, self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_HasPaCurrentMonitorRsp._ret)

    def MAVU_8T8R_QPAM_Control_MAX11300_SPI_Write(self, portSelect, address, writeData):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_MAX11300_SPI_WriteReq()
        _req.portSelect = portSelect
        _req.address = address
        _req.writeData = writeData
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_MAX11300_SPI_WriteReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_MAX11300_SPI_WriteRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_MAX11300_SPI_Write failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_MAX11300_SPI_Write failed: no valid response found (mAVU_8T8R_QPAM_Control_MAX11300_SPI_Write)")
        return self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_MAX11300_SPI_WriteRsp._ret)

    def MAVU_8T8R_QPAM_Control_MAX11300_SPI_Read(self, portSelect, address):
        _req = libqpam_pb2.MAVU_8T8R_QPAM_Control_MAX11300_SPI_ReadReq()
        _req.portSelect = portSelect
        _req.address = address
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.mAVU_8T8R_QPAM_Control_MAX11300_SPI_ReadReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_QPAM_Control_MAX11300_SPI_ReadRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_QPAM_Control_MAX11300_SPI_Read failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_QPAM_Control_MAX11300_SPI_Read failed: no valid response found (mAVU_8T8R_QPAM_Control_MAX11300_SPI_Read)")
        return _rsp.mAVU_8T8R_QPAM_Control_MAX11300_SPI_ReadRsp.pReadData, self.returnStatusType_toDict(_rsp.mAVU_8T8R_QPAM_Control_MAX11300_SPI_ReadRsp._ret)

