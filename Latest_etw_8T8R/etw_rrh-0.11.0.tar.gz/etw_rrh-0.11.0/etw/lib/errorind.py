from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import errorind_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class errorindProxy:
    def __init__(self, ipcLink, service_name = "common"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "common", method_call="Method")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def ErrorInd_fromDict(self, dict):
        x = errorind_pb2.ErrorInd()
        if not dict: return x
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def ErrorInd_toDict(self, v):
        dict = {}
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

