from etw.lib.etwproxy import EtwProxy, EtwError
from etw.lib.swmgr import SwMgr
from etw.lib.board import BoardProxy

class BoardMgr(EtwProxy, BoardProxy, SwMgr):
    def __init__(self, target):
        EtwProxy.__init__(self, target.ip_address, target.port)
        BoardProxy.__init__(self)
        SwMgr.__init__(self)

    def connect(self):
        EtwProxy.connect(self)

    def cold_reset(self):
        raise EtwError("cold_reset still not implemented")
        
    def power_cycle_reset(self):
        raise EtwError("power_cycle_reset still not implemented")
