from etw.lib.etwproxy import EtwProxy, EtwError

class Gpio():
    def __init__(self, proxy, name, pinNo, direction = None, value=None):
        self.name = name
        self.pinNo = pinNo
        self.direction = direction
        self.gpioDir = "/sys/class/gpio/"
        self.pinDevName = "gpio" + str(self.pinNo)
        self.pinDir = self.gpioDir + self.pinDevName + "/"
        self.proxy = proxy
        cmds = []
        cmds.append("echo '" + str(self.pinNo) + "' > " + self.gpioDir + "export")
        if self.direction == 'in':
            cmds.append("echo 'in' > " + self.pinDir + "direction")
        elif self.direction == 'out':
            if value == 0 or value == 'low':
                cmds.append("echo 'low' > " + self.pinDir + "direction")
            elif value == 1 or value == 'high':
                cmds.append("echo 'high' > " + self.pinDir + "direction")
                
        for cmd in cmds:
            # print("Exeute: %s" % (cmd))
            exit_code, output = self.proxy.execCmd(cmd, " 2>&1")
            
        if self.direction == 'out' and value == None:
            self.direction = self.get_direction()

    def set_value(self, value):
        cmd = "echo '" + str(value) + "' > " + self.pinDir + "value"
        exit_code, output = self.proxy.execCmd(cmd, "")

    def get_value(self):
        try:
            cmd = "cat " + self.pinDir + "value"
            exit_code, output = self.proxy.execCmd(cmd, "")
            return int(output)
        except:
            return None
        
    def get_direction(self):
        try:
            cmd = "cat " + self.pinDir + "direction"
            exit_code, output = self.proxy.execCmd(cmd, "")
            return output
        except:
            return None

class GpioMgr():
    def __init__(self, base, proxy = None, target = None):
        self.io_pins = {}
        self.base = base
        self.proxy = None
        if proxy:
            self.proxy = proxy
        elif target is not None:
            self.proxy = EtwProxy(target.ip_address, target.port)
            self.proxy.connect()

    def output_pin(self, name, pin_no, value=None):
        gpio = self.io_pins.get(name)
        if not gpio:
            gpio = Gpio(self.proxy, name, self.base + pin_no, "out", value)
            self.io_pins[name] = gpio
        return gpio

    def input_pin(self, name, pin_no):
        gpio = self.io_pins.get(name)
        if not gpio:
            gpio = Gpio(self.proxy, name, self.base + pin_no, "in")
            self.io_pins[name] = gpio
        return gpio

