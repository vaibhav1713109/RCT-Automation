import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time
import subprocess as sp
from etw.scripts import rrh_set_trx_ctrl
from etw.scripts import rrh_set_qpam_ctrl

def board_init(ipcLink=None):
    rrh_set_trx_ctrl.main(ipcLink,['-i'])

    for qpamId in range(rrh_dfe.NUM_OF_QPAM):    
        rrh_set_qpam_ctrl.main(ipcLink,['-i',f'-q {qpamId}'])

def tx_init(ipcLink=None):
    # TRX and QPAM board init
    board_init(ipcLink)

    # tx ports reset
    switch_tx_all_off(ipcLink)

    # 1b) Set 15dB as Tx Quad DSA attenuation and apply
    print(f'1b)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-a 1',f'-p {port}','-v 15'])

    # 1c) For TX1 path make "BF_CAL_SPDT_CTRL" to Normal TX.
    print(f'1c)')
    rrh_set_trx_ctrl.main(ipcLink,['-b 1','-o 2'])

    # 1f) Make QPAM TX_RXN signal as Tx mode(3.3V)
    print(f'1f)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        rrh_set_qpam_ctrl.main(ipcLink,['-t',f'-q {qpamId}','-o 1'])


    # 1g) RX_KEY signal should be driven Logic 1 (disable) from RFSoc During Tx operation
    print(f'1g)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-d 2',f'-p {port}'])

    
def switch_tx_port_on(port,ipcLink=None):
    print(f'==== Turning ON TX path for TRX and QPAM on port {port}. ====\n')

    # 1i) Set bias volatges
    #      Port 0,1,9,10    -4.3V  (PA Peak)
    #      Port 2,11        -4.2V  (Driver Peak)
    #      Port 3,12        -1.8V  (Pre driver)
    #      Port 4,13        -2.54V (Driver main)
    #      Port 6,7,15,16   -2.90V (PA Main)
    print(f'1i)')
    rrh_set_qpam_ctrl.main(ipcLink,['-s 1',f'-p {port}','-b -1.8 -2.54 -4.2 -2.9 -2.9 -4.3 -4.3'])
    time.sleep(1)

    # 1h) Make QPAM PA_VDD_EN signal as Enable
    print(f'1h)')
    qpamId = port >> 2
    ret = rrh_set_qpam_ctrl.main(ipcLink,['-v 1',f'-q {qpamId}'])

    if ret.returncode != 0:
        return

    # 1e) Make QPAM TX_KEY_1,TX_KEY_2, TX_KEY_3, TX_KEY_4 signals Enable (High State)
    print(f'1e)')
    rrh_set_qpam_ctrl.main(ipcLink,['-e 1',f'-p {port}'])


    # 1j) Make TX ports "ON"
    port_pair = port >> 1
    print(f'1j)')
    rrh_set_trx_ctrl.main(ipcLink,['-e 1',f'-p {port_pair}'])

def switch_tx_port_off(port,ipcLink=None):
    print(f'==== Turning OFF TX path for TRX and QPAM on port {port}. ====\n')

    # 2d) Make QPAM TX_KEY_1, TX_KEY_2, TX_KEY_3, TX_KEY_4 signals disable (Low state)
    print(f'2d)')
    rrh_set_qpam_ctrl.main(ipcLink,['-d 1 ',f'-p {port}'])


    # 1a) & 2c) Set QPAM PA_VDD_EN signal as disable
    # Skip this since the other ports in same QPAM might be alive

    # 1i) Set bias volatges
    #      Port 0,1,9,10    -8V  (PA Peak)
    #      Port 2,11        -8V  (Driver Peak)
    #      Port 3,12        -8V  (Pre driver)
    #      Port 4,13        -8V (Driver main)
    #      Port 6,7,15,16   -8V (PA Main)
    print(f'1i) but reset default bias')
    rrh_set_qpam_ctrl.main(ipcLink,['-s 1',f'-p {port}','-b -8 -8 -8 -8 -8 -8 -8'])


    # 2a) Make TX ports "OFF"
    # Skip this since the peer port might be alive

def switch_tx_all_on(ipcLink=None):
    print(f'==== Turning ON TX path for TRX and QPAM on all ports. ====\n')

    # 1i) Set bias volatges
    #      Port 0,1,9,10    -4.3V  (PA Peak)
    #      Port 2,11        -4.2V  (Driver Peak)
    #      Port 3,12        -1.8V  (Pre driver)
    #      Port 4,13        -2.54V (Driver main)
    #      Port 6,7,15,16   -2.90V (PA Main)
    print(f'1i)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-s 1',f'-p {port}','-b -1.8 -2.54 -4.2 -2.9 -2.9 -4.3 -4.3'])

    time.sleep(1)

    # 1h) Make QPAM PA_VDD_EN signal as Enable
    print(f'1h)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        ret = rrh_set_qpam_ctrl.main(ipcLink,['-v 1',f'-q {qpamId}'])
        if ret.returncode != 0:
            return

    # 1e) Make QPAM TX_KEY_1,TX_KEY_2, TX_KEY_3, TX_KEY_4 signals Enable (High State)
    print(f'1e)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-e 1',f'-p {port}'])

    # 1j) Make TX ports "ON"
    num_port_pair = int(rrh_dfe.NUM_OF_TX_PORTS/2)
    print(f'1j)')
    for port_pair in range(num_port_pair):
        rrh_set_trx_ctrl.main(ipcLink,['-e 1',f'-p {port_pair}'])

def switch_tx_all_off(ipcLink=None):
    print(f'==== Turning OFF TX path for TRX and QPAM on all ports. ====\n')
    # 2a) Make TX ports "OFF"
    num_port_pair = int(rrh_dfe.NUM_OF_TX_PORTS/2)
    print(f'2a)')
    for port_pair in range(num_port_pair):
        rrh_set_trx_ctrl.main(ipcLink,['-d 1',f'-p {port_pair}'])

    # 1a) & 2c) Set QPAM PA_VDD_EN signal as disable
    print(f'1a) & 2c)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        rrh_set_qpam_ctrl.main(ipcLink,['-v 0',f'-q {qpamId}'])

    # 1d) & 2b) Configure the Max bias and set -8v default at all DAC ports for both Maxim ICs in the QPAM
    print(f'1d) & 2b)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        rrh_set_qpam_ctrl.main(ipcLink,['-s 0',f'-q {qpamId}'])

    # 2d) Make QPAM TX_KEY_1, TX_KEY_2, TX_KEY_3, TX_KEY_4 signals disable (Low state)
    print(f'2d)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-d 1',f'-p {port}'])

def switch_rx_on(ipcLink=None):
    print(f'==== Turning ON RX paths for TRX and QPAM. ====\n')

    # a) Set 0dB as Rx Quad DSA attenuation and apply
    print(f'a)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-a 2',f'-p {port}','-v 0'])

    # b) Set Rx1-4 AGC Trigger 1 and 2 signals for 0dB attenuation
    print(f'b)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-a 4',f'-p {port}','-v 0'])

    # c) Make QPAM TX_KEY_1, TX_KEY_2, TX_KEY_3, TX_KEY_4 signals Disable
    print(f'c)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-d 1 ',f'-p {port}'])
        
    # d) Make QPAM TX_RXN signal as Rx mode(0V)
    print(f'd)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        rrh_set_qpam_ctrl.main(ipcLink,['-t',f'-q {qpamId}','-o 2'])

    # e) Make QPAM RX_KEY_1, RX_KEY_2, RX_KEY_3, RX_KEY_4 signals Enable (low state)
    print(f'e)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-e 2',f'-p {port}'])

    # f) Set Rx1 ON/OFF, Rx2 ON/OFF,Rx3 ON/OFF,Rx4 ON/OFF,signals to ON
    num_port_pair = int(rrh_dfe.NUM_OF_RX_PORTS/2)
    print(f'f)')
    for port_pair in range(num_port_pair):
        rrh_set_trx_ctrl.main(ipcLink,['-e 2',f'-p {port_pair}'])

    # g) Set Rx1 LNA2 Enable,Rx2 LNA2 Enable,Rx3 LNA2 Enable,Rx4 LNA2 Enable signals to ON
    print(f'g)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-l 1',f'-p {port}'])

    print(f'==== RX paths for TRX and QPAM have been turned ON. ====\n')

def switch_orx_on(ipcLink=None):
    print(f'==== Turning ON ORX paths for TRX and QPAM. ====\n')

    # a) Set QPAM1_ TX_RXN and QPAM2_ TX_RXN signals as High
    print(f'a)')
    for qpamId in range(rrh_dfe.NUM_OF_QPAM):
        rrh_set_qpam_ctrl.main(ipcLink,['-t',f'-q {qpamId}','-o 1'])

    # b) Set RX_KEY signals for QPAM1 and 2 to High
    print(f'b)')
    for port in range(rrh_dfe.NUM_OF_RX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-d 2 ',f'-p {port}'])  
        
    # c) Set "ORx_BF_CAL_SPDT_CTRL" to "OBX_A_QPAM1"
    print(f'c)')
    rrh_set_trx_ctrl.main(ipcLink,['-b 3','-o 1'])

    # d) Set "ORx Mux" to 0,1,2,3 for QPAM1_Path A/B/C/D,  "ORx Mux" to 4,5,6,7  for QPAM2_Path A/B/C/D
    # e) Set QPAM1_ORX_REV_SEL  and QPAM2_ORX_REV_SEL  signal as low  and for DPD functionality (logic OBS)
    # f) For selecting QPAM1 A path for DPD make QPAM1_ORX_AB_SEL signal as low.  For selecting QPAM1 B path for DPD make QPAM1_ORX_AB_SEL signal as high.
    # g) For selecting QPAM1 C path for DPD make QPAM1_ORX_CD_SEL signal as low.  For selecting QPAM1 D path for DPD make QPAM1_ORX_CD_SEL signal as high.
    # f) For selecting QPAM2 A path for DPD make QPAM2_ORX_AB_SEL signal as low.  For selecting QPAM2 B path for DPD make QPAM2_ORX_AB_SEL signal as high.
    # g) For selecting QPAM2 C path for DPD make QPAM2_ORX_CD_SEL signal as low.  For selecting QPAM2 D path for DPD make QPAM2_ORX_CD_SEL signal as high.
    print(f'd-g)')
    for port in range(rrh_dfe.NUM_OF_TX_PORTS):
        rrh_set_qpam_ctrl.main(ipcLink,['-m',f'-p {port}','-f 0'])
    
    # h) Set OBS Rx1 DSA and OBS Rx2 DSA as 10dB
    print(f'h)')
    for port in range(rrh_dfe.NUM_OF_ORX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-a 3',f'-p {port}','-v 10'])
        
    # i) Set OBS Rx1 AMP EN and OBS Rx2 AMP EN to high
    print(f'i)')
    for port in range(rrh_dfe.NUM_OF_ORX_PORTS):
        rrh_set_trx_ctrl.main(ipcLink,['-e 3',f'-p {port}'])
    
    print(f'==== ORX paths for TRX and QPAM have been turned ON. ====\n')

def main(ipcLink=None, argumentList=None):
    if ipcLink is None :
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()

    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
          fullCmdArguments = sys.argv
          argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hit:rop:',
                                          ['help', 'init', 'tx=', "rx", "orx", "port="])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    # default settings
    initTx = 0
    switchTx = 0
    switchOn = 0
    switchRxOn = 0
    switchOrxOn = 0
    set_single_port = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-i, --init           : initialize TX path for TRX and QPAM')
            print ('-t, --tx             : switch TX path of TRX and QPAM (choose from 1-ON and 0-OFF)')
            print ('                     : optional argument -p, only one port is set if specified,')
            print ('                     : otherwise all ports are set')
            print ('-r, --rx             : switch ON RX path of TRX and QPAM for all ports')
            print ('-o, --orx            : switch ON ORX path of TRX and QPAM for all ports')
            print ('------ parameter specification ------')
            print ('-p, --port           : specify port number')
            print ('=====================================')
            sys.exit()
        elif currentArgument in ('-i', '--init'):
            initTx = 1
        elif currentArgument in ('-t', '--tx'):
            switchTx = 1
            switchOn = int(currentValue)
        elif currentArgument in ('-r', '--rx'):
            switchRxOn = 1
        elif currentArgument in ('-o', '--orx'):
            switchOrxOn = 1
        elif currentArgument in ('-p', '--port'):
            set_single_port = 1
            port = int(currentValue)
            
    try:
        if initTx == 1:
            tx_init(ipcLink)
        elif switchTx == 1:
            if switchOn == 1:
                if set_single_port == 1:
                    switch_tx_port_on(port, ipcLink)
                else:
                    switch_tx_all_on(ipcLink)
            elif switchOn == 0:
                if set_single_port == 1:
                    switch_tx_port_off(port, ipcLink)
                else:
                    switch_tx_all_off(ipcLink)
            else:
                print('Invalid option. -h for help.')
        elif switchRxOn == 1:
            switch_rx_on(ipcLink)
        elif switchOrxOn == 1:
            switch_orx_on(ipcLink)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
