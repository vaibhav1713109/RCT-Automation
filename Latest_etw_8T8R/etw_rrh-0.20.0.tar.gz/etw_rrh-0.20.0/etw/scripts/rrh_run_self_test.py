import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList= None):  
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()

    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hte:p:', ['help', 'test', 'example=', 'prachType='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    run_self_test = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-t, --test           : specify which self test to run, require arguments -e, -p')
            print ('------ parameter specification ------')
            print ('-e, --example        : specify test example to run (1 for XDfeMixer and 2 for XDfeChanFilter)')
            print ('-p, --prachType      : specify type of PRACH (0 for dynamic and 1 for static) for carrier init')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-t', '--test'):
            run_self_test = 1
        elif currentArgument in ('-e', '--example'):
            self_testcase = int(currentValue)
        elif currentArgument in ('-p', '--prachType'):
            enableStaticPrach = int(currentValue)

    try:
        if run_self_test == 1:
            if self_testcase == 1:
                print('Running XDfeMixSelfTestExampleTests.\n')
                rrhDfeProxy.carrierClose()
                rrhDfeProxy.xDfeMixSelfTestExampleTests()
                rrhDfeProxy.carrierInit(enableStaticPrach)
            elif self_testcase == 2:
                print('Running XDfeCcfSelfTestExampleTests.\n')
                rrhDfeProxy.carrierClose()
                rrhDfeProxy.xDfeCcfSelfTestExampleTests()
                rrhDfeProxy.carrierInit(enableStaticPrach)
            else:
                print('Invalid testcase to run self test. -h for help')
        else:
            print('Require testcase to run self test. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
