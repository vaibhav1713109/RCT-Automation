import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hie:d:a:b:s:gl:p:v:o:',
                                          ['help', 'init', 'enable=', 'disable=', 'setAtten=',
                                           'bfCalSwitch=', 'setManager=', 'getManager', 'setRxLna=',
                                           'port=', 'attenVal=', 'opMode='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    DSA_ATTEN = [0, 18, 12, 30]
    trxCtrlInit = 0
    enableObj = 0
    disableObj = 0
    setAtten = 0
    bfCalSwitch = 0
    setManager = 0
    getManager = 0
    setRxLna = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help            : option list')
            print ('-i, --init            : initialize TRx control')
            print ('-e, --enable          : enable object (choose from 1-Tx LNA, 2-Rx LNA, 3-ORx LNA), require arguments -p')
            print ('                      : valid port pair range: Tx-[0,3], Rx-[0,3], ORx-[0,1]')
            print ('-d, --disable         : disable object (choose from 1-Tx LNA, 2-Rx LNA, 3-ORx LNA), require arguments -p')
            print ('                      : valid port pair range: Tx-[0,3], Rx-[0,3], ORx-[0,1]')
            print ('-a, --setAtten        : set attenuation to (choose from 1-Tx, 2-Rx, 3-ORx and 4-Rx AGC DSA),')
            print ('                      : require arguments -p, -v')
            print ('                      : valid port range: Tx-[0,7], Rx-[0,7], ORx-[0,1], Rx AGC DSA-[0,7]')
            print ('-b, --bfCalSwitch     : set BF Cal switch (choose from 1-SPDT, 2-SP3T, 3-ORx SPDT), require arguments -o')
            print ('                      : opMode options: SPDT (1-BF Calibration, 2-normal Tx operation)')
            print ('                                        SP3T (1-idle condition, 2-BF Cal Tx, 3-BF Cal Rx)')
            print ('                                        ORx BF Cal SPDT (1-BF Cal Rx, 2-OBX_A_QPAM1)')
            print ('-s, --setManager      : set switch manager to control QPAM ORx Mux (0-PL, 1-PS)')
            print ('-g, --getManager      : get switch manager which controls QPAM ORx Mux')
            print ('-l, --setRxLna        : set up Rx LNA (choose from 0-disable and 1-enable), require argument -p')
            print ('                      : valid port range: [0,7]')
            print ('------ parameter specification ------')
            print ('-p, --port            : specify port or port pair (valid range refer to different options)')
            print ('-v, --attenVal        : specify attenuation value (in dB)')
            print ('                      : note: in case of Rx AGC DSA, the attenuation is predefined as')
            print ('                      :       0-0dB, 1-18dB, 2-12dB and 3-30dB')
            print ('-o, --opMode          : specify opMode (refer to different switches)')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-i', '--init'):
            trxCtrlInit = 1
        elif currentArgument in ('-e', '--enable'):
            enableObj = 1
            enableSel = int(currentValue)
        elif currentArgument in ('-d', '--disable'):
            disableObj = 1
            disableSel = int(currentValue)
        elif currentArgument in ('-a', '--setAtten'):
            setAtten = 1
            setAttenSel = int(currentValue)
        elif currentArgument in ('-b', '--bfCalSwitch'):
            bfCalSwitch = 1
            bfCalSwitchSel = int(currentValue)
        elif currentArgument in ('-s', '--setManager'):
            setManager = 1
            managerSelect = int(currentValue)
        elif currentArgument in ('-g', '--getManager'):
            getManager = 1
        elif currentArgument in ('-l', '--setRxLna'):
            setRxLna = 1
            rxLnaEnable = int(currentValue)
        elif currentArgument in ('-p', '--port'):
            port = int(currentValue)
        elif currentArgument in ('-v', '--attenVal'):
            attenVal = float(currentValue)
            attenIdx = int(attenVal)
        elif currentArgument in ('-o', '--opMode'):
            opMode = int(currentValue)
    try:
        if trxCtrlInit == 1:
            print(f'Initializing TRx control.\n')
            rrhDfeProxy.mavu8t8rTrxControlInit()
        elif enableObj == 1:
            if enableSel == 1:
                print(f'Enabling Tx LNA on port pair {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetTxLnaEnable(port, 1)
            elif enableSel == 2:
                print(f'Enabling Rx LNA on port pair {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetRxLnaEnable(port, 1)
            elif enableSel == 3:
                print(f'Enabling ORx LNA on port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetORxLnaEnable(port, 1)
            else:
                print('Invalid option. -h for help.')
        elif disableObj == 1:
            if disableSel == 1:
                print(f'Disabling Tx LNA on port pair {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetTxLnaEnable(port, 0)
            elif disableSel == 2:
                print(f'Disabling Rx LNA on port pair {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetRxLnaEnable(port, 0)
            elif disableSel == 3:
                print(f'Disabling ORx LNA on port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetORxLnaEnable(port, 0)
            else:
                print('Invalid option. -h for help.')
        elif setAtten == 1:
            if setAttenSel == 1:
                print(f'Setting DSA attenuation {attenVal}dB to Tx port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetTxDsaAtten(port, attenVal)
            elif setAttenSel == 2:
                print(f'Setting DSA attenuation {attenVal}dB to Rx port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetRxDsaAtten(port, attenVal)
            elif setAttenSel == 3:
                print(f'Setting DSA attenuation {attenVal}dB to ORx port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetORxDsaAtten(port, attenVal)
            elif setAttenSel == 4:
                print(f'Setting attenuation {DSA_ATTEN[attenIdx]}dB to Rx AGC DSA on port {port}.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetRxAgcDsa(port, attenIdx)
            else:
                print('Invalid option. -h for help.')
        elif bfCalSwitch == 1:
            if bfCalSwitchSel == 1:
                print(f'Setting opMode {opMode} to BF Cal SPDT Switch.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetBfCalSpdtSwitch(opMode)
            elif bfCalSwitchSel == 2:
                print(f'Setting opMode {opMode} to BF Cal SP3T Switch.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetBfCalSp3tSwitch(opMode)
            elif bfCalSwitchSel == 3:
                print(f'Setting opMode {opMode} to ORx BF Cal SPDT Switch.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetORxBfCalSpdtSwitch(opMode)
            else:
                print('Invalid option. -h for help.')
        elif setManager == 1:
            if managerSelect == 0:
                print(f'Setting PL to control QPAM ORx Mux.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetSwitchManager(managerSelect)
            elif managerSelect == 1:
                print(f'Setting PS to control QPAM ORx Mux.\n')
                rrhDfeProxy.mavu8t8rTrxControlSetSwitchManager(managerSelect)
            else:
                print('Invalid option. -h for help.')
        elif getManager == 1:
            rsp = rrhDfeProxy.mavu8t8rTrxControlGetSwitchManager()
            if rsp.managerSelect == 0:
                print(f'QPAM ORx Mux is controlled by PL.\n')
            elif rsp.managerSelect == 1:
                print(f'QPAM ORx Mux is controlled by PS.\n')
            else:
                print(f'Invalid setting for QPAM ORx Mux control.\n')
        elif setRxLna == 1:
            enable_str = 'enable' if rxLnaEnable == 1 else 'disable'
            print(f'Setting {enable_str} LNA on RX port {port}.\n')
            rrhDfeProxy.mavu8t8rTrxControlSetRxLNA(port, rxLnaEnable)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
