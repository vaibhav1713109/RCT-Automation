#!/usr/bin/python

import getopt, os, sys, time

import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rfdc_pb2
from etw.lib import rfdc

ipcLink = IpcLink(target.ip_address, target.port)
rfdcProxy = rfdc.RfdcProxy(ipcLink)
rfdcProxy.connect()
rfdc.debug_on = 0

def set_dac_vop(current):
    try:
        ######################################################################
        # MIXER + NYQUIST ZONE SETTINGS ######################################
        ######################################################################
        for i in range (0, 4):
            for j in range (0, 4, 2):
                if current:
                    rfdcProxy.setDACCompMode(tile_id = i,
                                             block_id = j,
                                             mode = 0)
                
                    rfdcProxy.setDACVOP(tile_id = i,
                                        block_id = j,
                                        uACurrent = current)

                else:
                    rfdcProxy.setDACCompMode(tile_id = i,
                                             block_id = j,
                                             mode = 1)
                    
    except Exception as e:
        print(e)

def main():
    # Get and parse CMD arguments.
    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'dc:')
    except getopt.error as err:
        # output error, and return with an error code
        print (str(err))
        sys.exit(2)

    current = 10000
    # Override default values if passed via CMD arguments.
    err_msg = None
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-d', '--debug'):
            rfdc.debug_on = 1
        elif currentArgument in ('-c'):
            current = currentValue
            try:
                current = int(current)
            except:
                err_msg = f'invalid current value: {current}'
        else:
            err_msg = f'invalid argument: {currentArgument}'
            
        if err_msg:
            print(f'error: {err_msg}')
            sys.exit(1)
            
    set_dac_vop(current)

main()
