import target
from etw.lib.boardmgr import BoardMgr

mgr = BoardMgr(target)
mgr.connect()
    
exit_code, output = mgr.execCmd("top", "-b -n 1")

print(output)

