ip_address = '127.0.0.1'
#ip_address = '192.168.1.177'
#ip_address = '10.0.2.15'

use_ssl = False

tcp_port = 59875
ssl_port = 59876

port = ssl_port if use_ssl else tcp_port

RRH_HW_VERSION = '2'    # '0': zcu670 eval board, '1':VVDN P0, '2': VVDN E1
                        # '10' PUMA
