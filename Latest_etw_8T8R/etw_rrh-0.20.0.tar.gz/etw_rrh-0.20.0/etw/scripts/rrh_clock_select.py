import target
from etw.lib.etwproxy import IpcLink, EtwProxy
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList= None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
        
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    etwProxy = EtwProxy(ipcLink=ipcLink)
    rrh_dfe.debug_on = 1

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hc:',
                                          ['help', 'clockSource='])
    except getopt.error as err:
        print(str(err))
        sys.exit(2)

    CLOCK_SOURCE = ['Clk104 - 156.25 MHz from 10G Ethernet',
                    'Clk104 - 390.625 MHz from 25G Ethernet',
                    'Clk104 - External 10 MHz',
                    'Clk104 - Internal 10.8 MHz TCXO',
                    'Si5381 - External 10 MHz',
                    'Si5518 - External 10 MHz',
                    'Si5518 - Pre-programmed for PTP',
                    'Renesas 8a34005 - Program for PTP']
        
    setClockSource = 0
    if int(target.RRH_HW_VERSION) < 10:  # copper
        numClockSource = 7
    else:                           # puma
        numClockSource = 8

    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-c, --clockSource    : select clock source')
            print ('                     : 0 - Clk104 - 156.25 MHz from 10G Ethernet')
            print ('                     : 1 - Clk104 - 390.625 MHz from 25G Ethernet')
            print ('                     : 2 - Clk104 - External 10 MHz')
            print ('                     : 3 - Clk104 - Internal 10.8 MHz TCXO')
            print ('                     : 4 - Si5381 - External 10 MHz')
            print ('                     : 5 - Si5518 - External 10 MHz')
            print ('                     : 6 - Si5518 - Pre-programmed for PTP')
            print ('                     : 7 - Renesas 8a34005 - Program for PTP (only for PUMA)')
            print ('                     : 11 - internal free running 1PPS')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-c', '--clockSource'):
            setClockSource = 1
            clockSource = int(currentValue)
            
    try:
        if setClockSource == 1:
            if clockSource in range(0, numClockSource):
                print(f'Setting {CLOCK_SOURCE[clockSource]} as the clock source for the system.\n')
                rrhDfeProxy.rfClockSelect(clockSource)
            elif clockSource == 11: # do nothing as option 6 on etw service
                print(f'Setting internal free running 1PPS as the clock source for the system.\n')

                value = 0x1
                addr  = 0xa0140068
                etwProxy.writeU32(value, addr)   # change from external 1PPS to internel 1PPS
                print(f'Setting {hex(etwProxy.readU32(addr))} to addr {hex(addr)}.')

                value = 0x0
                addr  = 0xa01b0014
                etwProxy.writeU32(value, addr)
                print(f'Setting {hex(etwProxy.readU32(addr))} to addr {hex(addr)}.')

                value = 0x1
                addr  = 0xa01b0014
                etwProxy.writeU32(value, addr)
                print(f'Setting {hex(etwProxy.readU32(addr))} to addr {hex(addr)}.')
                rrhDfeProxy.rfClockSelect(6)
            else:
                print('Invalid option. -h for help.')
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
