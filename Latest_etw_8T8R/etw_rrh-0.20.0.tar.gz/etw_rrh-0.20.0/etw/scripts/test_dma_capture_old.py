import etw.lib
import target
from etwmodel import EtwModel
from dmachannel import DmaChannel
from testsignal import TestSignal
import sys, time

DMA_BASE_ADDRESS = 0x00A0910000

# Get capture size
try:
    capture_size = int(sys.argv[1])
except Exception as e:
    print(f'error: invalid capture size')
    sys.exit(1)

# Open output file
try:
    filename = sys.argv[2]
    try:
        if filename.endswith('.bin'):
            outfile = open(filename, "wb")
        else:
            outfile = open(filename, "w")
    except Exception as e:
        print(f'error: could not open output file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no output file provided')
    sys.exit(1)

# Create model and append dma instance
model = EtwModel()
dma_name = "dma-0"
model.model['devices'][dma_name] = {'name' : dma_name, 'type' : "axi_dma", 'base' : DMA_BASE_ADDRESS }
dma_regs, _ = model.getDeviceRegisters(model.model['devices'][dma_name])
model.model['devices'][dma_name]['registers'] = dma_regs

# Connect to target
try:
    model.connect(target)
except Exception as e:
    print(f'error: could not connect to target: {e}')
    sys.exit(1)

# allocate DDR memory buffer
try:
    vector_size = capture_size * 4
    vector_ptr = model.proxy.allocBuf(vector_size)
    print(f'DDR Address: 0x{vector_ptr:08X}')
except Exception as e:
    print(f'error: could not allocate DDR buffer: {e}')
    sys.exit(1)

# Turn on logging
model.log_write = True

# Create DMA proxy
dma = DmaChannel(model, dma_name)

# Transfer data to DDR
print("Start transfer...")
dma.transferToDDR(vector_ptr, vector_size)

# Sleep for a while
print("Sleeping...")
time.sleep(1)

# Read captured buffer
print("Reading captured data...");
data = model.proxy.readFromBuf(vector_ptr, vector_size)

# Write to output file
print("Writing result...")
if filename.endswith('.bin'):
    outfile.write(data)
else:
    sig = TestSignal(signal_data = data)
    i, q = sig.to_i_q()
    for n in range(len(i)):
        print(f'{i[n]} {q[n]}', file=outfile)

outfile.close()

# Dump DMA registers
print("Register dump (mm2s)...")
dma_regs = dma.readAllRegisters()
for reg in dma_regs:
    if not "s2mm" in reg:
        continue
    for field in dma_regs[reg]:
        val = dma_regs[reg][field]
        print(f'{reg}.{field} = {val}')
