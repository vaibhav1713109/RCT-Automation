import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):   
    if ipcLink is None :    
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()
 
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
          fullCmdArguments = sys.argv
          argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hdu',
                                          ['help', 'dl', 'ul'])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    config_dl = 0
    config_ul = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-d, --dl             : configure ORAN router for DL 1CC')
            print ('-u, --ul             : configure ORAN router for UL 1CC')
            print ('=====================================')
            sys.exit(0)
        elif currentArgument in ('-d', '--dl'):
            config_dl = 1
        elif currentArgument in ('-u', '--ul'):
            config_ul = 1

    try:
        if config_dl == 1:
            print(f'Configuring ORAN router for DL 1CC.\n')
            rrhDfeProxy.oranConfigDl1cc()
        elif config_ul == 1:
            print(f'Configuring ORAN router for UL 1CC.\n')
            rrhDfeProxy.oranConfigUl1cc()
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()