import target
import etw.lib
from etwmodel import EtwModel
from dmachannel import DmaChannel
from testsignal import TestSignal
import libetap
from libetap import libetapProxy
import sys, time

libetap.debug_on = 1

# Get capture size
try:
    capture_size = int(sys.argv[1])
except Exception as e:
    print(f'error: invalid capture size')
    sys.exit(1)

# Open output file
try:
    filename = sys.argv[2]
    try:
        if filename.endswith('.bin'):
            outfile = open(filename, "wb")
        else:
            outfile = open(filename, "w")
    except Exception as e:
        print(f'error: could not open output file: {e}')
        sys.exit(1)
except Exception as e:
    print(f'error: no output file provided')
    sys.exit(1)

# Create and connect model
try:
    model = EtwModel()
    model.connect(target)
except Exception as e:
    print(f'error: could not connect to target: {e}')
    sys.exit(1)

# allocate DDR memory buffer
try:
    vector_size = capture_size * 4
    vector_ptr = model.proxy.allocBuf(vector_size)
    print(f'DDR Address: 0x{vector_ptr:08X}')
except Exception as e:
    print(f'error: could not allocate DDR buffer: {e}')
    sys.exit(1)
    

# Create ETAP proxy
etapProxy = libetapProxy(model.proxy.ipc_link)
etapProxy.etapInit()

# Create DMA proxy
dma = DmaChannel(model)

# Create DMA TX BD Ring
first_rx, last_rx, tail_rx = dma.createRxBdRing(vector_ptr, vector_size)

etapProxy.startCapture()

# Call ETAP APP to setup injection
etapProxy.captureDmaDdr(tap_point=0,
                       antenna_port_id = 1,
                       cc_id = 1,
                       no_frames = 1,
                       first_desc = first_rx,
                       tail_desc = last_rx,
                       circular_capture = False)


# Read captured buffer
print("Reading captured data...");
data = model.proxy.readFromBuf(vector_ptr, vector_size)
sig = TestSignal(signal_data = data, format = 'ddr', sampleType='data_32bit')

# Write to output file
print("Writing result...")
i, q, _ = sig.to_i_q_c()
for n in range(len(i)):
    print(f'{i[n]} {q[n]}', file=outfile)

outfile.close()

# Free memory
dma.freeMem()
model.proxy.freeBuf(vector_ptr)

#Stop ETAP
etapProxy.stopCapture()

sys.exit(1)
