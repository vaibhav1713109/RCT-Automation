import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()

    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]

    supportedPrachFormat = ['NR_0',  'NR_1',  'NR_2',  'NR_3',
                            'NR_A1', 'NR_A2', 'NR_A3',
                            'NR_B1', 'NR_B2', 'NR_B3', 'NR_B4',
                            'NR_C0', 'NR_C2']

    try:
        arguments, values = getopt.getopt(argumentList, 'hac:m:o:n:f:p:s:t:',
                                          ['help', 'add',
                                           'carrierName=', 'format=', 'offsetFreq=',
                                           'numOfOccasions=', 'frameNum=', 'patternPeriod=',
                                           'subframeId=', 'timeOffsetTs='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    addPrach = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-a, --add            : add PRACH to existing carrier,')
            print ('                       require arguments -c, -m, -o, -n, -f, -p, -s, -t')
            print ('------ parameter specification ------')
            print ('-c, --carrierName    : specify existing carrier name')
            print ('-m, --format         : specify PRACH format, supported ones are:')
            print ('                       0  -> NR_0')
            print ('                       1  -> NR_1')
            print ('                       2  -> NR_2')
            print ('                       3  -> NR_3')
            print ('                       4  -> NR_A1')
            print ('                       5  -> NR_A2')
            print ('                       6  -> NR_A3')
            print ('                       7  -> NR_B1')
            print ('                       8  -> NR_B2')
            print ('                       9  -> NR_B3')
            print ('                       10 -> NR_B4')
            print ('                       11 -> NR_C0')
            print ('                       12 -> NR_C2')
            print ('-o, --offsetFreq     : specify PRACH offset frequency (in Hz)')
            print ('-n, --numOfOccasions : specify PRACH number of occasions')
            print ('-f, --frameNum       : specify PRACH frame number')
            print ('-p, --patternPeriod  : specify PRACH pattern period, valid range [1,256]')
            print ('-s, --subframeId     : specify PRACH subframe ID')
            print ('-t, --timeOffsetTs   : specify PRACH time offset Ts')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-a', '--add'):
            addPrach = 1
        elif currentArgument in ('-c', '--carrierName'):
            carrierName = currentValue
        elif currentArgument in ('-m', '--format'):
            prachFormat = int(currentValue)
        elif currentArgument in ('-o', '--offsetFreq'):
            offsetFreq = int(currentValue)
        elif currentArgument in ('-n', '--numOfOccasions'):
            numOfOccasions = int(currentValue)
        elif currentArgument in ('-f', '--frameNum'):
            frameNum = int(currentValue)
        elif currentArgument in ('-p', '--patternPeriod'):
            patternPeriod = int(currentValue)
        elif currentArgument in ('-s', '--subframeId'):
            subframeId = int(currentValue)
        elif currentArgument in ('-t', '--timeOffsetTs'):
            timeOffsetTs = int(currentValue)

    try:
        if addPrach == 1:
            print(f'Adding PRACH in format {supportedPrachFormat[prachFormat]} to carrier {carrierName}.\n')
            rrhDfeProxy.carrierAttachPrachByFormat(carrierName, prachFormat, offsetFreq, numOfOccasions,
                                                   frameNum, patternPeriod, subframeId, timeOffsetTs)
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
