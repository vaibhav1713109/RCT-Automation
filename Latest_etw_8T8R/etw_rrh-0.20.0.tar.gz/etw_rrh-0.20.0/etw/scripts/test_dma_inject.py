import target
import etw.lib
from etwmodel import EtwModel
from dmachannel import DmaChannel
from testsignal import TestSignal
import libetap
from libetap import libetapProxy
import sys, time

libetap.debug_on = 1

# Check file name
try:
    filename = sys.argv[1]
except Exception as e:
    print(f'error: no signal file provided')
    sys.exit(1)

# Create test signal
try:
    test_signal = TestSignal(signal_file = filename, format='dec')
    # test_signal = TestSignal(signal_file = filename, format='hex32')
    data = test_signal.to_bytes(format='ddr', sampleType='data_32bit')
except Exception as e:
    print(f'error: could not read signal file: {e}')
    sys.exit(1)

# Create and connect model
try:
    model = EtwModel()
    model.connect(target)
except Exception as e:
    print(f'error: could not connect to target: {e}')
    sys.exit(1)

# Free all DDR buffers (not always a good idea...)
model.proxy.freeAll()

# allocate DDR memory buffer and write signal vector
try:
    vector_size = len(data)
#    vector_size = 65535
    vector_ptr = model.proxy.allocBuf(vector_size)
    model.proxy.writeToBuf(vector_ptr, data)
#    model.proxy.writeToBuf(vector_ptr, data[:vector_size])
except Exception as e:
    print(f'error: could not allocate and write to DDR buffer: {e}')
    sys.exit(1)
    

# Create ETAP proxy
etapProxy = libetapProxy(model.proxy.ipc_link)
etapProxy.etapInit()


# Create DMA proxy
dma = DmaChannel(model)

# Create DMA TX BD Ring
first_tx, last_tx, tail_tx = dma.createTxBdRing(vector_ptr, vector_size)

# Start ETAP inject
etapProxy.startInject()


# Call ETAP APP to setup injection
etapProxy.injectDmaDdr(tap_point=0,
                       antenna_port_id = 4,
                       cc_id = 1,
                       ccid_pattern = 0,
                       first_desc = first_tx,
                       tail_desc = tail_tx,
                       circular_inject = True)


#print("sleeping...")
time.sleep(1)

# Wait for keyboard input
input(f'Circular injection started ({vector_size >> 2} samples), press enter to stop...')
print()

# Stop injection
etapProxy.stopInject()

# Free memory
dma.freeMem()
model.proxy.freeBuf(vector_ptr)

sys.exit(1)
