from shutil import ReadError
import target
from etw.lib.etwproxy import IpcLink
from etw.lib import libdatabase_pb2
from etw.lib import libdatabase
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()

    libdatabaseProxy = libdatabase.libdatabaseProxy(ipcLink)
    libdatabaseProxy.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hc:s:',
                                          ['help',  'command=','saveflash='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)
    
    SaveflashMode = 0
    CmdMode = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help            : option list')
            print ('-c, --command         : command input,e.g: db init')
            print("                         usage: ")
            print("                           db init")
            print("                           db list [hw | sw | all] ")
            print("                           db read [path] ")
            print("                           db save hw")
            print("                           db write [path] [-m] [value]")
            print("                           db append [hw|sw] [path] [value] [value type]")
            print ('-s, --saveflash          : saveflash,require filepath.e.g: "/home/root/production.db"')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-c', '--command'):
            CmdMode = 1
            cmd = currentValue
        elif currentArgument in ('-s', '--saveflash'):
            SaveflashMode = 1
            filepath = currentValue
    try:
        if CmdMode == 1:
            print(f'cmd is  : {cmd}')
            result = libdatabaseProxy.cmdHandler(cmd)
            print(result)
        elif SaveflashMode == 1:
            result = libdatabaseProxy.saveflash(filepath) 
            if result == 1:
                print("save flash to "+filepath+" success!")
            else:
                print("save flash to "+filepath+" failed!")
        else:
            print('Invalid option. -h for help.')

    except Exception as e:
        print(e)
        
if __name__=="__main__":
    main()