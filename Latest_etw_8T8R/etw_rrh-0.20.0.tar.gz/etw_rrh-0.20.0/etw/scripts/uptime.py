import target
from etw.lib.etwproxy import EtwProxy, EtwError

try:
    proxy = EtwProxy(target.ip_address, target.port)
    proxy.connect()
    
    exit_code, output = proxy.execCmd("uptime", "")
    print(output)

except EtwError as error:
    print("ETW Exception occurred: " + error.message)
