import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None:
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()          

    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
        fullCmdArguments = sys.argv
        argumentList     = fullCmdArguments[1:]
    
    try:
        arguments, values = getopt.getopt(argumentList, 'hpcf:n:l:', ['help', 'playback', 'capture', 'filename=', 'numOfSamples=', 'channel='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    waveform_playback = 0
    waveform_capture = 0
    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-p, --playback       : set waveform playback mode, require arguments -f -n')
            print ('-c, --capture        : set waveform capture mode, require argument -f -n -l')
            print ('------ parameter specification ------')
            print ('-f, --filename       : specify full path of filename, only .txt and .bin are supported')
            print ('-n, --numOfSamples   : specify number of 32-bit words in file')
            print ('-l, --channel        : specify waveform channel')
            print ('=====================================')
            sys.exit(2)
        elif currentArgument in ('-p', '--playback'):
            waveform_playback = 1
        elif currentArgument in ('-c', '--capture'):
            waveform_capture = 1
        elif currentArgument in ('-f', '--filename'):
            filename = currentValue
            name, extension = os.path.splitext(filename)
            if extension == '.txt':
                waveFormat =  rrh_dfe.WaveFormatType_TXT
            elif extension == '.bin':
                waveFormat =  rrh_dfe.WaveFormatType_BIN
            else:
                print('Invalid extension for waveform filename. -h for help.')
        elif currentArgument in ('-n', '--numOfSamples'):
            numOfSamples = int(currentValue)
        elif currentArgument in ('-l', '--channel'):
            waveformChannel = int(currentValue)

    try:
        if waveform_playback == 1:
            print(f'Running waveform playback from file {filename}.\n')
            rrhDfeProxy.waveformMemoryDownloadAndWrite(filename, waveFormat, numOfSamples)
            rrhDfeProxy.setWaveformPlaybackLength(numOfSamples)
            rrhDfeProxy.setWaveformPlaybackMasterEnable(1)
        elif waveform_capture == 1:
            print(f'Running waveform capture to file {filename}.\n')
            rrhDfeProxy.startWaveformCapture(filename, waveFormat, waveformChannel,
                                             rrh_dfe.CaptureModeType_SINGLE, 1)
        else:
            print('Either playback or capture mode must be specified. -h for help.')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
