import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time

def main(ipcLink=None, argumentList=None):
    if ipcLink is None :
        ipcLink = IpcLink(target.ip_address, target.port)
        ipcLink.connect()

    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrh_dfe.debug_on = 0

    if argumentList is None:
          fullCmdArguments = sys.argv
          argumentList     = fullCmdArguments[1:]

    try:
        arguments,value = getopt.getopt(argumentList,'hm:p:',
                                        ['help','setBypassMode=','setCfrOutputPar='])
    except getopt.error as err:
        print(str(err))
        sys.exit(2)

    BYPASSMODE = ['CFR-DPD Both Bypassed', 'CFR Enabled but DPD Bypassed', 'CFR-DPD Both Enabled']
    setcfrdpdbypassmode = 0
    setcfroutputpar = 0
    for currnetArgument,currentValue in arguments:
        if currnetArgument in('-h','--help'):
            print("========================================================")
            print("Help Menu")
            print("-------- functional option -------")
            print("-h,  --help             : option list")
            print("-m,  --setBypassMode    : set CFR-DPD Bypass Mode, choose from:")
            print("                          0-CFR-DPD Both Bypassed")
            print("                          1-CFR Enabled but DPD Bypassed")
            print("                          2-CFR-DPD Both Enabled")
            print("-p,  --setCfrOutputPar  : set CFR output PAR (specify float value, e.g. 2.0)")
            print("=========================================================")
            sys.exit(2)
        elif currnetArgument in ('-m','--setBypassMode'):
            setcfrdpdbypassmode = 1
            cfrDpdBypassMode = int(currentValue)
        elif currnetArgument in ('-p','--setCfrOutputPar'):
            setcfroutputpar = 1
            cfrOutputPar = float(currentValue)
    try:
        if(setcfroutputpar == 1):
            print(f'Setting CFR Output PAR to {cfrOutputPar}')
            rrhDfeProxy.carrierSetCfrOutputPar(cfrOutputPar)
        elif(setcfrdpdbypassmode==1):
            print(f'Setting CFR-DPD mode to {BYPASSMODE[cfrDpdBypassMode]}')
            rrhDfeProxy.carrierSetCfrDpdBypassMode(cfrDpdBypassMode)
        else:
            print("Invalid option. -h for help")

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
