import target
from etw.lib.etwproxy import IpcLink
from etw.lib import rrh_dfe_pb2
from etw.lib import rrh_dfe
import getopt, os, sys, time
import subprocess as sp

def main():        
    ipcLink = IpcLink(target.ip_address, target.port)
    rrhDfeProxy = rrh_dfe.RrhDfeProxy(ipcLink)
    rrhDfeProxy.connect()
    rrh_dfe.debug_on = 0

    fullCmdArguments = sys.argv
    argumentList     = fullCmdArguments[1:]

    try:
        arguments, values = getopt.getopt(argumentList, 'hoqc:',
                                          ['help', 'oran', 'qpam', 'centerFreqKhz='])
    except getopt.error as err:
        print (str(err))
        sys.exit(2)

    # default settings
    enableStaticPrach = 1    # static
    carrierName = 'CC0'
    scs_u = 1                # 30kHz
    fftSize = 4096
    chBwMhz = 100            # 100MHz
    centerFreqKhz = 3450000  # 3.45GHz
    dacAtten = 0
    dacAttenPort = 7
    adcAtten = 0
    adcAttenPort = 7

    config_oran_dl_1cc = 0
    config_qpam_tx = 0

    for currentArgument, currentValue in arguments:
        if currentArgument in ('-h', '--help'):
            print ('=====================================')
            print ('Help Menu')
            print ('--------- functional option ---------')
            print ('-h, --help           : option list')
            print ('-o, --oran           : also configure ORAN router for DL 1CC')
            print ('-q, --qpam           : also configure QPAM for all TX ports')
            print ('------ parameter specification ------')
            print ('-c, --centerFreqKhz  : specify TX/RX RF center frequency (in kHz)')
            print ('=====================================')
            sys.exit()
        elif currentArgument in ('-o', '--oran'):
            config_oran_dl_1cc = 1
        elif currentArgument in ('-q', '--qpam'):
            config_qpam_tx = 1
        elif currentArgument in ('-c', '--centerFreqKhz'):
            centerFreqKhz = int(currentValue)

    try:
        print('======== Started setting up 1CC test case ========\n')

        # Initialize carrier
        sp.run(f'python3 rrh_set_carrier.py -i -p {enableStaticPrach}', shell=True)

        # Set TX RF frequency
        sp.run(f'python3 rrh_set_rf_frequency.py -t -f {centerFreqKhz}', shell=True)

        # Set RX RF frequency
        sp.run(f'python3 rrh_set_rf_frequency.py -r -f {centerFreqKhz}', shell=True)

        # Set DAC attenuation
        sp.run(f'python3 rrh_set_attenuation.py -d -p {dacAttenPort} -s {dacAtten}', shell=True)

        # Set ADC attenuation
        sp.run(f'python3 rrh_set_attenuation.py -a -p {adcAttenPort} -s {adcAtten}', shell=True)

        # (if specified), set up TRX and QPAM for port 0
        if config_qpam_tx == 1:
            sp.run(f'python3 rrh_set_trx_ctrl.py -i', shell=True)
            sp.run(f'python3 rrh_set_qpam_ctrl.py -i -q 0', shell=True)
            sp.run(f'python3 rrh_config_trx_qpam.py -t 1 -p 0', shell=True)

        # Add carrier
        sp.run(f'python3 rrh_set_carrier.py -a -n {carrierName} -s {scs_u} -f {fftSize} -b {chBwMhz} -c {centerFreqKhz}', shell=True)

        # Enable carrier
        sp.run(f'python3 rrh_set_carrier.py -e -n {carrierName}', shell=True)

        # Set up ORAN router for DL 1CC (if specified)
        if config_oran_dl_1cc == 1:
            sp.run(f'python3 rrh_config_oran.py -d', shell=True)

        print('======== Completed setting up 1CC test case ========\n')

    except Exception as e:
        print(e)

if __name__=="__main__":
    main()
