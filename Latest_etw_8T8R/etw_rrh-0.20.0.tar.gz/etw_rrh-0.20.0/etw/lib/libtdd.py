from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libtdd_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libtddProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibtdd", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def TddReturnStatusType_fromDict(self, dict):
        x = libtdd_pb2.TddReturnStatusType()
        if not dict: return x
        setattr(x, "status", dict.get("status", 0))
        setattr(x, "errorString", dict.get("errorString", 0))
        return x

    def Struct_tdd_caps_t_fromDict(self, dict):
        x = libtdd_pb2.Struct_tdd_caps_t()
        if not dict: return x
        setattr(x, "num_sw_points", dict.get("num_sw_points", 0))
        setattr(x, "num_dl_int_sw", dict.get("num_dl_int_sw", 0))
        setattr(x, "num_ul_int_sw", dict.get("num_ul_int_sw", 0))
        setattr(x, "num_dl_ext_sw", dict.get("num_dl_ext_sw", 0))
        setattr(x, "num_ul_ext_sw", dict.get("num_ul_ext_sw", 0))
        return x

    def tdd_transitions_t_fromDict(self, dict):
        x = libtdd_pb2.tdd_transitions_t()
        if not dict: return x
        setattr(x, "delay", dict.get("delay", 0))
        setattr(x, "dlValue", dict.get("dlValue", 0))
        setattr(x, "ulValue", dict.get("ulValue", 0))
        setattr(x, "en", dict.get("en", 0))
        return x

    def tdd_config_delays_t_fromDict(self, dict):
        x = libtdd_pb2.tdd_config_delays_t()
        if not dict: return x
        setattr(x, "delayAfterRising", dict.get("delayAfterRising", 0))
        setattr(x, "valueAfterRising", dict.get("valueAfterRising", 0))
        setattr(x, "delayAfterFalling", dict.get("delayAfterFalling", 0))
        setattr(x, "valueAfterFalling", dict.get("valueAfterFalling", 0))
        setattr(x, "defaultValue", dict.get("defaultValue", 0))
        return x

    def TddReturnStatusType_toDict(self, v):
        dict = {}
        dict["status"] = getattr(v, "status")
        dict["errorString"] = getattr(v, "errorString")
        return dict

    def Struct_tdd_caps_t_toDict(self, v):
        dict = {}
        dict["num_sw_points"] = getattr(v, "num_sw_points")
        dict["num_dl_int_sw"] = getattr(v, "num_dl_int_sw")
        dict["num_ul_int_sw"] = getattr(v, "num_ul_int_sw")
        dict["num_dl_ext_sw"] = getattr(v, "num_dl_ext_sw")
        dict["num_ul_ext_sw"] = getattr(v, "num_ul_ext_sw")
        return dict

    def tdd_transitions_t_toDict(self, v):
        dict = {}
        dict["delay"] = getattr(v, "delay")
        dict["dlValue"] = getattr(v, "dlValue")
        dict["ulValue"] = getattr(v, "ulValue")
        dict["en"] = getattr(v, "en")
        return dict

    def tdd_config_delays_t_toDict(self, v):
        dict = {}
        dict["delayAfterRising"] = getattr(v, "delayAfterRising")
        dict["valueAfterRising"] = getattr(v, "valueAfterRising")
        dict["delayAfterFalling"] = getattr(v, "delayAfterFalling")
        dict["valueAfterFalling"] = getattr(v, "valueAfterFalling")
        dict["defaultValue"] = getattr(v, "defaultValue")
        return dict

    def MAVU_TDD_Init(self):
        _req = libtdd_pb2.MAVU_TDD_InitReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Init failed: no valid response found (mAVU_TDD_Init)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_InitRsp._ret)

    def MAVU_TDD_Get_Capabilities(self):
        _req = libtdd_pb2.MAVU_TDD_Get_CapabilitiesReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Get_CapabilitiesReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Get_CapabilitiesRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Get_Capabilities failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Get_Capabilities failed: no valid response found (mAVU_TDD_Get_Capabilities)")
        return self.Struct_tdd_caps_t_toDict(_rsp.mAVU_TDD_Get_CapabilitiesRsp.tdd_cap), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Get_CapabilitiesRsp._ret)

    def MAVU_TDD_Configure_Int_Trans(self, sw_point):
        _req = libtdd_pb2.MAVU_TDD_Configure_Int_TransReq()
        _req.sw_point = sw_point
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Configure_Int_TransReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Configure_Int_TransRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Configure_Int_Trans failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Configure_Int_Trans failed: no valid response found (mAVU_TDD_Configure_Int_Trans)")
        return self.tdd_transitions_t_toDict(_rsp.mAVU_TDD_Configure_Int_TransRsp.transitions), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Configure_Int_TransRsp._ret)

    def MAVU_TDD_Configure_Ext_Trans(self, sw_point):
        _req = libtdd_pb2.MAVU_TDD_Configure_Ext_TransReq()
        _req.sw_point = sw_point
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Configure_Ext_TransReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Configure_Ext_TransRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Configure_Ext_Trans failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Configure_Ext_Trans failed: no valid response found (mAVU_TDD_Configure_Ext_Trans)")
        return self.tdd_transitions_t_toDict(_rsp.mAVU_TDD_Configure_Ext_TransRsp.transitions), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Configure_Ext_TransRsp._ret)

    def MAVU_TDD_Configure_DL_Int_SW_Delays(self, dl_int_sw):
        _req = libtdd_pb2.MAVU_TDD_Configure_DL_Int_SW_DelaysReq()
        _req.dl_int_sw = dl_int_sw
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Configure_DL_Int_SW_DelaysReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Configure_DL_Int_SW_DelaysRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Configure_DL_Int_SW_Delays failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Configure_DL_Int_SW_Delays failed: no valid response found (mAVU_TDD_Configure_DL_Int_SW_Delays)")
        return self.tdd_config_delays_t_toDict(_rsp.mAVU_TDD_Configure_DL_Int_SW_DelaysRsp.config), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Configure_DL_Int_SW_DelaysRsp._ret)

    def MAVU_TDD_Configure_UL_Int_SW_Delays(self, ul_int_sw):
        _req = libtdd_pb2.MAVU_TDD_Configure_UL_Int_SW_DelaysReq()
        _req.ul_int_sw = ul_int_sw
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Configure_UL_Int_SW_DelaysReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Configure_UL_Int_SW_DelaysRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Configure_UL_Int_SW_Delays failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Configure_UL_Int_SW_Delays failed: no valid response found (mAVU_TDD_Configure_UL_Int_SW_Delays)")
        return self.tdd_config_delays_t_toDict(_rsp.mAVU_TDD_Configure_UL_Int_SW_DelaysRsp.config), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Configure_UL_Int_SW_DelaysRsp._ret)

    def MAVU_TDD_Enable(self):
        _req = libtdd_pb2.MAVU_TDD_EnableReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_EnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_EnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Enable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Enable failed: no valid response found (mAVU_TDD_Enable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_EnableRsp._ret)

    def MAVU_TDD_Disable(self):
        _req = libtdd_pb2.MAVU_TDD_DisableReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_DisableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_DisableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Disable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Disable failed: no valid response found (mAVU_TDD_Disable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_DisableRsp._ret)

    def MAVU_TDD_Set_SCS_Terminal_Count(self, scsTermCnt):
        _req = libtdd_pb2.MAVU_TDD_Set_SCS_Terminal_CountReq()
        _req.scsTermCnt = scsTermCnt
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Set_SCS_Terminal_CountReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Set_SCS_Terminal_CountRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Set_SCS_Terminal_Count failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Set_SCS_Terminal_Count failed: no valid response found (mAVU_TDD_Set_SCS_Terminal_Count)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Set_SCS_Terminal_CountRsp._ret)

    def MAVU_TDD_Configure_Clk_Divisor(self, clk_div):
        _req = libtdd_pb2.MAVU_TDD_Configure_Clk_DivisorReq()
        _req.clk_div = clk_div
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Configure_Clk_DivisorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Configure_Clk_DivisorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Configure_Clk_Divisor failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Configure_Clk_Divisor failed: no valid response found (mAVU_TDD_Configure_Clk_Divisor)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Configure_Clk_DivisorRsp._ret)

    def MAVU_TDD_Read_Status(self):
        _req = libtdd_pb2.MAVU_TDD_Read_StatusReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Read_StatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Read_StatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Read_Status failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Read_Status failed: no valid response found (mAVU_TDD_Read_Status)")
        return _rsp.mAVU_TDD_Read_StatusRsp.status, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Read_StatusRsp._ret)

    def MAVU_TDD_Extsw_Configure_Dpdsw(self, dpdSwToAnt_Delay):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Configure_DpdswReq()
        _req.dpdSwToAnt_Delay = dpdSwToAnt_Delay
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Configure_DpdswReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Configure_DpdswRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Configure_Dpdsw failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Configure_Dpdsw failed: no valid response found (mAVU_TDD_Extsw_Configure_Dpdsw)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Configure_DpdswRsp._ret)

    def MAVU_TDD_Extsw_Configure_DL_SW_Delays(self, dl_ext_sw):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Configure_DL_SW_DelaysReq()
        _req.dl_ext_sw = dl_ext_sw
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Configure_DL_SW_DelaysReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Configure_DL_SW_DelaysRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Configure_DL_SW_Delays failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Configure_DL_SW_Delays failed: no valid response found (mAVU_TDD_Extsw_Configure_DL_SW_Delays)")
        return self.tdd_config_delays_t_toDict(_rsp.mAVU_TDD_Extsw_Configure_DL_SW_DelaysRsp.config), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Configure_DL_SW_DelaysRsp._ret)

    def MAVU_TDD_Extsw_Configure_DL_SW_Default_Value(self, dl_ext_sw, defVal):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Configure_DL_SW_Default_ValueReq()
        _req.dl_ext_sw = dl_ext_sw
        _req.defVal = defVal
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Configure_DL_SW_Default_ValueReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Configure_DL_SW_Default_ValueRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Configure_DL_SW_Default_Value failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Configure_DL_SW_Default_Value failed: no valid response found (mAVU_TDD_Extsw_Configure_DL_SW_Default_Value)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Configure_DL_SW_Default_ValueRsp._ret)

    def MAVU_TDD_Extsw_Configure_UL_SW_Delays(self, ul_ext_sw):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Configure_UL_SW_DelaysReq()
        _req.ul_ext_sw = ul_ext_sw
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Configure_UL_SW_DelaysReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Configure_UL_SW_DelaysRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Configure_UL_SW_Delays failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Configure_UL_SW_Delays failed: no valid response found (mAVU_TDD_Extsw_Configure_UL_SW_Delays)")
        return self.tdd_config_delays_t_toDict(_rsp.mAVU_TDD_Extsw_Configure_UL_SW_DelaysRsp.config), self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Configure_UL_SW_DelaysRsp._ret)

    def MAVU_TDD_Extsw_Configure_UL_SW_Default_Value(self, ul_ext_sw, defVal):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Configure_UL_SW_Default_ValueReq()
        _req.ul_ext_sw = ul_ext_sw
        _req.defVal = defVal
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Configure_UL_SW_Default_ValueReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Configure_UL_SW_Default_ValueRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Configure_UL_SW_Default_Value failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Configure_UL_SW_Default_Value failed: no valid response found (mAVU_TDD_Extsw_Configure_UL_SW_Default_Value)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Configure_UL_SW_Default_ValueRsp._ret)

    def MAVU_TDD_DL_Extsw_Enable(self, dl_ext_sw, mask):
        _req = libtdd_pb2.MAVU_TDD_DL_Extsw_EnableReq()
        _req.dl_ext_sw = dl_ext_sw
        _req.mask = mask
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_DL_Extsw_EnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_DL_Extsw_EnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_DL_Extsw_Enable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_DL_Extsw_Enable failed: no valid response found (mAVU_TDD_DL_Extsw_Enable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_DL_Extsw_EnableRsp._ret)

    def MAVU_TDD_DL_Extsw_Disable(self, dl_ext_sw, mask):
        _req = libtdd_pb2.MAVU_TDD_DL_Extsw_DisableReq()
        _req.dl_ext_sw = dl_ext_sw
        _req.mask = mask
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_DL_Extsw_DisableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_DL_Extsw_DisableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_DL_Extsw_Disable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_DL_Extsw_Disable failed: no valid response found (mAVU_TDD_DL_Extsw_Disable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_DL_Extsw_DisableRsp._ret)

    def MAVU_TDD_UL_Extsw_Enable(self, ul_ext_sw, mask):
        _req = libtdd_pb2.MAVU_TDD_UL_Extsw_EnableReq()
        _req.ul_ext_sw = ul_ext_sw
        _req.mask = mask
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_UL_Extsw_EnableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_UL_Extsw_EnableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_UL_Extsw_Enable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_UL_Extsw_Enable failed: no valid response found (mAVU_TDD_UL_Extsw_Enable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_UL_Extsw_EnableRsp._ret)

    def MAVU_TDD_UL_Extsw_Disable(self, ul_ext_sw, mask):
        _req = libtdd_pb2.MAVU_TDD_UL_Extsw_DisableReq()
        _req.ul_ext_sw = ul_ext_sw
        _req.mask = mask
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_UL_Extsw_DisableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_UL_Extsw_DisableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_UL_Extsw_Disable failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_UL_Extsw_Disable failed: no valid response found (mAVU_TDD_UL_Extsw_Disable)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_UL_Extsw_DisableRsp._ret)

    def MAVU_TDD_Extsw_Enable_PL_Control(self):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Enable_PL_ControlReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Enable_PL_ControlReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Enable_PL_ControlRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Enable_PL_Control failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Enable_PL_Control failed: no valid response found (mAVU_TDD_Extsw_Enable_PL_Control)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Enable_PL_ControlRsp._ret)

    def MAVU_TDD_Extsw_Disable_PL_Control(self):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Disable_PL_ControlReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Disable_PL_ControlReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Disable_PL_ControlRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Disable_PL_Control failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Disable_PL_Control failed: no valid response found (mAVU_TDD_Extsw_Disable_PL_Control)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Disable_PL_ControlRsp._ret)

    def MAVU_TDD_Extsw_Read_Status(self):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Read_StatusReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Read_StatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Read_StatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Read_Status failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Read_Status failed: no valid response found (mAVU_TDD_Extsw_Read_Status)")
        return _rsp.mAVU_TDD_Extsw_Read_StatusRsp.status, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Read_StatusRsp._ret)

    def MAVU_TDD_Get_Num_SW_Points(self):
        _req = libtdd_pb2.MAVU_TDD_Get_Num_SW_PointsReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Get_Num_SW_PointsReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Get_Num_SW_PointsRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Get_Num_SW_Points failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Get_Num_SW_Points failed: no valid response found (mAVU_TDD_Get_Num_SW_Points)")
        return _rsp.mAVU_TDD_Get_Num_SW_PointsRsp.num_sw_points, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Get_Num_SW_PointsRsp._ret)

    def MAVU_TDD_Get_Num_Dl_Int_SW(self):
        _req = libtdd_pb2.MAVU_TDD_Get_Num_Dl_Int_SWReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Get_Num_Dl_Int_SWReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Get_Num_Dl_Int_SWRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Get_Num_Dl_Int_SW failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Get_Num_Dl_Int_SW failed: no valid response found (mAVU_TDD_Get_Num_Dl_Int_SW)")
        return _rsp.mAVU_TDD_Get_Num_Dl_Int_SWRsp.num_dl_int_sw, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Get_Num_Dl_Int_SWRsp._ret)

    def MAVU_TDD_Get_Num_Ul_Int_SW(self):
        _req = libtdd_pb2.MAVU_TDD_Get_Num_Ul_Int_SWReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Get_Num_Ul_Int_SWReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Get_Num_Ul_Int_SWRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Get_Num_Ul_Int_SW failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Get_Num_Ul_Int_SW failed: no valid response found (mAVU_TDD_Get_Num_Ul_Int_SW)")
        return _rsp.mAVU_TDD_Get_Num_Ul_Int_SWRsp.num_ul_int_sw, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Get_Num_Ul_Int_SWRsp._ret)

    def MAVU_TDD_Extsw_Get_Num_Dl_Ext_SW(self):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Get_Num_Dl_Ext_SWReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Get_Num_Dl_Ext_SWReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Get_Num_Dl_Ext_SWRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Get_Num_Dl_Ext_SW failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Get_Num_Dl_Ext_SW failed: no valid response found (mAVU_TDD_Extsw_Get_Num_Dl_Ext_SW)")
        return _rsp.mAVU_TDD_Extsw_Get_Num_Dl_Ext_SWRsp.num_dl_ext_sw, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Get_Num_Dl_Ext_SWRsp._ret)

    def MAVU_TDD_Extsw_Get_Num_Ul_Ext_SW(self):
        _req = libtdd_pb2.MAVU_TDD_Extsw_Get_Num_Ul_Ext_SWReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_Extsw_Get_Num_Ul_Ext_SWReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_Extsw_Get_Num_Ul_Ext_SWRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Extsw_Get_Num_Ul_Ext_SW failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Extsw_Get_Num_Ul_Ext_SW failed: no valid response found (mAVU_TDD_Extsw_Get_Num_Ul_Ext_SW)")
        return _rsp.mAVU_TDD_Extsw_Get_Num_Ul_Ext_SWRsp.num_ul_ext_sw, self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_Extsw_Get_Num_Ul_Ext_SWRsp._ret)

    def MAVU_TDD_FPGA_Static_Default_Config(self):
        _req = libtdd_pb2.MAVU_TDD_FPGA_Static_Default_ConfigReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_FPGA_Static_Default_ConfigReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_FPGA_Static_Default_ConfigRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_FPGA_Static_Default_Config failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_FPGA_Static_Default_Config failed: no valid response found (mAVU_TDD_FPGA_Static_Default_Config)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_FPGA_Static_Default_ConfigRsp._ret)

    def MAVU_TDD_Deinit(self):
        _req = libtdd_pb2.MAVU_TDD_DeinitReq()
        _inMsg = libtdd_pb2.libtddIn()
        _inMsg.mAVU_TDD_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libtdd_pb2.libtddOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_TDD_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_TDD_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_TDD_Deinit failed: no valid response found (mAVU_TDD_Deinit)")
        return self.TddReturnStatusType_toDict(_rsp.mAVU_TDD_DeinitRsp._ret)

