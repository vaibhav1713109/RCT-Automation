from etw.lib.etwproxy import EtwProxy, EtwError
from etw.lib.etwmodel import EtwModel
import time

class DmaChannel:
    dev = None
    model = None
    txBdRing = None
    txTaildescr = None
    regs = {}
    
    def __init__(self, model, dev=None):
        self.model = model
        self.dev = dev;
        self.regs = {}
        self.txBdRing = {}
        self.txTailDescr = {}
        self.rxBdRing = {}
        self.rxTailDescr = {}
        if model is not None and dev is not None:
            for regName, regDescr in model.model['devices'][dev]['registers'].items():
                reg = {'name' : regName}
                self.regs[regName] = reg
                fields = []
                for fieldName, fieldDescr in regDescr['fields'].items():
                    fields.append(fieldName)
                reg['fields'] = fields

    def readAllRegisters(self):
        result = {}
        for regName, regInfo in self.regs.items():
            result[regName] = {}
            for fieldName in regInfo['fields']:
                val = self.model.readRegister(self.dev, regName, fieldName)
                result[regName][fieldName] = val
        return result

    def reset(self):
        # Reset will affect both channels
        self.reset_mm2s()
        # self.reset_s2mm()
        
    def reset_mm2s(self):
        # Set reset bit
        self.model.writeRegister(1<<2, self.dev, 'mm2s_dmacr')
        
    def start_mm2s(self):
        # Set start bit
        self.model.writeRegister(1, self.dev, 'mm2s_dmacr','rs')
        
    def stop_mm2s(self):
        # Clear start bit
        self.model.writeRegister(0, self.dev, 'mm2s_dmacr','rs')
        
    def reset_s2mm(self):
        # Set reset bit
        self.model.writeRegister(1<<2, self.dev, 's2mm_dmacr')
        
    def start_s2mm(self):
        # Set start bit
        self.model.writeRegister(1, self.dev, 's2mm_dmacr','rs')
        
    def stop_s2mm(self):
        # Clear start bit
        self.model.writeRegister(0, self.dev, 's2mm_dmacr','rs')
        
    def set_dest_addr(self, addr):
        # Set address values
        self.model.writeRegister(int(addr & 0x0FFFFFFFF), self.dev, 's2mm_da','address')
        self.model.writeRegister(int(addr >> 32), self.dev, 's2mm_da_msb','address')
        
    def set_source_addr(self, addr):
        # Set address values
        self.model.writeRegister(int(addr & 0x0FFFFFFFF), self.dev, 'mm2s_sa','address')
        self.model.writeRegister(int(addr >> 32), self.dev, 'mm2s_sa_msb','address')
        
    def set_dest_length(self, length):
        # Set length value
        self.model.writeRegister(length, self.dev, 's2mm_length','length')
        
    def set_source_length(self, length):
        # Set length value
        self.model.writeRegister(length, self.dev, 'mm2s_length','length')

    def createTxBdRing(self, ddrBufAddr, ddrBufLen, sgBufLen=16384, memDev = 'CMA'):
        numDescr = int((ddrBufLen + sgBufLen - 1) / sgBufLen)
        maxNumDescr = 65535
        # print(ddrBufLen)
        # print(sgBufLen)
        # print(numDescr)
        if numDescr > maxNumDescr:
            raise EtwError("Too many BD Descriptors: {} (max for {} is {}".format(numDescr, memDev, maxNumDescr))
        if not self.txBdRing.get(memDev):
            # Allocate a buffer for first BD
            self.txBdRing[memDev] = self.model.proxy.allocBuf(maxNumDescr * 64, dev=memDev)
            # Create tail descriptor for cyclic transfer
            self.txTailDescr[memDev] = self.txBdRing[memDev] + maxNumDescr * 64;

        descrAddr = []
        bufAddr = []
        bufLen = []
        descrAddr.append(self.txBdRing[memDev])              # First BD
        bufAddr.append(ddrBufAddr)
        bufLen.append(sgBufLen)
        
        for i in range(numDescr - 1):
            descrAddr.append(descrAddr[i] + 64)
            bufAddr.append(bufAddr[i] + bufLen[i])
            bufLen.append(bufLen[i])
        bufLen[numDescr - 1] += ddrBufLen - bufLen[0] * numDescr

        # Empty byte array
        descrData = bytearray()

        for i in range(numDescr):
            next = i + 1
            if next == numDescr:
                next = 0
            # First descriptor in ring
            value = descrAddr[next] & 0xFFFFFFFF
            descrData += value.to_bytes(4, 'little')        # NXTDESC (00h)
            descrData += bytearray(4)                       # NXT_DESCR_MSB (04h)
            value = bufAddr[i] & 0xFFFFFFFF
            descrData += value.to_bytes(4, 'little')        # BUFFER_ADDR (08h)
            descrData += bytearray(12)                      # BUFFER_ADDR_MSB (0Ch), RESERVED (10h), RESERVED (14h)
            if i == 0:
                value = 0x08000000 + bufLen[i]              # TXSOF=1
            elif next == 0:
                value = 0x04000000 + bufLen[i]              # TXEOF=1
            else:
                value = bufLen[i]
            descrData += value.to_bytes(4, 'little')        # CONTROL (18h)
            descrData += bytearray(36)                      # STATUS (1Ch), APP0-APP4 (20h-30h), Zero Fill (34h-3Ch)
            # print("descr[{}] = 0x{:08X}".format(i, descrAddr[i]))
            # print("next[{}] = 0x{:08X}".format(i, descrAddr[next]))
            # print("buf[{}] = 0x{:08X}".format(i, bufAddr[i]))
            # print("len[{}] = 0x{:08X}".format(i, bufLen[i]))
        
        descrData += bytearray(64) # Zero fill 64 bytes
        
        numWrite = self.model.proxy.writeToBuf(self.txBdRing[memDev], bytes(descrData), dev=memDev)
        return descrAddr[0], descrAddr[numDescr - 1], self.txTailDescr[memDev]

    def createRxBdRing(self, ddrBufAddr, ddrBufLen, sgBufLen=16384, memDev = 'CMA'):
        numDescr = int((ddrBufLen + sgBufLen - 1) / sgBufLen)
        # print("NumDescr = {}".format(numDescr))
        maxNumDescr = 65535
        if numDescr > maxNumDescr:
            raise EtwError("Too many BD Descriptors: {} (max for {} is {}".format(numDescr, memDev, maxNumDescr))
        if not self.rxBdRing.get(memDev):
            # Allocate a buffer for first BD
            self.rxBdRing[memDev] = self.model.proxy.allocBuf(maxNumDescr * 64, dev=memDev)
            # Create tail descriptor for cyclic transfer
            self.rxTailDescr[memDev] = self.rxBdRing[memDev] + maxNumDescr * 64;

        descrAddr = []
        bufAddr = []
        bufLen = []
        descrAddr.append(self.rxBdRing[memDev])              # First BD
        bufAddr.append(ddrBufAddr)
        bufLen.append(sgBufLen)
        
        for i in range(numDescr - 1):
            descrAddr.append(descrAddr[i] + 64)
            bufAddr.append(bufAddr[i] + bufLen[i])
            bufLen.append(bufLen[i])
        bufLen[numDescr - 1] += ddrBufLen - bufLen[0] * numDescr

        # Empty byte array
        descrData = bytearray()

        for i in range(numDescr):
            next = i + 1
            if next == numDescr:
                next = 0
            # First descriptor in ring
            value = descrAddr[next] & 0xFFFFFFFF
            descrData += value.to_bytes(4, 'little')        # NXTDESC (00h)
            descrData += bytearray(4)                       # NXT_DESCR_MSB (04h)
            value = bufAddr[i] & 0xFFFFFFFF
            descrData += value.to_bytes(4, 'little')        # BUFFER_ADDR (08h)
            descrData += bytearray(12)                      # BUFFER_ADDR_MSB (0Ch), RESERVED (10h), RESERVED (14h)
            value = bufLen[i]
            descrData += value.to_bytes(4, 'little')        # CONTROL (18h)
            descrData += bytearray(36)                      # STATUS (1Ch), APP0-APP4 (20h-30h), Zero Fill (34h-3Ch)
            # print("descr[{}] = 0x{:08X}".format(i, descrAddr[i]))
            # print("next[{}] = 0x{:08X}".format(i, descrAddr[next]))
            # print("buf[{}] = 0x{:08X}".format(i, bufAddr[i]))
            # print("len[{}] = 0x{:08X}".format(i, bufLen[i]))
        
        descrData += bytearray(64) # Zero fill 64 bytes
        
        numWrite = self.model.proxy.writeToBuf(self.rxBdRing[memDev], bytes(descrData), dev=memDev)
        # print("BD = 0x{:08X}, Tail = {:08X}".format(self.rxBdRing[memDev], self.rxTailDescr[memDev]))
        return descrAddr[0], descrAddr[numDescr - 1], self.rxTailDescr[memDev]


    def freeMem(self):
        try:
            for memDev in self.txBdRing:
                self.model.proxy.freeBuf(self.txBdRing[memDev])
            self.txBdRing = {}
            for memDev in self.rxBdRing:
                self.model.proxy.freeBuf(self.rxBdRing[memDev])
            self.rxBdRing = {}
        except:
            pass


    def transferFromDDR(self, ddrAddr, dataLen, cyclic = False, sgBufLen=8192, memDev = 'CMA'):
        if dataLen == 0:
            return
        # self.reset_mm2s()

        if cyclic and dataLen <= sgBufLen:
            # Ensure at least two BDs in cyclic mode
            sgBufLen = max(1, int((dataLen + 1) / 2))
            
        firstDescr, lastDescr, tailDescr = self.createTxBdRing(ddrAddr, dataLen, sgBufLen = sgBufLen, memDev = memDev)
        self.model.writeRegister(firstDescr & 0xFFFFFFFF, self.dev, 'mm2s_curdesc')
        if cyclic:
            self.model.writeRegister(1, self.dev, 'mm2s_dmacr', 'cyclic_bd')
        else:
            self.model.writeRegister(0, self.dev, 'mm2s_dmacr', 'cyclic_bd')
            tailDescr = lastDescr
        self.start_mm2s()
        self.model.writeRegister(tailDescr & 0xFFFFFFFF, self.dev, 'mm2s_taildesc')
        
    def transferToDDR(self, ddrAddr, dataLen, sgBufLen=4096, memDev = 'CMA'):
        # self.reset_s2mm()
        firstDescr, lastDescr, tailDescr = self.createRxBdRing(ddrAddr, dataLen, sgBufLen = sgBufLen, memDev = memDev)
        self.model.writeRegister(firstDescr & 0xFFFFFFFF, self.dev, 's2mm_curdesc')
        self.model.writeRegister(0, self.dev, 's2mm_dmacr', 'cyclic_bd')
        self.start_s2mm()
        self.model.writeRegister(lastDescr & 0xFFFFFFFF, self.dev, 's2mm_taildesc')
        
    def printRegisters(self):
        for regName, fields in self.readAllRegisters().items():
            for fieldName, value in fields.items():
                print("%s.%s = %d" % (regName, fieldName, value))

