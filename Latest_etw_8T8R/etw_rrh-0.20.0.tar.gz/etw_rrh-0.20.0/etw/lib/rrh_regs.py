from etw.lib.etwproxy import EtwProxy, EtwError

class FpgaReg:
    
    FPGA_CLOCK_BASEADDR = 0XC001000
    ClockCtrlOffset = 0X0000
    ClockPllResetBit = 1 << 0
    ClockSysResetBit = 1 << 1
    ClockStatusOffset = 0X0008
    ClockRxPllLockBit = 1 << 0
    ClockTxPllLockBit = 1 << 1
    
    def connect(self, target):
        self.proxy = EtwProxy(target.ip_address, target.port)
        self.proxy.connect()

    def disconnect(self):
        self.proxy.disconnect()
        
    def clockAddr(self, offset):
        return self.FPGA_CLOCK_BASEADDR + offset

    def readRegister(self, addr, mask=0xffffffff):
        val = self.proxy.readU32(addr, mask)
        return val

    def writeRegister(self, addr, value, mask=0):
        self.proxy.writeU32(value, addr, mask)
   
