from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libprach_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libprachProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibprach", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = libprach_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", 0))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def DfePrach_Init(self):
        _req = libprach_pb2.DfePrach_InitReq()
        _inMsg = libprach_pb2.libprachIn()
        _inMsg.dfePrach_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libprach_pb2.libprachOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfePrach_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfePrach_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("DfePrach_Init failed: no valid response found (dfePrach_Init)")
        return self.returnStatusType_toDict(_rsp.dfePrach_InitRsp._ret)

    def DfePrach_Deinit(self):
        _req = libprach_pb2.DfePrach_DeinitReq()
        _inMsg = libprach_pb2.libprachIn()
        _inMsg.dfePrach_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libprach_pb2.libprachOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfePrach_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfePrach_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("DfePrach_Deinit failed: no valid response found (dfePrach_Deinit)")
        return self.returnStatusType_toDict(_rsp.dfePrach_DeinitRsp._ret)

    def DfePrachConfigL1Phy(self, samplesPerTs, CpLengthTs, NumOfRepetitions, Prach_SCS_Hz, GpLengthTs, NumberOfOccasions):
        _req = libprach_pb2.DfePrachConfigL1PhyReq()
        _req.samplesPerTs = samplesPerTs
        _req.CpLengthTs = CpLengthTs
        _req.NumOfRepetitions = NumOfRepetitions
        _req.Prach_SCS_Hz = Prach_SCS_Hz
        _req.GpLengthTs = GpLengthTs
        _req.NumberOfOccasions = NumberOfOccasions
        _inMsg = libprach_pb2.libprachIn()
        _inMsg.dfePrachConfigL1PhyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libprach_pb2.libprachOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfePrachConfigL1PhyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfePrachConfigL1Phy failed: " + _rsp.zzerr_msg)
            raise EtwError("DfePrachConfigL1Phy failed: no valid response found (dfePrachConfigL1Phy)")
        return self.returnStatusType_toDict(_rsp.dfePrachConfigL1PhyRsp._ret)

    def DfePrachRemapCcid(self, subsystem, ccfIndex, ccfCcid, mixerCcid):
        _req = libprach_pb2.DfePrachRemapCcidReq()
        _req.subsystem = subsystem
        _req.ccfIndex = ccfIndex
        _req.ccfCcid = ccfCcid
        _req.mixerCcid = mixerCcid
        _inMsg = libprach_pb2.libprachIn()
        _inMsg.dfePrachRemapCcidReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libprach_pb2.libprachOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfePrachRemapCcidRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfePrachRemapCcid failed: " + _rsp.zzerr_msg)
            raise EtwError("DfePrachRemapCcid failed: no valid response found (dfePrachRemapCcid)")
        return _rsp.dfePrachRemapCcidRsp._ret

