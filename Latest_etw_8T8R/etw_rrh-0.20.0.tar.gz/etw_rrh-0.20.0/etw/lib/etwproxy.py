import socket
import ssl
import sys
import struct
import time
import platform
from os import path

from etw.lib import dbusgw_pb2
from etw.lib import etw_pb2

from google.protobuf.internal import encoder
from google.protobuf.internal import decoder

tcp_port = 59875
ssl_port = 59876

class EtwError(Exception):
    def __init__(self, message):
        self.message = message
        
class IpcLink:
    def __init__(self, host, port, ssl_cert=None):
        self.host = host
        self.port = port
        self.use_ssl = port == ssl_port
        self.pltfrm = platform.system()
        self.sock = None
        self._sock = None
        self.ssl_cert_path = None

        if self.use_ssl:
            if ssl_cert is None:
                dirs = ['.']
                if self.pltfrm  == "Linux":
                    dirs.append('/etc/ssl/certs')
                    dirs.append(path.dirname(path.abspath(__file__)))
                for p in dirs:
                    ssl_cert = path.join(p, 'etw_cert.pem')
                    if path.exists(ssl_cert):
                        break;
            if (not path.exists(ssl_cert)):
                raise EtwError(f'No ETW SSL certificate found in: {dirs}')
            self.ssl_cert_path = ssl_cert
        
        if not self.use_ssl and self.pltfrm == "Linux":
            self.hasSendMsg = True
        else:
            self.hasSendMsg = False

    def connect(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = (self.host, self.port)

        if self.use_ssl:
            hostname = 'etw.ru.mavenir.com'
            # PROTOCOL_TLS_CLIENT requires valid cert chain and hostname
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            try:
                context.load_verify_locations(self.ssl_cert_path)
            except Exception as e:
                raise EtwError(f'ETW ssl certificate not found ({self.ssl_cert_path}): {e}') 
            self.sock = context.wrap_socket(self._sock, server_hostname=hostname)
        else:
            self.sock = self._sock
            
        try:
            self.sock.connect(server_address)
        except Exception as e:
            raise EtwError("connection failed: " + str(e)) 

    def disconnect(self):
        try:
            self.sock.close()
        except Exception as e:
            raise EtwError("disconnect failed: " + str(e)) 
        
    def read_varint(self):
        try:
            size = 0
            base = 1;
            while True:
                v, = struct.unpack('b', self.sock.recv(1))
                size += (v & 0x7f) * base        
                base *= 128;
                if not v & 0x80:
                    break;
            return size
        except Exception as e:
            raise EtwError("target communication failed: " + str(e))

    def recv_msg(self):
        try:
            size = self.read_varint()
            data = []
            while size:
                buf = self.sock.recv(size)
                if not buf:
                    raise EtwError("Buffer receive truncated")
                data.append(buf)
                size -= len(buf)
            return b''.join(data)
        except EtwError:
            raise
        except Exception as e:
            raise EtwError("target communication failed: " + str(e))

    def send_msg(self, payload):
        try:
            size = len(payload)
            if self.hasSendMsg:
                self.sock.sendmsg([bytes(encoder._VarintBytes(size)), payload])
            else:
                self.sock.sendall(bytes(encoder._VarintBytes(size)) + payload)
                
        except Exception as e:
            raise EtwError("target communication failed: " + str(e))

class DBusGwProxy():
    link = None
    proto_name = None

    def __init__(self, link, service_name = "etwserver", proto_name="etwserver", method_call="MethodCall"):
        self.link = link
        self.service_name = service_name
        self.proto_name = proto_name
        self.method_call = method_call

    def connect(self):
        self.link.connect()

    def disconnect(self):
        self.link.disconnect()

    def methodCall(self, reqMsg, rspCls):
        # prepare method call
        call = dbusgw_pb2.MethodCallReq()
        call.seq_no = 1
        call.service = 'com.mavenir.rru.' + self.service_name
        call.obj_path = '/com/mavenir/rru/' + self.proto_name
        call.interface = 'com.mavenir.rru.' + self.proto_name
        call.method = self.method_call
        call.payload = reqMsg.SerializeToString()

        # wrap and send it
        dbusGwIn = dbusgw_pb2.DBusGwIn()
        dbusGwIn.methodCallReq.CopyFrom(call)
        self.link.send_msg(dbusGwIn.SerializeToString())

        # wait for response
        dbusGwOut = dbusgw_pb2.DBusGwOut()
        dbusGwOut.ParseFromString(self.link.recv_msg())
        if dbusGwOut.methodCallRsp:
            rsp = rspCls()
            rsp.ParseFromString(dbusGwOut.methodCallRsp.payload)
            return rsp
        else:
            raise EtwError("invalid target response")


class EtwProxy():
    def __init__(self, host="127.0.0.1", port=tcp_port, ipcLink=None):
        if not ipcLink:
            ipcLink = IpcLink(host, port)
        self.ipc_link = ipcLink
        self.__gw = DBusGwProxy(self.ipc_link)

    def connect(self):
        self.__gw.connect()

    def disconnect(self):
        self.__gw.disconnect()

    def readU32(self, addr, mask=0, dev='AXI'):
        read = etw_pb2.ReadU32Req();
        read.dev = dev
        read.addr = addr
        read.mask = mask
        etwIn = etw_pb2.EtwIn();
        etwIn.readU32Req.CopyFrom(read);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.readU32Rsp:
            raise EtwError("readU32 failed: " + rsp.err_msg)
        if not rsp.readU32Rsp.ok:
            raise EtwError("readU32 failed: " + rsp.readU32Rsp.err_msg)
        return rsp.readU32Rsp.val
            
    def writeU32(self, val, addr, mask=0, dev='AXI'):
        write = etw_pb2.WriteU32Req();
        write.dev = dev
        write.addr = addr
        write.mask = mask
        write.val = val
        etwIn = etw_pb2.EtwIn();
        etwIn.writeU32Req.CopyFrom(write);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        #       print rsp.__str__()
        if not rsp.writeU32Rsp:
            raise EtwError("writeU32 failed: " + rsp.err_msg)
        if not rsp.writeU32Rsp.ok:
            raise EtwError("writeU32 failed: " + rsp.writeU32Rsp.err_msg)
            
    def readU8(self, addr, mask=0, dev='AXI'):
        read = etw_pb2.ReadU8Req();
        read.dev = dev
        read.addr = addr
        read.mask = mask
        etwIn = etw_pb2.EtwIn();
        etwIn.readU8Req.CopyFrom(read);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.readU8Rsp:
            raise EtwError("readU8 failed: " + rsp.err_msg)
        if not rsp.readU8Rsp.ok:
            raise EtwError("readU8 failed: " + rsp.readU8Rsp.err_msg)
        return rsp.readU8Rsp.val
            
    def writeU8(self, val, addr, mask=0, dev='AXI'):
        write = etw_pb2.WriteU8Req();
        write.dev = dev
        write.addr = addr
        write.mask = mask
        write.val = val
        etwIn = etw_pb2.EtwIn();
        etwIn.writeU8Req.CopyFrom(write);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        #       print rsp.__str__()
        if not rsp.writeU8Rsp:
            raise EtwError("writeU8 failed: " + rsp.err_msg)
        if not rsp.writeU8Rsp.ok:
            raise EtwError("writeU8 failed: " + rsp.writeU8Rsp.err_msg)
            
    def allocBuf(self, size, dev='CMA'):
        alloc = etw_pb2.AllocBufReq();
        alloc.dev = dev
        alloc.size = size
        etwIn = etw_pb2.EtwIn();
        etwIn.allocBufReq.CopyFrom(alloc);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        #       print rsp.__str__()
        if not rsp.allocBufRsp:
            raise EtwError("allocBuf failed: " + rsp.err_msg)
        if not rsp.allocBufRsp.ok:
            raise EtwError("allocBuf failed: " + rsp.allocBufRsp.err_msg)
        return rsp.allocBufRsp.addr 
            
    def freeBuf(self, addr, dev='CMA'):
        free = etw_pb2.FreeBufReq();
        free.dev = dev
        free.addr = addr
        etwIn = etw_pb2.EtwIn();
        etwIn.freeBufReq.CopyFrom(free);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        #       print rsp.__str__()
        if not rsp.freeBufRsp:
            raise EtwError("freeBuf failed: " + rsp.err_msg)
        if not rsp.freeBufRsp.ok:
            raise EtwError("freeBuf failed: " + rsp.freeBufRsp.err_msg)


    def freeAll(self, dev='CMA'):
        for buf in self.listBuf(dev):
            self.freeBuf(buf.addr, dev)
        
    def listBuf(self, dev='CMA'):
        list = etw_pb2.ListBufReq();
        list.dev = dev
        etwIn = etw_pb2.EtwIn();
        etwIn.listBufReq.CopyFrom(list);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        #       print rsp.__str__()
        if not rsp.listBufRsp:
            raise EtwError("listBuf failed: " + rsp.err_msg)
        if not rsp.listBufRsp.ok:
            raise EtwError("listBuf failed: " + rsp.listBufRsp.err_msg)
        return rsp.listBufRsp.buffers 
            
    def writeToBuf(self, addr, data, chunk_size=150000, dev='CMA'):
        data_len = len(data)
        if chunk_size == 0:
            chunk_size = data_len
        ix = 0
        tot_write = 0
        while data_len > 0:
            if data_len < chunk_size:
                chunk_size = data_len;
            write = etw_pb2.WriteToBufReq();
            write.dev = dev
            write.addr = addr
            write.data = data[ix:ix+chunk_size]
            etwIn = etw_pb2.EtwIn();
            # print(write.__str__())
            etwIn.writeToBufReq.CopyFrom(write);
            rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
            # print(rsp.__str__())
            if not rsp.writeToBufRsp:
                raise EtwError("writeToBuf failed: " + rsp.err_msg)
            if not rsp.writeToBufRsp.ok:
                raise EtwError("writeToBuf failed: " + rsp.writeToBufRsp.err_msg)
            n = rsp.writeToBufRsp.num_write
            # print("ix = %d, data_len = %d, chunk = %d, n=%d" % (ix, data_len, chunk_size, n))
            data_len = data_len - chunk_size
            if n == 0:
                data_len = 0
            addr = addr + n
            ix = ix + n
            tot_write = tot_write + n
        return tot_write
            
    def readFromBuf(self, addr, length, chunk_size=150000, dev='CMA'):
        data_len = length
        if chunk_size == 0:
            chunk_size = data_len
        ix = 0
        result = bytes()
        while data_len > 0:
            if data_len < chunk_size:
                chunk_size = data_len;
            read = etw_pb2.ReadFromBufReq();
            read.dev = dev
            read.addr = addr
            read.len = chunk_size
            etwIn = etw_pb2.EtwIn();
            # print(read.__str__())
            etwIn.readFromBufReq.CopyFrom(read);
            rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
            # print(rsp.__str__())
            if not rsp.readFromBufRsp:
                raise EtwError("readFromBuf failed: " + rsp.err_msg)
            if not rsp.readFromBufRsp.ok:
                raise EtwError("readFromBuf failed: " + rsp.readFromBufRsp.err_msg)
            n = len(rsp.readFromBufRsp.data)
            result = result + rsp.readFromBufRsp.data
            data_len = data_len - chunk_size
            if n == 0:
                data_len = 0
            addr = addr + n
        return result


    def saveBufToFile(self, path, addr, len, dev='CMA'):
        save = etw_pb2.SaveBufToFileReq();
        save.dev = dev
        save.file_path = path
        save.addr = addr
        save.len = len
        etwIn = etw_pb2.EtwIn()
        etwIn.saveBufToFileReq.CopyFrom(save);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.saveBufToFileRsp:
            raise EtwError("saveBufToFile failed: " + rsp.err_msg)
        if not rsp.saveBufToFileRsp.ok:
            raise EtwError("saveBufToFile failed: " + rsp.saveBufToFileRsp.err_msg)
        return rsp.saveBufToFileRsp.num_write
            
    def loadFileToBuf(self, path, addr = 0, len = 0, dev='CMA'):
        load = etw_pb2.LoadFileToBufReq();
        load.dev = dev
        load.file_path = path
        load.addr = addr
        load.len = len
        etwIn = etw_pb2.EtwIn()
        etwIn.loadFileToBufReq.CopyFrom(load);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.loadFileToBufRsp:
            raise EtwError("loadFileToBuf failed: " + rsp.err_msg)
        if not rsp.loadFileToBufRsp.ok:
            raise EtwError("loadFileToBuf failed: " + rsp.loadFileToBufRsp.err_msg)
        return rsp.loadFileToBufRsp.addr, rsp.loadFileToBufRsp.num_read
            
    def lockDev(self, dev, wait=False):
        lock = etw_pb2.LockDevReq();
        lock.dev = dev
        lock.wait = wait
        etwIn = etw_pb2.EtwIn();
        etwIn.lockDevReq.CopyFrom(lock);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        if not rsp.lockDevRsp:
            raise EtwError("lockDev failed: " + rsp.err_msg)
        if not rsp.lockDevRsp.ok:
            raise EtwError("lockDev failed: " + rsp.lockDevRsp.err_msg)
            
    def unlockDev(self, dev):
        unlock = etw_pb2.UnlockDevReq();
        unlock.dev = dev
        etwIn = etw_pb2.EtwIn();
        etwIn.unlockDevReq.CopyFrom(unlock);
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        if not rsp.unlockDevRsp:
            raise EtwError("unlockDev failed: " + rsp.err_msg)
        if not rsp.unlockDevRsp.ok:
            raise EtwError("unlockDev failed: " + rsp.unlockDevRsp.err_msg)
            
    def readDir(self, dir="/"):
        read = etw_pb2.ReadDirReq();
        read.dir_path = dir
        etwIn = etw_pb2.EtwIn();
        etwIn.readDirReq.CopyFrom(read);
        # print etwIn.__str__()
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.readDirRsp:
            raise EtwError("readDir failed: " + rsp.err_msg)
        if not rsp.readDirRsp.ok:
            raise EtwError("readDir failed: " + rsp.readDirRsp.err_msg)
        return rsp.readDirRsp.files, rsp.readDirRsp.dirs
            
    def execCmd(self, cmd, params = "", run_in_bg = False):
        execReq = etw_pb2.ExecCmdReq();
        execReq.cmd = cmd
        execReq.params = params;
        execReq.run_in_background = run_in_bg;
        etwIn = etw_pb2.EtwIn();
        etwIn.execCmdReq.CopyFrom(execReq);
        # print etwIn.__str__()
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        # print rsp.__str__()
        if not rsp.execCmdRsp:
            raise EtwError("execCmd failed: " + rsp.err_msg)
        if not rsp.execCmdRsp.ok:
            raise EtwError("execCmd failed: " + rsp.execCmdRsp.err_msg)
        return rsp.execCmdRsp.exit_code, rsp.execCmdRsp.output

    def loadPlugin(self, type, name, path):
        loadReq = etw_pb2.LoadPluginReq();
        loadReq.type = type
        loadReq.name = name
        loadReq.path = path
        etwIn = etw_pb2.EtwIn();
        etwIn.loadPluginReq.CopyFrom(loadReq);
        # print etwIn.__str__()
        rsp = self.__gw.methodCall(etwIn, etw_pb2.EtwOut)
        print(rsp.__str__())
        if not rsp.loadPluginRsp:
            raise EtwError("loadPlugin failed: " + rsp.err_msg)
        if not rsp.loadPluginRsp.ok:
            raise EtwError("loadPlugin failed: " + rsp.loadPluginRsp.err_msg)
