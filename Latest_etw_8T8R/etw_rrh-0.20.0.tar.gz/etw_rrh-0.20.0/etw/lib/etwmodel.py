from os.path import dirname, abspath, join
from os import path
import xml.etree.ElementTree as ET
from etw.lib.etwproxy import EtwProxy, EtwError
import re

def log(str):
    print(str)

class EtwModel:
    def __init__(self, file = None, proxy = None):
        try:
            self.model = {}
            self.cache = {}
            self.proxy = proxy
            self.log_write = False
            self.log_action_enabled = False
            self.log = log

            if not file:
                file_path = self._get_model_path('axi_dev_model.xml')
            elif path.exists(file):
                file_path = file
            else:
                file_path = self._get_model_path(file)
                
            tree = ET.parse(file_path)
            root = tree.getroot()
            self.model['device_types'] = self.getDevTypeMap(root)
            self.model['devices'] = self.getDeviceMap(root)

            if not file:
                try:
                    self.append('axi_dma.xml')
                except:
                    pass

        except Exception as e:
            raise e # EtwError("Could not create model: " + str(e))

    def log_action(self, action, dev, reg, field, addr, mask, value):
        if not self.log_action_enabled:
            return
        self.log(f'{action}: {dev}.{reg}.{field} [{addr:08X}/{mask:08X}] = 0x{value:08X} ({value})')
        
    @staticmethod
    def _get_model_path(file):
        parent_dir = dirname(abspath(__file__))
        return join(parent_dir, file)

    def append(self, file):
        if file and path.exists(file):
            file_path = file
        else:
            file_path = self._get_model_path(file)
        tree = ET.parse(file_path)
        root = tree.getroot()
        self.model['device_types'].update(self.getDevTypeMap(root))
        self.model['devices'].update(self.getDeviceMap(root))

    def connect(self, target):
        self.proxy = EtwProxy(target.ip_address, target.port)
        self.proxy.connect()

    def disconnect(self):
        self.proxy.disconnect()

    def updateCache(self, value, dev, reg):
        self.cache[dev + "." + reg] = value

    def getFromCache(self, dev, reg, default):
        return self.cache.get(dev + "." + reg, default)

    def readRegister(self, dev, reg, field=None, mask=0):
        regInfo,fieldInfo = self.getRegisterInfo(dev, reg, field)
        addr=regInfo['addr']
        val = self.proxy.readU32(addr=addr, mask=mask)
        if mask == 0:
            self.updateCache(val, dev, reg)
            if fieldInfo:
                mask = fieldInfo['mask']
                val = (val & mask) >> fieldInfo['bit_lo']
        self.log_action("read", dev, reg, field, addr, mask, val)
        return val

    def fieldValueToString(self, value, fieldInfo):
        value_str = str(value)
        for n,v in fieldInfo['values'].items():
            if (value == v):
                value_str = n
                break
        return value_str

    def fieldValueNameToInt(self, valueName, fieldInfo):
        value = fieldInfo['values'].get(valueName)
        if value is None:
            raise EtwError("No such pre-defined value: " + str(valueName));
        return value

    def writeRegister(self, value, dev, reg, field=None, mask=0):
        regInfo,fieldInfo = self.getRegisterInfo(dev, reg, field)
        addr=regInfo['addr']
        if not fieldInfo:
            if self.log_write:
                self.log(f'{dev}.{reg} <= 0x{value:08X} ({value})')
            self.log_action("write", dev, reg, field, addr, mask, value)
            self.proxy.writeU32(value, addr=addr, mask=mask)
            if mask == 0:
                self.updateCache(value, dev, reg)
        else:
            mask=fieldInfo['mask']
            if not isinstance(value, int):
                value = self.fieldValueNameToInt(value, fieldInfo)
            if self.log_write:
                value_str = self.fieldValueToString(value, fieldInfo)
                self.log(f'{dev}.{reg}.{field} <= 0x{value:08X} ({value_str})')
            self.log_action("write", dev, reg, field, addr, mask, value)
            self.proxy.writeU32(value, addr=addr, mask=mask)

    def getRegister(self, dev, reg, field=None):
        val = self.getFromCache(dev, reg)
        if not val:
            val = self.readRegister(dev, reg)
        if field:
            regInfo,fieldInfo = self.getRegisterInfo(dev, reg, field)
            val = (regVal & fieldInfo['mask']) >> fieldInfo['bit_lo']
        return val

    def setInCache(self, value, dev, reg, field=None):
        if field:
            cached_val = getFromCache(dev, reg, 0)
            regInfo,fieldInfo = self.getRegisterInfo(dev, reg, field)
            mask = fieldInfo['mask']
            value = (cached_val & ~mask) | ((value << fieldInfo['bit_lo']) & mask)
        self.updateCache(value, dev, reg)

    def getDeviceInstances(self, name, max = 16):
        result = []
        for instNo in range(max):
            dev = name + '-' + str(instNo)
            devInfo = self.model['devices'].get(dev)
            if not devInfo:
                break;
            result.append(dev)
        return result

    def getRegisterInfo(self, dev, reg, field=None):
        fieldInfo = None
        devInfo = self.model['devices'].get(dev)
        if not devInfo:
            raise EtwError("No such device: " + dev)
        regInfo = devInfo['registers'].get(reg)
        if not regInfo:
            raise EtwError("No such register: " + dev + "." + reg)
        if (field):
            fieldInfo = regInfo['fields'].get(field)
            if not fieldInfo:
                raise EtwError("No such field: " + dev + "." + reg + "." + field)
        return regInfo, fieldInfo

    def getDevTypeMap(self, top):
        devTypes = {}
        devTypes_top = top.find('device_types')
        if devTypes_top is None:
            return devTypes
        for e in devTypes_top.findall('device_type'):
            name = e.get('name')
            devTypes[name] = {'name' : name };
            devTypes[name]['registers'] = self.getRegDescrMap(e)
        return devTypes
    
    def getRegDescrMap(self, top):
        regs = {}
        regs_top = top.find('registers')
        if regs_top is None:
            return regs
        for e in regs_top.findall('register'):
            name = e.get('name')
            offs = int(e.get('offs'), 0)
            access = e.get('access')
            regs[name] = {'name' : name, 'offs' : offs, 'access' : access }
            regs[name]['fields'] = self.getRegFieldDescrMap(e)
        return regs

    def bits2mask(self, hi, lo):
        mask = 0xffffffff >> (31 - hi);
        mask &= ~((1 << lo) - 1);
        return mask;

    def getRegFieldDescrMap(self, top):
        fields = {}
        fields_top = top.find('fields')
        if fields_top is None:
            return fields
        for e in fields_top.findall('field'):
            name = e.get('name')
            bits = e.get('bits').split(':')
            bit_hi = int(bits[0])
            bit_lo = int(bits[1])
            mask = self.bits2mask(bit_hi, bit_lo)
            access = e.get('access')
            fields[name] = {'name' : name, 'bit_hi' : bit_hi, 'bit_lo' : bit_lo, 'mask' : mask, 'access' : access }
            fields[name]['values'] = self.getPredefinedValues(e)
        return fields

    def getPredefinedValues(self, top):
        values = {}
        for e in top.findall('predefined_value'):
            name = e.get('name')
            values[name] = int(e.get('value'), 0)
        return values

    def getDeviceMap(self, top):
        devices = {}
        for e in top.find('devices').findall('device'):
            name = e.get('name')
            t = e.get('type')
            base = int(e.get('base', "0"), 0)
            if base == 0:
                dev = self.model.get('devices', {}).get(name)
                if dev is not None:
                    # print("Re-use base addr: %s:%s" % (name, base))
                    base = dev['base']
                else:
                    # print("Illegal base addr: %s:%s" % (name, base))
                    pass

            instCount = int(e.get('instances', '1'), 0)
            for instNo in range(instCount):
                if not e.get('instances') or instCount == 1 and re.match("(\w+)-(\d+)$", name):
                    instName = name
                else:
                    instName = name + '-' + str(instNo)
                devices[instName] = {'name' : instName, 'type' : t, 'base' : base }
                devices[instName]['registers'], regSpaceSize = self.getDeviceRegisters(devices[instName])
                # print("Added device: %s@0x%X" % (instName, base))
                base = base + regSpaceSize
        return devices
    
    def getDeviceRegisters(self, device):
        regs = {}
        base = device['base']
        regSpaceSize = 0;
        devType = self.model['device_types'][device['type']]
        for regName, regDescr in devType['registers'].items():
            offs = regDescr['offs']
            regs[regName] = {'name' : regName, 'type' : devType['name'], 'addr' : base + offs}
            regs[regName]['fields'] = self.getRegisterFields(regDescr)
            if (offs + 4 > regSpaceSize):
                regSpaceSize = offs + 4
        return regs, regSpaceSize

    def getRegisterFields(self, regDescr):
        fields = {}
        for fieldName, fieldDescr in regDescr['fields'].items():
            fields[fieldName] = fieldDescr
        return fields
