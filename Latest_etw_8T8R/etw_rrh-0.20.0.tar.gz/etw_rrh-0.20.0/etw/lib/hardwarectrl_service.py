from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import hardwarectrl_service_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class hardwarectrl_serviceProxy:
    def __init__(self, ipcLink, service_name = "hardwarectrl"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "hardwarectrl", method_call="Method")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def AvailableHardwareComponentsReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AvailableHardwareComponentsReq()
        if not dict: return x
        return x

    def AvailableHardwareComponentsRsp_HardwareComponent_Parent_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AvailableHardwareComponentsRsp_HardwareComponent_Parent()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "class", dict.get("class", 0))
        return x

    def AvailableHardwareComponentsRsp_HardwareComponent_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AvailableHardwareComponentsRsp_HardwareComponent()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "parent", dict.get("parent", 0))
        setattr(x, "class", dict.get("class", 0))
        return x

    def AvailableHardwareComponentsRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AvailableHardwareComponentsRsp()
        if not dict: return x
        for v in dict.get("components", []):
            getattr(x, "components").append(v)
        return x

    def GeneralHWComponentData_fromDict(self, dict):
        x = hardwarectrl_service_pb2.GeneralHWComponentData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "description", dict.get("description", ""))
        setattr(x, "hardwareRevision", dict.get("hardwareRevision", ""))
        setattr(x, "firmwareRevision", dict.get("firmwareRevision", ""))
        setattr(x, "softwareRevision", dict.get("softwareRevision", ""))
        setattr(x, "serialNumber", dict.get("serialNumber", ""))
        setattr(x, "mfgName", dict.get("mfgName", ""))
        setattr(x, "modelName", dict.get("modelName", ""))
        setattr(x, "isFru", dict.get("isFru", ""))
        setattr(x, "mfgDate", dict.get("mfgDate", ""))
        setattr(x, "uuid", dict.get("uuid", ""))
        setattr(x, "productCode", dict.get("productCode", ""))
        return x

    def SensorData_fromDict(self, dict):
        x = hardwarectrl_service_pb2.SensorData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "value", dict.get("value", ""))
        setattr(x, "valueType", dict.get("valueType", 0))
        setattr(x, "valueScale", dict.get("valueScale", 0))
        setattr(x, "valuePrecision", dict.get("valuePrecision", ""))
        setattr(x, "operStatus", dict.get("operStatus", 0))
        setattr(x, "unitsDisplay", dict.get("unitsDisplay", ""))
        return x

    def HardwareComponentDataReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.HardwareComponentDataReq()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        return x

    def HardwareComponentDataRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.HardwareComponentDataRsp()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        getattr(x, "generalData").CopyFrom(self.GeneralHWComponentData_fromDict(dict.get("generalData")))
        getattr(x, "sensorData").CopyFrom(self.SensorData_fromDict(dict.get("sensorData")))
        return x

    def GetSlotStatusReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.GetSlotStatusReq()
        if not dict: return x
        setattr(x, "slotNumber", dict.get("slotNumber", 0))
        return x

    def GetSlotStatusRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.GetSlotStatusRsp()
        if not dict: return x
        setattr(x, "running", dict.get("running", 0))
        setattr(x, "active", dict.get("active", 0))
        setattr(x, "imageStatus", dict.get("imageStatus", 0))
        setattr(x, "version", dict.get("version", ""))
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def WriteImageToBoardReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.WriteImageToBoardReq()
        if not dict: return x
        setattr(x, "slotNumber", dict.get("slotNumber", 0))
        setattr(x, "path", dict.get("path", ""))
        return x

    def WriteImageToBoardRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.WriteImageToBoardRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def SetImageStatusReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.SetImageStatusReq()
        if not dict: return x
        return x

    def SetImageStatusRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.SetImageStatusRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def SetActiveSlotReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.SetActiveSlotReq()
        if not dict: return x
        setattr(x, "slotNumber", dict.get("slotNumber", 0))
        return x

    def SetActiveSlotRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.SetActiveSlotRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def LedModeInd_fromDict(self, dict):
        x = hardwarectrl_service_pb2.LedModeInd()
        if not dict: return x
        setattr(x, "ledMode", dict.get("ledMode", 0))
        return x

    def RegisterEventListenerInd_fromDict(self, dict):
        x = hardwarectrl_service_pb2.RegisterEventListenerInd()
        if not dict: return x
        setattr(x, "clientName", dict.get("clientName", ""))
        setattr(x, "event", dict.get("event", 0))
        return x

    def ExternalIoReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ExternalIoReq()
        if not dict: return x
        return x

    def ExternalIoInput_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ExternalIoInput()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "portIn", dict.get("portIn", 0))
        setattr(x, "lineIn", dict.get("lineIn", 0))
        return x

    def ExternalIoRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ExternalIoRsp()
        if not dict: return x
        for v in dict.get("externalIoInputRsp", []):
            getattr(x, "externalIoInputRsp").append(self.ExternalIoInput_fromDict(v))
        return x

    def ResetWDReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ResetWDReq()
        if not dict: return x
        return x

    def ResetReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ResetReq()
        if not dict: return x
        return x

    def ResetRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.ResetRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def AldPortsCapabilitiesReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortsCapabilitiesReq()
        if not dict: return x
        return x

    def AldPortsCapabilitiesRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortsCapabilitiesRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "overCurrentSupported", dict.get("overCurrentSupported", 0))
        setattr(x, "aldPortNames", dict.get("aldPortNames", ""))
        return x

    def AldPortInfoReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortInfoReq()
        if not dict: return x
        setattr(x, "portName", dict.get("portName", ""))
        return x

    def AldPortInfoRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortInfoRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "portId", dict.get("portId", 0))
        setattr(x, "dcControlSupport", dict.get("dcControlSupport", 0))
        setattr(x, "dcEnabledStatus", dict.get("dcEnabledStatus", 0))
        setattr(x, "supportedConnector", dict.get("supportedConnector", 0))
        return x

    def AldPortCommunicationReq_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortCommunicationReq()
        if not dict: return x
        setattr(x, "portId", dict.get("portId", 0))
        setattr(x, "aldReqMsg", dict.get("aldReqMsg", ""))
        return x

    def AldPortCommunicationRsp_AldPortCommunicationData_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortCommunicationRsp_AldPortCommunicationData()
        if not dict: return x
        setattr(x, "portId", dict.get("portId", 0))
        setattr(x, "status", dict.get("status", 0))
        setattr(x, "errorMessage", dict.get("errorMessage", ""))
        setattr(x, "aldRsp", dict.get("aldRsp", ""))
        setattr(x, "framesWithWrongCrc", dict.get("framesWithWrongCrc", 0))
        setattr(x, "framesWithoutStopFlag", dict.get("framesWithoutStopFlag", 0))
        setattr(x, "numberOfReceivedOctets", dict.get("numberOfReceivedOctets", 0))
        return x

    def AldPortCommunicationRsp_fromDict(self, dict):
        x = hardwarectrl_service_pb2.AldPortCommunicationRsp()
        if not dict: return x
        setattr(x, "aldPortData", dict.get("aldPortData", 0))
        return x

    def HardwareCtrlIn_fromDict(self, dict):
        x = hardwarectrl_service_pb2.HardwareCtrlIn()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "availHwComponentsReq").CopyFrom(self.AvailableHardwareComponentsReq_fromDict(dict.get("availHwComponentsReq")))
        getattr(x, "hwComponentDataReq").CopyFrom(self.HardwareComponentDataReq_fromDict(dict.get("hwComponentDataReq")))
        getattr(x, "getSlotStatusReq").CopyFrom(self.GetSlotStatusReq_fromDict(dict.get("getSlotStatusReq")))
        getattr(x, "writeImageToBoardReq").CopyFrom(self.WriteImageToBoardReq_fromDict(dict.get("writeImageToBoardReq")))
        getattr(x, "setActiveSlotReq").CopyFrom(self.SetActiveSlotReq_fromDict(dict.get("setActiveSlotReq")))
        getattr(x, "resetReq").CopyFrom(self.ResetReq_fromDict(dict.get("resetReq")))
        getattr(x, "resetWDReq").CopyFrom(self.ResetWDReq_fromDict(dict.get("resetWDReq")))
        getattr(x, "ledModeInd").CopyFrom(self.LedModeInd_fromDict(dict.get("ledModeInd")))
        getattr(x, "setImageStatusReq").CopyFrom(self.SetImageStatusReq_fromDict(dict.get("setImageStatusReq")))
        getattr(x, "externalIoReq").CopyFrom(self.ExternalIoReq_fromDict(dict.get("externalIoReq")))
        getattr(x, "aldPortCapabilitiesReq").CopyFrom(self.AldPortsCapabilitiesReq_fromDict(dict.get("aldPortCapabilitiesReq")))
        getattr(x, "aldPortInfoReq").CopyFrom(self.AldPortInfoReq_fromDict(dict.get("aldPortInfoReq")))
        getattr(x, "aldPortCommunicationReq").CopyFrom(self.AldPortCommunicationReq_fromDict(dict.get("aldPortCommunicationReq")))
        return x

    def HardwareCtrlOut_fromDict(self, dict):
        x = hardwarectrl_service_pb2.HardwareCtrlOut()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "availHwComponentsRsp").CopyFrom(self.AvailableHardwareComponentsRsp_fromDict(dict.get("availHwComponentsRsp")))
        getattr(x, "hwComponentDataRsp").CopyFrom(self.HardwareComponentDataRsp_fromDict(dict.get("hwComponentDataRsp")))
        getattr(x, "getSlotStatusRsp").CopyFrom(self.GetSlotStatusRsp_fromDict(dict.get("getSlotStatusRsp")))
        getattr(x, "writeImageToBoardRsp").CopyFrom(self.WriteImageToBoardRsp_fromDict(dict.get("writeImageToBoardRsp")))
        getattr(x, "setActiveSlotRsp").CopyFrom(self.SetActiveSlotRsp_fromDict(dict.get("setActiveSlotRsp")))
        getattr(x, "resetRsp").CopyFrom(self.ResetRsp_fromDict(dict.get("resetRsp")))
        getattr(x, "setImageStatusRsp").CopyFrom(self.SetImageStatusRsp_fromDict(dict.get("setImageStatusRsp")))
        getattr(x, "externalIoRsp").CopyFrom(self.ExternalIoRsp_fromDict(dict.get("externalIoRsp")))
        getattr(x, "aldPortCapabilitiesRsp").CopyFrom(self.AldPortsCapabilitiesRsp_fromDict(dict.get("aldPortCapabilitiesRsp")))
        getattr(x, "aldPortInfoRsp").CopyFrom(self.AldPortInfoRsp_fromDict(dict.get("aldPortInfoRsp")))
        getattr(x, "aldPortCommunicationRsp").CopyFrom(self.AldPortCommunicationRsp_fromDict(dict.get("aldPortCommunicationRsp")))
        return x

    def AvailableHardwareComponentsReq_toDict(self, v):
        dict = {}
        return dict

    def AvailableHardwareComponentsRsp_HardwareComponent_Parent_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        dict["class"] = getattr(v, "class")
        return dict

    def AvailableHardwareComponentsRsp_HardwareComponent_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        dict["parent"] = getattr(v, "parent")
        dict["class"] = getattr(v, "class")
        return dict

    def AvailableHardwareComponentsRsp_toDict(self, v):
        dict = {}
        dict["components"] = getattr(v, "components")[:]
        return dict

    def GeneralHWComponentData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["description"] = getattr(v, "description")
        dict["hardwareRevision"] = getattr(v, "hardwareRevision")
        dict["firmwareRevision"] = getattr(v, "firmwareRevision")
        dict["softwareRevision"] = getattr(v, "softwareRevision")
        dict["serialNumber"] = getattr(v, "serialNumber")
        dict["mfgName"] = getattr(v, "mfgName")
        dict["modelName"] = getattr(v, "modelName")
        dict["isFru"] = getattr(v, "isFru")
        dict["mfgDate"] = getattr(v, "mfgDate")
        dict["uuid"] = getattr(v, "uuid")
        dict["productCode"] = getattr(v, "productCode")
        return dict

    def SensorData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["value"] = getattr(v, "value")
        dict["valueType"] = getattr(v, "valueType")
        dict["valueScale"] = getattr(v, "valueScale")
        dict["valuePrecision"] = getattr(v, "valuePrecision")
        dict["operStatus"] = getattr(v, "operStatus")
        dict["unitsDisplay"] = getattr(v, "unitsDisplay")
        return dict

    def HardwareComponentDataReq_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        return dict

    def HardwareComponentDataRsp_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["generalData"] = self.GeneralHWComponentData_toDict(getattr(v, "generalData"))
        dict["sensorData"] = self.SensorData_toDict(getattr(v, "sensorData"))
        return dict

    def GetSlotStatusReq_toDict(self, v):
        dict = {}
        dict["slotNumber"] = getattr(v, "slotNumber")
        return dict

    def GetSlotStatusRsp_toDict(self, v):
        dict = {}
        dict["running"] = getattr(v, "running")
        dict["active"] = getattr(v, "active")
        dict["imageStatus"] = getattr(v, "imageStatus")
        dict["version"] = getattr(v, "version")
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def WriteImageToBoardReq_toDict(self, v):
        dict = {}
        dict["slotNumber"] = getattr(v, "slotNumber")
        dict["path"] = getattr(v, "path")
        return dict

    def WriteImageToBoardRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def SetImageStatusReq_toDict(self, v):
        dict = {}
        return dict

    def SetImageStatusRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def SetActiveSlotReq_toDict(self, v):
        dict = {}
        dict["slotNumber"] = getattr(v, "slotNumber")
        return dict

    def SetActiveSlotRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def LedModeInd_toDict(self, v):
        dict = {}
        dict["ledMode"] = getattr(v, "ledMode")
        return dict

    def RegisterEventListenerInd_toDict(self, v):
        dict = {}
        dict["clientName"] = getattr(v, "clientName")
        dict["event"] = getattr(v, "event")
        return dict

    def ExternalIoReq_toDict(self, v):
        dict = {}
        return dict

    def ExternalIoInput_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        dict["portIn"] = getattr(v, "portIn")
        dict["lineIn"] = getattr(v, "lineIn")
        return dict

    def ExternalIoRsp_toDict(self, v):
        dict = {}
        dict["externalIoInputRsp"] = []
        for x in getattr(v, "externalIoInputRsp"):
            dict["externalIoInputRsp"].append(self.ExternalIoInput_toDict(x))
        return dict

    def ResetWDReq_toDict(self, v):
        dict = {}
        return dict

    def ResetReq_toDict(self, v):
        dict = {}
        return dict

    def ResetRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def AldPortsCapabilitiesReq_toDict(self, v):
        dict = {}
        return dict

    def AldPortsCapabilitiesRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["overCurrentSupported"] = getattr(v, "overCurrentSupported")
        dict["aldPortNames"] = getattr(v, "aldPortNames")
        return dict

    def AldPortInfoReq_toDict(self, v):
        dict = {}
        dict["portName"] = getattr(v, "portName")
        return dict

    def AldPortInfoRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["portId"] = getattr(v, "portId")
        dict["dcControlSupport"] = getattr(v, "dcControlSupport")
        dict["dcEnabledStatus"] = getattr(v, "dcEnabledStatus")
        dict["supportedConnector"] = getattr(v, "supportedConnector")
        return dict

    def AldPortCommunicationReq_toDict(self, v):
        dict = {}
        dict["portId"] = getattr(v, "portId")
        dict["aldReqMsg"] = getattr(v, "aldReqMsg")
        return dict

    def AldPortCommunicationRsp_AldPortCommunicationData_toDict(self, v):
        dict = {}
        dict["portId"] = getattr(v, "portId")
        dict["status"] = getattr(v, "status")
        dict["errorMessage"] = getattr(v, "errorMessage")
        dict["aldRsp"] = getattr(v, "aldRsp")
        dict["framesWithWrongCrc"] = getattr(v, "framesWithWrongCrc")
        dict["framesWithoutStopFlag"] = getattr(v, "framesWithoutStopFlag")
        dict["numberOfReceivedOctets"] = getattr(v, "numberOfReceivedOctets")
        return dict

    def AldPortCommunicationRsp_toDict(self, v):
        dict = {}
        dict["aldPortData"] = getattr(v, "aldPortData")
        return dict

    def HardwareCtrlIn_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["availHwComponentsReq"] = self.AvailableHardwareComponentsReq_toDict(getattr(v, "availHwComponentsReq"))
        dict["hwComponentDataReq"] = self.HardwareComponentDataReq_toDict(getattr(v, "hwComponentDataReq"))
        dict["getSlotStatusReq"] = self.GetSlotStatusReq_toDict(getattr(v, "getSlotStatusReq"))
        dict["writeImageToBoardReq"] = self.WriteImageToBoardReq_toDict(getattr(v, "writeImageToBoardReq"))
        dict["setActiveSlotReq"] = self.SetActiveSlotReq_toDict(getattr(v, "setActiveSlotReq"))
        dict["resetReq"] = self.ResetReq_toDict(getattr(v, "resetReq"))
        dict["resetWDReq"] = self.ResetWDReq_toDict(getattr(v, "resetWDReq"))
        dict["ledModeInd"] = self.LedModeInd_toDict(getattr(v, "ledModeInd"))
        dict["setImageStatusReq"] = self.SetImageStatusReq_toDict(getattr(v, "setImageStatusReq"))
        dict["externalIoReq"] = self.ExternalIoReq_toDict(getattr(v, "externalIoReq"))
        dict["aldPortCapabilitiesReq"] = self.AldPortsCapabilitiesReq_toDict(getattr(v, "aldPortCapabilitiesReq"))
        dict["aldPortInfoReq"] = self.AldPortInfoReq_toDict(getattr(v, "aldPortInfoReq"))
        dict["aldPortCommunicationReq"] = self.AldPortCommunicationReq_toDict(getattr(v, "aldPortCommunicationReq"))
        return dict

    def HardwareCtrlOut_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["availHwComponentsRsp"] = self.AvailableHardwareComponentsRsp_toDict(getattr(v, "availHwComponentsRsp"))
        dict["hwComponentDataRsp"] = self.HardwareComponentDataRsp_toDict(getattr(v, "hwComponentDataRsp"))
        dict["getSlotStatusRsp"] = self.GetSlotStatusRsp_toDict(getattr(v, "getSlotStatusRsp"))
        dict["writeImageToBoardRsp"] = self.WriteImageToBoardRsp_toDict(getattr(v, "writeImageToBoardRsp"))
        dict["setActiveSlotRsp"] = self.SetActiveSlotRsp_toDict(getattr(v, "setActiveSlotRsp"))
        dict["resetRsp"] = self.ResetRsp_toDict(getattr(v, "resetRsp"))
        dict["setImageStatusRsp"] = self.SetImageStatusRsp_toDict(getattr(v, "setImageStatusRsp"))
        dict["externalIoRsp"] = self.ExternalIoRsp_toDict(getattr(v, "externalIoRsp"))
        dict["aldPortCapabilitiesRsp"] = self.AldPortsCapabilitiesRsp_toDict(getattr(v, "aldPortCapabilitiesRsp"))
        dict["aldPortInfoRsp"] = self.AldPortInfoRsp_toDict(getattr(v, "aldPortInfoRsp"))
        dict["aldPortCommunicationRsp"] = self.AldPortCommunicationRsp_toDict(getattr(v, "aldPortCommunicationRsp"))
        return dict

    def AvailableHardwareComponents(self):
        _req = hardwarectrl_service_pb2.AvailableHardwareComponentsReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.availHwComponentsReq.CopyFrom(_req)
        debug(_inMsg)

    def HardwareComponentData(self, name):
        _req = hardwarectrl_service_pb2.HardwareComponentDataReq()
        _req.name = name
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.hwComponentDataReq.CopyFrom(_req)
        debug(_inMsg)

    def GetSlotStatus(self, slotNumber):
        _req = hardwarectrl_service_pb2.GetSlotStatusReq()
        _req.slotNumber = slotNumber
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.getSlotStatusReq.CopyFrom(_req)
        debug(_inMsg)

    def WriteImageToBoard(self, slotNumber, path):
        _req = hardwarectrl_service_pb2.WriteImageToBoardReq()
        _req.slotNumber = slotNumber
        _req.path = path
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.writeImageToBoardReq.CopyFrom(_req)
        debug(_inMsg)

    def SetImageStatus(self):
        _req = hardwarectrl_service_pb2.SetImageStatusReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.setImageStatusReq.CopyFrom(_req)
        debug(_inMsg)

    def SetActiveSlot(self, slotNumber):
        _req = hardwarectrl_service_pb2.SetActiveSlotReq()
        _req.slotNumber = slotNumber
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.setActiveSlotReq.CopyFrom(_req)
        debug(_inMsg)

    def LedMode(self, ledMode):
        _req = hardwarectrl_service_pb2.LedModeInd()
        _req.ledMode = ledMode
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.ledModeInd.CopyFrom(_req)
        debug(_inMsg)

    def ExternalIo(self):
        _req = hardwarectrl_service_pb2.ExternalIoReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.externalIoReq.CopyFrom(_req)
        debug(_inMsg)

    def ResetWD(self):
        _req = hardwarectrl_service_pb2.ResetWDReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.resetWDReq.CopyFrom(_req)
        debug(_inMsg)

    def Reset(self):
        _req = hardwarectrl_service_pb2.ResetReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.resetReq.CopyFrom(_req)
        debug(_inMsg)

    def AldPortsCapabilities(self):
        _req = hardwarectrl_service_pb2.AldPortsCapabilitiesReq()
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.aldPortCapabilitiesReq.CopyFrom(_req)
        debug(_inMsg)

    def AldPortInfo(self, portName):
        _req = hardwarectrl_service_pb2.AldPortInfoReq()
        _req.portName = portName
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.aldPortInfoReq.CopyFrom(_req)
        debug(_inMsg)

    def AldPortCommunication(self, portId, aldReqMsg):
        _req = hardwarectrl_service_pb2.AldPortCommunicationReq()
        _req.portId = portId
        _req.aldReqMsg = aldReqMsg
        _inMsg = hardwarectrl_service_pb2.HardwareCtrlIn()
        _inMsg.aldPortCommunicationReq.CopyFrom(_req)
        debug(_inMsg)

