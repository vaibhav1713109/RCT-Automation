from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libducddcchain_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libducddcchainProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibducddcchain", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = libducddcchain_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", 0))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def Dfe_Init(self):
        _req = libducddcchain_pb2.Dfe_InitReq()
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfe_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfe_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Dfe_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("Dfe_Init failed: no valid response found (dfe_Init)")
        return self.returnStatusType_toDict(_rsp.dfe_InitRsp._ret)

    def DfeMixerSetCcAlignmentDelay(self, MixerIndexInChain, DdcDucSelect, subsystem, MixerBitSequence, MaxUseableCcids, AlignmentDlyClks):
        _req = libducddcchain_pb2.DfeMixerSetCcAlignmentDelayReq()
        _req.MixerIndexInChain = MixerIndexInChain
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _req.MixerBitSequence = MixerBitSequence
        _req.MaxUseableCcids = MaxUseableCcids
        _req.AlignmentDlyClks = AlignmentDlyClks
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeMixerSetCcAlignmentDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeMixerSetCcAlignmentDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeMixerSetCcAlignmentDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeMixerSetCcAlignmentDelay failed: no valid response found (dfeMixerSetCcAlignmentDelay)")
        return _rsp.dfeMixerSetCcAlignmentDelayRsp._ret

    def DfeMixerCalcCcAlignmentDelay(self, DdcDucSelect, subsystem, ClksPerSample):
        _req = libducddcchain_pb2.DfeMixerCalcCcAlignmentDelayReq()
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _req.ClksPerSample = ClksPerSample
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeMixerCalcCcAlignmentDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeMixerCalcCcAlignmentDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeMixerCalcCcAlignmentDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeMixerCalcCcAlignmentDelay failed: no valid response found (dfeMixerCalcCcAlignmentDelay)")
        return _rsp.dfeMixerCalcCcAlignmentDelayRsp._ret

    def DfeMixerGetMaxRateDelay(self, DdcDucSelect, subsystem):
        _req = libducddcchain_pb2.DfeMixerGetMaxRateDelayReq()
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeMixerGetMaxRateDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeMixerGetMaxRateDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeMixerGetMaxRateDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeMixerGetMaxRateDelay failed: no valid response found (dfeMixerGetMaxRateDelay)")
        return _rsp.dfeMixerGetMaxRateDelayRsp._ret

    def DfeChanFilterSetCcAlignmentDelay(self, ChanFiltIndexInChain, DdcDucSelect, subsystem, ChanFiltBitSequence, MaxUseableCcids, AddedMixerDelayClks, ClksPerSample):
        _req = libducddcchain_pb2.DfeChanFilterSetCcAlignmentDelayReq()
        _req.ChanFiltIndexInChain = ChanFiltIndexInChain
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _req.ChanFiltBitSequence = ChanFiltBitSequence
        _req.MaxUseableCcids = MaxUseableCcids
        _req.AddedMixerDelayClks = AddedMixerDelayClks
        _req.ClksPerSample = ClksPerSample
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeChanFilterSetCcAlignmentDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeChanFilterSetCcAlignmentDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeChanFilterSetCcAlignmentDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeChanFilterSetCcAlignmentDelay failed: no valid response found (dfeChanFilterSetCcAlignmentDelay)")
        return _rsp.dfeChanFilterSetCcAlignmentDelayRsp._ret

    def DfeChanFilterGetMaxRateDelay(self, DdcDucSelect, subsystem):
        _req = libducddcchain_pb2.DfeChanFilterGetMaxRateDelayReq()
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeChanFilterGetMaxRateDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeChanFilterGetMaxRateDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeChanFilterGetMaxRateDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeChanFilterGetMaxRateDelay failed: no valid response found (dfeChanFilterGetMaxRateDelay)")
        return _rsp.dfeChanFilterGetMaxRateDelayRsp._ret

    def DfeRemapCcid(self, subsystem, ccfIndex, ccfCcid, mixerCcid):
        _req = libducddcchain_pb2.DfeRemapCcidReq()
        _req.subsystem = subsystem
        _req.ccfIndex = ccfIndex
        _req.ccfCcid = ccfCcid
        _req.mixerCcid = mixerCcid
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfeRemapCcidReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfeRemapCcidRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DfeRemapCcid failed: " + _rsp.zzerr_msg)
            raise EtwError("DfeRemapCcid failed: no valid response found (dfeRemapCcid)")
        return _rsp.dfeRemapCcidRsp._ret

    def Dfe_Deinit(self):
        _req = libducddcchain_pb2.Dfe_DeinitReq()
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.dfe_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dfe_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Dfe_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("Dfe_Deinit failed: no valid response found (dfe_Deinit)")
        return self.returnStatusType_toDict(_rsp.dfe_DeinitRsp._ret)

    def DucDdcChain_ChanFilter_count(self, DdcDucSelect, subsystem):
        _req = libducddcchain_pb2.DucDdcChain_ChanFilter_countReq()
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.ducDdcChain_ChanFilter_countReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "ducDdcChain_ChanFilter_countRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DucDdcChain_ChanFilter_count failed: " + _rsp.zzerr_msg)
            raise EtwError("DucDdcChain_ChanFilter_count failed: no valid response found (ducDdcChain_ChanFilter_count)")
        return _rsp.ducDdcChain_ChanFilter_countRsp._ret

    def DucDdcChain_Mixer_count(self, DdcDucSelect, subsystem):
        _req = libducddcchain_pb2.DucDdcChain_Mixer_countReq()
        _req.DdcDucSelect = DdcDucSelect
        _req.subsystem = subsystem
        _inMsg = libducddcchain_pb2.libducddcchainIn()
        _inMsg.ducDdcChain_Mixer_countReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libducddcchain_pb2.libducddcchainOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "ducDdcChain_Mixer_countRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DucDdcChain_Mixer_count failed: " + _rsp.zzerr_msg)
            raise EtwError("DucDdcChain_Mixer_count failed: no valid response found (ducDdcChain_Mixer_count)")
        return _rsp.ducDdcChain_Mixer_countRsp._ret

