from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import rrh_dfe_pb2
from etw.lib import dbusgw_pb2

ClockRefType_LMK04828B_156M25_245M76_122M88 = rrh_dfe_pb2.ClockRefType_LMK04828B_156M25_245M76_122M88
ClockRefType_LMK04828B_390M625_245M76_122M88 = rrh_dfe_pb2.ClockRefType_LMK04828B_390M625_245M76_122M88
ClockRefType_LMK04828B_EXT_10M_245M76_122M88 = rrh_dfe_pb2.ClockRefType_LMK04828B_EXT_10M_245M76_122M88
ClockRefType_LMK04828B_TCXO_10M_245M76_122M88 = rrh_dfe_pb2.ClockRefType_LMK04828B_TCXO_10M_245M76_122M88
DacFreqType_DAC_245_76_MHZ = rrh_dfe_pb2.DacFreqType_DAC_245_76_MHZ
Adc0FreqType_ADC_245_76_MHZ = rrh_dfe_pb2.Adc0FreqType_ADC_245_76_MHZ
WaveFormatType_TXT = rrh_dfe_pb2.WaveFormatType_TXT
WaveFormatType_BIN = rrh_dfe_pb2.WaveFormatType_BIN
CaptureModeType_SINGLE = rrh_dfe_pb2.CaptureModeType_SINGLE
CaptureModeType_CONT = rrh_dfe_pb2.CaptureModeType_CONT

NUM_OF_TX_PORTS = 8
NUM_OF_RX_PORTS = 8
NUM_OF_ORX_PORTS = 2
NUM_OF_QPAM = 2

debug_on = 0

def debug(msg):
    if debug_on: print(msg.__str__())

class RrhDfeProxy():

    def __init__(self, ipcLink):
        self.etwProxy = EtwProxy(ipcLink = ipcLink)
        self.gw = DBusGwProxy(ipcLink, proto_name = 'etwrrhdfe')

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def initRfClock(self, lmk_freq, lmx0_freq, lmx1_freq):
        req = rrh_dfe_pb2.InitRfClockReq()
        req.lmkFreq = lmk_freq
        req.lmx0Freq = lmx0_freq
        req.lmx1Freq = lmx1_freq
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.initRfClockReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.initRfClockRsp:
            raise EtwError("InitRfClock failed: " + rsp.err_msg)
        if not rsp.initRfClockRsp.ok:
            raise EtwError("InitRfClock failed: " + rsp.initRfClockRsp.err_msg)

    def si5381ClockConfig(self):
        req = rrh_dfe_pb2.Si5381ClockConfigReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.si5381ClockConfigReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.si5381ClockConfigRsp:
            raise EtwError("Si5381ClockConfig failed: " + rsp.err_msg)
        if not rsp.si5381ClockConfigRsp.ok:
            raise EtwError("Si5381ClockConfig failed: " + rsp.si5381ClockConfigRsp.err_msg)

    def rfControlInit(self):
        req = rrh_dfe_pb2.RfControlInitReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlInitReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlInitRsp:
            raise EtwError("RfControlInit failed: " + rsp.err_msg)
        if not rsp.rfControlInitRsp.ok:
            raise EtwError("RfControlInit failed: " + rsp.rfControlInitRsp.err_msg)

    def rfControlSetRxCenterFreqKhz(self, port, rxCenterFreqKhz, dacAdcRefClk):
        req = rrh_dfe_pb2.RfControlSetRxCenterFreqKhzReq()
        req.port = port
        req.rxCenterFreqKhz = rxCenterFreqKhz
        req.dacAdcRefClk = dacAdcRefClk
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlSetRxCenterFreqKhzReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlSetRxCenterFreqKhzRsp:
            raise EtwError("RfControlSetRxCenterFreqKhz failed: " + rsp.err_msg)
        if not rsp.rfControlSetRxCenterFreqKhzRsp.ok:
            raise EtwError("RfControlSetRxCenterFreqKhz failed: " + rsp.rfControlSetRxCenterFreqKhzRsp.err_msg)

    def rfControlSetTxCenterFreqKhz(self, port, txCenterFreqKhz, dacAdcRefClk):
        req = rrh_dfe_pb2.RfControlSetTxCenterFreqKhzReq()
        req.port = port
        req.txCenterFreqKhz = txCenterFreqKhz
        req.dacAdcRefClk = dacAdcRefClk
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlSetTxCenterFreqKhzReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlSetTxCenterFreqKhzRsp:
            raise EtwError("RfControlSetTxCenterFreqKhz failed: " + rsp.err_msg)
        if not rsp.rfControlSetTxCenterFreqKhzRsp.ok:
            raise EtwError("RfControlSetTxCenterFreqKhz failed: " + rsp.rfControlSetTxCenterFreqKhzRsp.err_msg)

    def rfControlGetRxCenterFreqKhz(self, port):
        req = rrh_dfe_pb2.RfControlGetRxCenterFreqKhzReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlGetRxCenterFreqKhzReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlGetRxCenterFreqKhzRsp:
            raise EtwError("RfControlGetRxCenterFreqKhz failed: " + rsp.err_msg)
        if not rsp.rfControlGetRxCenterFreqKhzRsp.ok:
            raise EtwError("RfControlGetRxCenterFreqKhz failed: " + rsp.rfControlGetRxCenterFreqKhzRsp.err_msg)

    def rfControlGetTxCenterFreqKhz(self, port):
        req = rrh_dfe_pb2.RfControlGetTxCenterFreqKhzReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlGetTxCenterFreqKhzReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlGetTxCenterFreqKhzRsp:
            raise EtwError("RfControlGetTxCenterFreqKhz failed: " + rsp.err_msg)
        if not rsp.rfControlGetTxCenterFreqKhzRsp.ok:
            raise EtwError("RfControlGetTxCenterFreqKhz failed: " + rsp.rfControlGetTxCenterFreqKhzRsp.err_msg)

    def performTxPowerMeasurement(self, port, subFrameMode, subFrameNumber):
        req = rrh_dfe_pb2.PerformTxPowerMeasurementReq()
        req.port = port
        req.subFrameMode = subFrameMode
        req.subFrameNumber = subFrameNumber
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.performTxPowerMeasurementReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.performTxPowerMeasurementRsp:
            raise EtwError("PerformTxPowerMeasurement failed: " + rsp.err_msg)
        if not rsp.performTxPowerMeasurementRsp.ok:
            raise EtwError("PerformTxPowerMeasurement failed: " + rsp.performTxPowerMeasurementRsp.err_msg)

    def getTxAntDigPowerDbfs(self,port):
        req = rrh_dfe_pb2.GetTxAntDigPowerDbfsReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.getTxAntDigPowerDbfsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.getTxAntDigPowerDbfsRsp:
            raise EtwError("GetTxAntDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.getTxAntDigPowerDbfsRsp.ok:
            raise EtwError("GetTxAntDigPowerDbfs failed: " + rsp.getTxAntDigPowerDbfsRsp.err_msg)
        return rsp.getTxAntDigPowerDbfsRsp

    def rfControlSetDacAtten(self, port, atten):
        req = rrh_dfe_pb2.RfControlSetDacAttenReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlSetDacAttenReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlSetDacAttenRsp:
            raise EtwError("RfControlSetDacAtten failed: " + rsp.err_msg)
        if not rsp.rfControlSetDacAttenRsp.ok:
            raise EtwError("RfControlSetDacAtten failed: " + rsp.rfControlSetDacAttenRsp.err_msg)

    def rfControlSetAdcAtten(self, port, atten):
        req = rrh_dfe_pb2.RfControlSetAdcAttenReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlSetAdcAttenReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlSetAdcAttenRsp:
            raise EtwError("RfControlSetAdcAtten failed: " + rsp.err_msg)
        if not rsp.rfControlSetAdcAttenRsp.ok:
            raise EtwError("RfControlSetAdcAtten failed: " + rsp.rfControlSetAdcAttenRsp.err_msg)

    def performRxPowerMeasurement(self, port, subFrameMode, subFrameNumber):
        req = rrh_dfe_pb2.PerformRxPowerMeasurementReq()
        req.port = port
        req.subFrameMode = subFrameMode
        req.subFrameNumber = subFrameNumber
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.performRxPowerMeasurementReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.performRxPowerMeasurementRsp:
            raise EtwError("PerformRxPowerMeasurement failed: " + rsp.err_msg)
        if not rsp.performRxPowerMeasurementRsp.ok:
            raise EtwError("PerformRxPowerMeasurement failed: " + rsp.performRxPowerMeasurementRsp.err_msg)

    def getRxAntDigPowerDbfs(self,port):
        req = rrh_dfe_pb2.GetRxAntDigPowerDbfsReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.getRxAntDigPowerDbfsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.getRxAntDigPowerDbfsRsp:
            raise EtwError("GetRxAntDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.getRxAntDigPowerDbfsRsp.ok:
            raise EtwError("GetRxAntDigPowerDbfs failed: " + rsp.getRxAntDigPowerDbfsRsp.err_msg)
        return rsp.getRxAntDigPowerDbfsRsp

    def rxAgcSetConfig(self, peakDbfs, attenStepDb, hysteresisDb,rxCg0AttenDb,cgStepUpCount,cgStepDownCount,port):
        req = rrh_dfe_pb2.RxAgcSetConfigReq()
        req.peakDbfs = peakDbfs
        req.attenStepDb = attenStepDb
        req.hysteresisDb = hysteresisDb
        req.rxCg0AttenDb = rxCg0AttenDb
        req.cgStepUpCount = cgStepUpCount
        req.cgStepDownCount = cgStepDownCount
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rxAgcSetConfigReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rxAgcSetConfigRsp:
            raise EtwError("RxAgcSetConfig failed: " + rsp.err_msg)
        if not rsp.rxAgcSetConfigRsp.ok:
            raise EtwError("RxAgcSetConfig failed: " + rsp.rxAgcSetConfigRsp.err_msg)

    def rxAgcSetMode(self,enableDisable):
        req = rrh_dfe_pb2.RxAgcSetModeReq()
        req.enableDisable = enableDisable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn()
        rrhDfeIn.rxAgcSetModeReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn,rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rxAgcSetModeRsp:
            raise EtwError("RxAgcSetMode failed:" + rsp.err_msg)
        if not rsp.rxAgcSetModeRsp.ok:
            raise EtwError("RxAgcSetMode failed:" + rsp.rxAgcSetModeRsp.err_msg)
            
    def rxAgcClrThresholdEvent(self, tileId, blockId, thresholdSelect):
        req = rrh_dfe_pb2.RxAgcClrThresholdEventReq()
        req.tileId = tileId
        req.blockId = blockId
        req.thresholdSelect = thresholdSelect
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rxAgcClrThresholdEventReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rxAgcClrThresholdEventRsp:
            raise EtwError("RxAgcClrThresholdEvent failed: " + rsp.err_msg)
        if not rsp.rxAgcClrThresholdEventRsp.ok:
            raise EtwError("RxAgcClrThresholdEvent failed: " + rsp.rxAgcClrThresholdEventRsp.err_msg)

    def mavu8t8rTrxControlSetTxLnaEnable(self, portPair, enable):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetTxLnaEnableReq()
        req.portPair = portPair
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetTxLnaEnableReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetTxLnaEnableRsp:
            raise EtwError("Mavu8t8rTrxControlSetTxLnaEnable failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetTxLnaEnableRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetTxLnaEnable failed: " + rsp.mavu8t8rTrxControlSetTxLnaEnableRsp.err_msg)

    def mavu8t8rTrxControlSetRxLnaEnable(self, portPair, enable):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetRxLnaEnableReq()
        req.portPair = portPair
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetRxLnaEnableReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetRxLnaEnableRsp:
            raise EtwError("Mavu8t8rTrxControlSetRxLnaEnable failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetRxLnaEnableRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetRxLnaEnable failed: " + rsp.mavu8t8rTrxControlSetRxLnaEnableRsp.err_msg)

    def mavu8t8rTrxControlSetORxLnaEnable(self, port, enable):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetORxLnaEnableReq()
        req.port = port
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetORxLnaEnableReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetORxLnaEnableRsp:
            raise EtwError("Mavu8t8rTrxControlSetORxLnaEnable failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetORxLnaEnableRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetORxLnaEnable failed: " + rsp.mavu8t8rTrxControlSetORxLnaEnableRsp.err_msg)

    def mavu8t8rTrxControlSetTxDsaAtten(self, port, atten):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetTxDsaAttenReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetTxDsaAttenReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetTxDsaAttenRsp:
            raise EtwError("Mavu8t8rTrxControlSetTxDsaAtten failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetTxDsaAttenRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetTxDsaAtten failed: " + rsp.mavu8t8rTrxControlSetTxDsaAttenRsp.err_msg)

    def mavu8t8rTrxControlSetRxDsaAtten(self, port, atten):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetRxDsaAttenReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetRxDsaAttenReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetRxDsaAttenRsp:
            raise EtwError("Mavu8t8rTrxControlSetRxDsaAtten failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetRxDsaAttenRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetRxDsaAtten failed: " + rsp.mavu8t8rTrxControlSetRxDsaAttenRsp.err_msg)

    def mavu8t8rTrxControlSetORxDsaAtten(self, port, atten):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetORxDsaAttenReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetORxDsaAttenReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetORxDsaAttenRsp:
            raise EtwError("Mavu8t8rTrxControlSetORxDsaAtten failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetORxDsaAttenRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetORxDsaAtten failed: " + rsp.mavu8t8rTrxControlSetORxDsaAttenRsp.err_msg)

    def mavu8t8rTrxControlSetBfCalSpdtSwitch(self, opMode):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetBfCalSpdtSwitchReq()
        req.opMode = opMode
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetBfCalSpdtSwitchReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetBfCalSpdtSwitchRsp:
            raise EtwError("Mavu8t8rTrxControlSetBfCalSpdtSwitch failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetBfCalSpdtSwitchRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetBfCalSpdtSwitch failed: " + rsp.mavu8t8rTrxControlSetBfCalSpdtSwitchRsp.err_msg)

    def mavu8t8rTrxControlSetBfCalSp3tSwitch(self, opMode):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetBfCalSp3tSwitchReq()
        req.opMode = opMode
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetBfCalSp3tSwitchReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetBfCalSp3tSwitchRsp:
            raise EtwError("Mavu8t8rTrxControlSetBfCalSp3tSwitch failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetBfCalSp3tSwitchRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetBfCalSp3tSwitch failed: " + rsp.mavu8t8rTrxControlSetBfCalSp3tSwitchRsp.err_msg)

    def mavu8t8rTrxControlSetORxBfCalSpdtSwitch(self, opMode):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetORxBfCalSpdtSwitchReq()
        req.opMode = opMode
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetORxBfCalSpdtSwitchReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetORxBfCalSpdtSwitchRsp:
            raise EtwError("Mavu8t8rTrxControlSetORxBfCalSpdtSwitch failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetORxBfCalSpdtSwitchRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetORxBfCalSpdtSwitch failed: " + rsp.mavu8t8rTrxControlSetORxBfCalSpdtSwitchRsp.err_msg)

    def mavu8t8rTrxControlSetSwitchManager(self, managerSelect):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetSwitchManagerReq()
        req.managerSelect = managerSelect
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetSwitchManagerReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetSwitchManagerRsp:
            raise EtwError("Mavu8t8rTrxControlSetSwitchManager failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetSwitchManagerRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetSwitchManager failed: " + rsp.mavu8t8rTrxControlSetSwitchManagerRsp.err_msg)

    def mavu8t8rTrxControlGetSwitchManager(self):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlGetSwitchManagerReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlGetSwitchManagerReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlGetSwitchManagerRsp:
            raise EtwError("Mavu8t8rTrxControlGetSwitchManager failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlGetSwitchManagerRsp.ok:
            raise EtwError("Mavu8t8rTrxControlGetSwitchManager failed: " + rsp.mavu8t8rTrxControlGetSwitchManagerRsp.err_msg)
        return rsp.mavu8t8rTrxControlGetSwitchManagerRsp

    def mavu8t8rQpamControlSetTxKey(self, port, enable):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetTxKeyReq()
        req.port = port
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetTxKeyReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetTxKeyRsp:
            raise EtwError("Mavu8t8rQpamControlSetTxKey failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetTxKeyRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetTxKey failed: " + rsp.mavu8t8rQpamControlSetTxKeyRsp.err_msg)

    def mavu8t8rQpamControlSetRxKey(self, port, enable):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetRxKeyReq()
        req.port = port
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetRxKeyReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetRxKeyRsp:
            raise EtwError("Mavu8t8rQpamControlSetRxKey failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetRxKeyRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetRxKey failed: " + rsp.mavu8t8rQpamControlSetRxKeyRsp.err_msg)

    def mavu8t8rQpamControlSetPaVdd(self, port, enable):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetPaVddReq()
        req.port = port
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetPaVddReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetPaVddRsp:
            raise EtwError("Mavu8t8rQpamControlSetPaVdd failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetPaVddRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetPaVdd failed: " + rsp.mavu8t8rQpamControlSetPaVddRsp.err_msg)

    def mavu8t8rQpamControlSetTddMode(self, port, opMode):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetTddModeReq()
        req.port = port
        req.opMode = opMode
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetTddModeReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetTddModeRsp:
            raise EtwError("Mavu8t8rQpamControlSetTddMode failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetTddModeRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetTddMode failed: " + rsp.mavu8t8rQpamControlSetTddModeRsp.err_msg)

    def mavu8t8rQpamControlSetORxMuxCtrl(self, port, fwdRev):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetORxMuxCtrlReq()
        req.port = port
        req.fwdRev = fwdRev
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetORxMuxCtrlReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetORxMuxCtrlRsp:
            raise EtwError("Mavu8t8rQpamControlSetORxMuxCtrl failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetORxMuxCtrlRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetORxMuxCtrl failed: " + rsp.mavu8t8rQpamControlSetORxMuxCtrlRsp.err_msg)

    def mavu8t8rTrxControlSetRxLNA(self, port, enable):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetRxLNAReq()
        req.port = port
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetRxLNAReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetRxLNARsp:
            raise EtwError("Mavu8t8rTrxControlSetRxLNA failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetRxLNARsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetRxLNA failed: " + rsp.mavu8t8rTrxControlSetRxLNARsp.err_msg)

    def mavu8t8rQpamControlSetPaBias(self, port, preDriver, driverMainAmplifier, driverPeakingAmplifier, finalMainAmplifier1, finalMainAmplifier2, finalPeakingAmplifier1, finalPeakingAmplifier2):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlSetPaBiasReq()
        req.port = port
        req.preDriver = preDriver
        req.driverMainAmplifier = driverMainAmplifier
        req.driverPeakingAmplifier = driverPeakingAmplifier
        req.finalMainAmplifier1 = finalMainAmplifier1
        req.finalMainAmplifier2 = finalMainAmplifier2
        req.finalPeakingAmplifier1 = finalPeakingAmplifier1
        req.finalPeakingAmplifier2 = finalPeakingAmplifier2
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlSetPaBiasReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlSetPaBiasRsp:
            raise EtwError("Mavu8t8rQpamControlSetPaBias failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlSetPaBiasRsp.ok:
            raise EtwError("Mavu8t8rQpamControlSetPaBias failed: " + rsp.mavu8t8rQpamControlSetPaBiasRsp.err_msg)

    def mavu8t8rQpamControlGetPaBias(self, port):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlGetPaBiasReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlGetPaBiasReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlGetPaBiasRsp:
            raise EtwError("Mavu8t8rQpamControlGetPaBias failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlGetPaBiasRsp.ok:
            raise EtwError("Mavu8t8rQpamControlGetPaBias failed: " + rsp.mavu8t8rQpamControlGetPaBiasRsp.err_msg)
        return rsp.mavu8t8rQpamControlGetPaBiasRsp

    def mavu8t8rQpamControlGetPaCurrentMonitorVoltage(self, port):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlGetPaCurrentMonitorVoltageReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlGetPaCurrentMonitorVoltageReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlGetPaCurrentMonitorVoltageRsp:
            raise EtwError("Mavu8t8rQpamControlGetPaCurrentMonitorVoltage failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlGetPaCurrentMonitorVoltageRsp.ok:
            raise EtwError("Mavu8t8rQpamControlGetPaCurrentMonitorVoltage failed: " + rsp.mavu8t8rQpamControlGetPaCurrentMonitorVoltageRsp.err_msg)
        return rsp.mavu8t8rQpamControlGetPaCurrentMonitorVoltageRsp

    def mavu8t8rQpamControlTxPortReadTemp(self, port):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlTxPortReadTempReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlTxPortReadTempReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlTxPortReadTempRsp:
            raise EtwError("Mavu8t8rQpamControlTxPortReadTemp failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlTxPortReadTempRsp.ok:
            raise EtwError("Mavu8t8rQpamControlTxPortReadTemp failed: " + rsp.mavu8t8rQpamControlTxPortReadTempRsp.err_msg)
        return rsp.mavu8t8rQpamControlTxPortReadTempRsp

    def mavu8t8rTrxControlInit(self):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlInitReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlInitReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlInitRsp:
            raise EtwError("Mavu8t8rTrxControlInit failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlInitRsp.ok:
            raise EtwError("Mavu8t8rTrxControlInit failed: " + rsp.mavu8t8rTrxControlInitRsp.err_msg)

    def mavu8t8rQpam1SetDefaultBiasVoltage(self):
        req = rrh_dfe_pb2.Mavu8t8rQpam1SetDefaultBiasVoltageReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpam1SetDefaultBiasVoltageReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpam1SetDefaultBiasVoltageRsp:
            raise EtwError("Mavu8t8rQpam1SetDefaultBiasVoltage failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpam1SetDefaultBiasVoltageRsp.ok:
            raise EtwError("Mavu8t8rQpam1SetDefaultBiasVoltage failed: " + rsp.mavu8t8rQpam1SetDefaultBiasVoltageRsp.err_msg)

    def mavu8t8rQpam2SetDefaultBiasVoltage(self):
        req = rrh_dfe_pb2.Mavu8t8rQpam2SetDefaultBiasVoltageReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpam2SetDefaultBiasVoltageReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpam2SetDefaultBiasVoltageRsp:
            raise EtwError("Mavu8t8rQpam2SetDefaultBiasVoltage failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpam2SetDefaultBiasVoltageRsp.ok:
            raise EtwError("Mavu8t8rQpam2SetDefaultBiasVoltage failed: " + rsp.mavu8t8rQpam2SetDefaultBiasVoltageRsp.err_msg)

    def mavu8t8rTrxControlSetRxAgcDsa(self, port, atten):
        req = rrh_dfe_pb2.Mavu8t8rTrxControlSetRxAgcDsaReq()
        req.port = port
        req.atten = atten
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rTrxControlSetRxAgcDsaReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rTrxControlSetRxAgcDsaRsp:
            raise EtwError("Mavu8t8rTrxControlSetRxAgcDsa failed: " + rsp.err_msg)
        if not rsp.mavu8t8rTrxControlSetRxAgcDsaRsp.ok:
            raise EtwError("Mavu8t8rTrxControlSetRxAgcDsa failed: " + rsp.mavu8t8rTrxControlSetRxAgcDsaRsp.err_msg)

    def mavu8t8rQpamMaxChipControlInit(self, qpamId):
        req = rrh_dfe_pb2.Mavu8t8rQpamMaxChipControlInitReq()
        req.qpamID = qpamId
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamMaxChipControlInitReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamMaxChipControlInitRsp:
            raise EtwError("Mavu8t8rQpamMaxChipControlInit failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamMaxChipControlInitRsp.ok:
            raise EtwError("Mavu8t8rQpamMaxChipControlInit failed: " + rsp.mavu8t8rQpamMaxChipControlInitRsp.err_msg)

    def rfControlSetORxCenterFreqKhz(self, port, centerFreqKhz, dacAdcRefClk):
        req = rrh_dfe_pb2.RfControlSetORxCenterFreqKhzReq()
        req.port = port
        req.centerFreqKhz = centerFreqKhz
        req.dacAdcRefClk = dacAdcRefClk
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfControlSetORxCenterFreqKhzReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfControlSetORxCenterFreqKhzRsp:
            raise EtwError("RfControlSetORxCenterFreqKhz failed: " + rsp.err_msg)
        if not rsp.rfControlSetORxCenterFreqKhzRsp.ok:
            raise EtwError("RfControlSetORxCenterFreqKhz failed: " + rsp.rfControlSetORxCenterFreqKhzRsp.err_msg)

    def mavu8t8rQpamControlGetPaBiasStepSize(self):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlGetPaBiasStepSizeReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlGetPaBiasStepSizeReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlGetPaBiasStepSizeRsp:
            raise EtwError("Mavu8t8rQpamControlGetPaBiasStepSize failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlGetPaBiasStepSizeRsp.ok:
            raise EtwError("Mavu8t8rQpamControlGetPaBiasStepSize failed: " + rsp.mavu8t8rQpamControlGetPaBiasStepSizeRsp.err_msg)
        return rsp.mavu8t8rQpamControlGetPaBiasStepSizeRsp

    def mavu8t8rQpamControlHasPaCurrentMonitor(self):
        req = rrh_dfe_pb2.Mavu8t8rQpamControlHasPaCurrentMonitorReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.mavu8t8rQpamControlHasPaCurrentMonitorReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.mavu8t8rQpamControlHasPaCurrentMonitorRsp:
            raise EtwError("Mavu8t8rQpamControlHasPaCurrentMonitor failed: " + rsp.err_msg)
        if not rsp.mavu8t8rQpamControlHasPaCurrentMonitorRsp.ok:
            raise EtwError("Mavu8t8rQpamControlHasPaCurrentMonitor failed: " + rsp.mavu8t8rQpamControlHasPaCurrentMonitorRsp.err_msg)
        return rsp.mavu8t8rQpamControlHasPaCurrentMonitorRsp

    def rfClockSelect(self, clockSource):
        req = rrh_dfe_pb2.RfClockSelectReq()
        req.clockSource = clockSource
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rfClockSelectReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rfClockSelectRsp:
            raise EtwError("RfClockSelect failed: " + rsp.err_msg)
        if not rsp.rfClockSelectRsp.ok:
            raise EtwError("RfClockSelect failed: " + rsp.rfClockSelectRsp.err_msg)

    def getOrxDigPowerDbfs(self,port):
        req = rrh_dfe_pb2.GetOrxDigPowerDbfsReq()
        req.port = port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.getOrxDigPowerDbfsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.getOrxDigPowerDbfsRsp:
            raise EtwError("GetOrxDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.getOrxDigPowerDbfsRsp.ok:
            raise EtwError("GetOrxDigPowerDbfs failed: " + rsp.getOrxDigPowerDbfsRsp.err_msg)
        return rsp.getOrxDigPowerDbfsRsp

    def qpamControlGetMaxDeviceId(self, qpamId):
        req = rrh_dfe_pb2.QpamControlGetMaxDeviceIdReq()
        req.qpamID = qpamId
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.qpamControlGetMaxDeviceIdReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.qpamControlGetMaxDeviceIdRsp:
            raise EtwError("QpamControlGetMaxDeviceId failed: " + rsp.err_msg)
        if not rsp.qpamControlGetMaxDeviceIdRsp.ok:
            raise EtwError("QpamControlGetMaxDeviceId failed: " + rsp.qpamControlGetMaxDeviceIdRsp.err_msg)
        return rsp.qpamControlGetMaxDeviceIdRsp

    def qpamControlGetVoltagePaVdd(self, qpamId):
        req = rrh_dfe_pb2.QpamControlGetVoltagePaVddReq()
        req.qpamID = qpamId
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.qpamControlGetVoltagePaVddReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.qpamControlGetVoltagePaVddRsp:
            raise EtwError("QpamControlGetVoltagePaVdd failed: " + rsp.err_msg)
        if not rsp.qpamControlGetVoltagePaVddRsp.ok:
            raise EtwError("QpamControlGetVoltagePaVdd failed: " + rsp.qpamControlGetVoltagePaVddRsp.err_msg)
        return rsp.qpamControlGetVoltagePaVddRsp

    def carrierInit(self, enableStaticPrach):
        req = rrh_dfe_pb2.CarrierInitReq()
        req.enableStaticPrach = enableStaticPrach
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierInitReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierInitRsp:
            raise EtwError("CarrierInit failed: " + rsp.err_msg)
        if not rsp.carrierInitRsp.ok:
            raise EtwError("CarrierInit failed: " + rsp.carrierInitRsp.err_msg)

    def carrierClose(self):
        req = rrh_dfe_pb2.CarrierCloseReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierCloseReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierCloseRsp:
            raise EtwError("CarrierClose failed: " + rsp.err_msg)
        if not rsp.carrierCloseRsp.ok:
            raise EtwError("CarrierClose failed: " + rsp.carrierCloseRsp.err_msg)

    def carrierListAll(self):
        req = rrh_dfe_pb2.CarrierListAllReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierListAllReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierListAllRsp:
            raise EtwError("CarrierListAll failed: " + rsp.err_msg)
        if not rsp.carrierListAllRsp.ok:
            raise EtwError("CarrierListAll failed: " + rsp.carrierListAllRsp.err_msg)

    def carrierAdd(self, name, SCS_u, fftSize, chBwMhz, centerFreqKhz):
        req = rrh_dfe_pb2.CarrierAddReq()
        req.name = name
        req.scs_u = SCS_u
        req.fftSize = fftSize
        req.chBwMhz = chBwMhz
        req.centerFreqKhz = centerFreqKhz
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierAddReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierAddRsp:
            raise EtwError("CarrierAdd failed: " + rsp.err_msg)
        if not rsp.carrierAddRsp.ok:
            raise EtwError("CarrierAdd failed: " + rsp.carrierAddRsp.err_msg)

    def carrierDelete(self, name):
        req = rrh_dfe_pb2.CarrierDeleteReq()
        req.name = name
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierDeleteReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierDeleteRsp:
            raise EtwError("CarrierDelete failed: " + rsp.err_msg)
        if not rsp.carrierDeleteRsp.ok:
            raise EtwError("CarrierDelete failed: " + rsp.carrierDeleteRsp.err_msg)

    def carrierModifyTxFreq(self, name, centerFreqKhz):
        req = rrh_dfe_pb2.CarrierModifyTxFreqReq()
        req.name = name
        req.centerFreqKhz = centerFreqKhz
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierModifyTxFreqReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierModifyTxFreqRsp:
            raise EtwError("CarrierModifyTxFreq failed: " + rsp.err_msg)
        if not rsp.carrierModifyTxFreqRsp.ok:
            raise EtwError("CarrierModifyTxFreq failed: " + rsp.carrierModifyTxFreqRsp.err_msg)

    def carrierGetMixerEventStatus(self, name):
        req = rrh_dfe_pb2.CarrierGetMixerEventStatusReq()
        req.name = name
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierGetMixerEventStatusReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierGetMixerEventStatusRsp:
            raise EtwError("CarrierGetMixerEventStatus failed: " + rsp.err_msg)
        if not rsp.carrierGetMixerEventStatusRsp.ok:
            raise EtwError("CarrierGetMixerEventStatus failed: " + rsp.carrierGetMixerEventStatusRsp.err_msg)

    def carrierSetChFiltBypass(self, name, ducDdcSelect, chFilterBypass):
        req = rrh_dfe_pb2.CarrierSetChFiltBypassReq()
        req.name = name
        req.ducDdcSelect = ducDdcSelect
        req.chFilterBypass = chFilterBypass
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierSetChFiltBypassReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierSetChFiltBypassRsp:
            raise EtwError("CarrierSetChFiltBypass failed: " + rsp.err_msg)
        if not rsp.carrierSetChFiltBypassRsp.ok:
            raise EtwError("CarrierSetChFiltBypass failed: " + rsp.carrierSetChFiltBypassRsp.err_msg)

    def carrierAttachPrachByFormat(self, carrierName, prachFormat, prachOffsetFreqHz, prachNumberOfOccasions, prachFrameNumber, prachPatternPeriod, prachSubframeId, prachTimeOffsetTs):
        req = rrh_dfe_pb2.CarrierAttachPrachByFormatReq()
        req.carrierName = carrierName
        req.prachFormat = prachFormat
        req.prachOffsetFreqHz = prachOffsetFreqHz
        req.prachNumberOfOccasions = prachNumberOfOccasions
        req.prachFrameNumber = prachFrameNumber
        req.prachPatternPeriod = prachPatternPeriod
        req.prachSubframeId = prachSubframeId
        req.prachTimeOffsetTs = prachTimeOffsetTs
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierAttachPrachByFormatReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierAttachPrachByFormatRsp:
            raise EtwError("CarrierAttachPrachByFormat failed: " + rsp.err_msg)
        if not rsp.carrierAttachPrachByFormatRsp.ok:
            raise EtwError("CarrierAttachPrachByFormat failed: " + rsp.carrierAttachPrachByFormatRsp.err_msg)

    def carrierEnable(self, name):
        req = rrh_dfe_pb2.CarrierEnableReq()
        req.name = name
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierEnableReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierEnableRsp:
            raise EtwError("CarrierEnable failed: " + rsp.err_msg)
        if not rsp.carrierEnableRsp.ok:
            raise EtwError("CarrierEnable failed: " + rsp.carrierEnableRsp.err_msg)

    def carrierSetDucInput(self, ducInputSelect):
        req = rrh_dfe_pb2.CarrierSetDucInputReq()
        req.ducInputSelect = ducInputSelect
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierSetDucInputReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierSetDucInputRsp:
            raise EtwError("CarrierSetDucInput failed: " + rsp.err_msg)
        if not rsp.carrierSetDucInputRsp.ok:
            raise EtwError("CarrierSetDucInput failed: " + rsp.carrierSetDucInputRsp.err_msg)

    def carrierModifyGain(self, carrierName, ducDdcSelect, gain):
        req = rrh_dfe_pb2.CarrierModifyGainReq()
        req.carrierName = carrierName
        req.ducDdcSelect = ducDdcSelect
        req.gain = gain
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierModifyGainReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierModifyGainRsp:
            raise EtwError("CarrierModifyGain failed: " + rsp.err_msg)
        if not rsp.carrierModifyGainRsp.ok:
            raise EtwError("CarrierModifyGain failed: " + rsp.carrierModifyGainRsp.err_msg)

    def waveformMemoryDownloadAndWrite(self, filename, waveFormat, numOfSamples):
        req = rrh_dfe_pb2.WaveformMemoryDownloadAndWriteReq()
        req.filename = filename
        req.waveFormat = waveFormat
        req.numOfSamples = numOfSamples
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.waveformMemoryDownloadAndWriteReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.waveformMemoryDownloadAndWriteRsp:
            raise EtwError("WaveformMemoryDownloadAndWrite failed: " + rsp.err_msg)
        if not rsp.waveformMemoryDownloadAndWriteRsp.ok:
            raise EtwError("WaveformMemoryDownloadAndWrite failed: " + rsp.waveformMemoryDownloadAndWriteRsp.err_msg)

    def setWaveformPlaybackLength(self, numOfSamples):
        req = rrh_dfe_pb2.SetWaveformPlaybackLengthReq()
        req.numOfSamples = numOfSamples
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.setWaveformPlaybackLengthReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.setWaveformPlaybackLengthRsp:
            raise EtwError("SetWaveformPlaybackLength failed: " + rsp.err_msg)
        if not rsp.setWaveformPlaybackLengthRsp.ok:
            raise EtwError("SetWaveformPlaybackLength failed: " + rsp.setWaveformPlaybackLengthRsp.err_msg)

    def setWaveformPlaybackMasterEnable(self, enable):
        req = rrh_dfe_pb2.SetWaveformPlaybackMasterEnableReq()
        req.enable = enable
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.setWaveformPlaybackMasterEnableReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.setWaveformPlaybackMasterEnableRsp:
            raise EtwError("SetWaveformPlaybackMasterEnable failed: " + rsp.err_msg)
        if not rsp.setWaveformPlaybackMasterEnableRsp.ok:
            raise EtwError("SetWaveformPlaybackMasterEnable failed: " + rsp.setWaveformPlaybackMasterEnableRsp.err_msg)

    def startWaveformCapture(self, filename, waveFormat, waveformChannel, captureMode, captureDelayMsec):
        req = rrh_dfe_pb2.StartWaveformCaptureReq()
        req.filename = filename
        req.waveFormat = waveFormat
        req.waveformChannel = waveformChannel
        req.captureMode = captureMode
        req.captureDelayMsec = captureDelayMsec
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.startWaveformCaptureReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.startWaveformCaptureRsp:
            raise EtwError("StartWaveformCapture failed: " + rsp.err_msg)
        if not rsp.startWaveformCaptureRsp.ok:
            raise EtwError("StartWaveformCapture failed: " + rsp.startWaveformCaptureRsp.err_msg)

    def xDfeMixSelfTestExampleTests(self):
        req = rrh_dfe_pb2.XDfeMixSelfTestExampleTestsReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.xDfeMixSelfTestExampleTestsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.xDfeMixSelfTestExampleTestsRsp:
            raise EtwError("XDfeMixSelfTestExampleTests failed: " + rsp.err_msg)
        if not rsp.xDfeMixSelfTestExampleTestsRsp.ok:
            raise EtwError("XDfeMixSelfTestExampleTests failed: " + rsp.xDfeMixSelfTestExampleTestsRsp.err_msg)

    def xDfeCcfSelfTestExampleTests(self):
        req = rrh_dfe_pb2.XDfeCcfSelfTestExampleTestsReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.xDfeCcfSelfTestExampleTestsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.xDfeCcfSelfTestExampleTestsRsp:
            raise EtwError("XDfeCcfSelfTestExampleTests failed: " + rsp.err_msg)
        if not rsp.xDfeCcfSelfTestExampleTestsRsp.ok:
            raise EtwError("XDfeCcfSelfTestExampleTests failed: " + rsp.xDfeCcfSelfTestExampleTestsRsp.err_msg)

    def oranConfigDl1cc(self):
        req = rrh_dfe_pb2.OranConfigDl1ccReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.oranConfigDl1ccReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.oranConfigDl1ccRsp:
            raise EtwError("OranConfigDl1cc failed: " + rsp.err_msg)
        if not rsp.oranConfigDl1ccRsp.ok:
            raise EtwError("OranConfigDl1cc failed: " + rsp.oranConfigDl1ccRsp.err_msg)

    def oranConfigUl1cc(self):
        req = rrh_dfe_pb2.OranConfigUl1ccReq()
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.oranConfigUl1ccReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.oranConfigUl1ccRsp:
            raise EtwError("OranConfigUl1cc failed: " + rsp.err_msg)
        if not rsp.oranConfigUl1ccRsp.ok:
            raise EtwError("OranConfigUl1cc failed: " + rsp.oranConfigUl1ccRsp.err_msg)

    def carrierSetCfrDpdBypassMode(self,cfrDpdBypassMode):
        req = rrh_dfe_pb2.CarrierSetCfrDpdBypassModeReq()
        req.cfrDpdBypassMode =  cfrDpdBypassMode
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn()
        rrhDfeIn.carrierSetCfrDpdBypassModeReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn,rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierSetCfrDpdBypassModeRsp:
            raise EtwError("CarrierSetCfrDpdBypassMode failed:" + rsp.err_msg)
        if not rsp.carrierSetCfrDpdBypassModeRsp.ok:
            raise EtwError("CarrierSetCfrDpdBypassMode failed:" + rsp.carrierSetCfrDpdBypassModeRsp.err_msg)

    def carrierSetCfrOutputPar(self,cfrOutputPar):
        req = rrh_dfe_pb2.CarrierSetCfrOutputParReq()
        req.cfrOutputPar =  cfrOutputPar
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn()
        rrhDfeIn.carrierSetCfrOutputParReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn,rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierSetCfrOutputParRsp:
            raise EtwError("CarrierSetCfrOutputPar failed:" + rsp.err_msg)
        if not rsp.carrierSetCfrOutputParRsp.ok:
            raise EtwError("CarrierSetCfrOutputPar failed:" + rsp.carrierSetCfrOutputParRsp.err_msg)
    
    def carrierGetCcDigPowerDbfs(self,port):
        req = rrh_dfe_pb2.CarrierGetCcDigPowerDbfsReq()
        req.port =  port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.carrierGetCcDigPowerDbfsReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.carrierGetCcDigPowerDbfsRsp:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.carrierGetCcDigPowerDbfsRsp.ok:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.carrierGetCcDigPowerDbfsRsp.err_msg)
        return rsp.carrierGetCcDigPowerDbfsRsp

    def getRxAntDigPowerCgLevel(self,port):
        req = rrh_dfe_pb2.GetRxAntDigPowerCgLevelReq()
        req.port =  port
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.getRxAntDigPowerCgLevelReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.getRxAntDigPowerCgLevelRsp:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.getRxAntDigPowerCgLevelRsp.ok:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.getRxAntDigPowerCgLevelRsp.err_msg)
        return rsp.getRxAntDigPowerCgLevelRsp

    def rxAgcGetCgLevelAttenuation(self,CgLevel):
        req = rrh_dfe_pb2.RxAgcGetCgLevelAttenuationReq()
        req.CgLevel =  CgLevel
        rrhDfeIn = rrh_dfe_pb2.RrhDfeIn();
        rrhDfeIn.rxAgcGetCgLevelAttenuationReq.CopyFrom(req)
        debug(rrhDfeIn)
        rsp = self.gw.methodCall(rrhDfeIn, rrh_dfe_pb2.RrhDfeOut)
        debug(rsp)
        if not rsp.rxAgcGetCgLevelAttenuationRsp:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.err_msg)
        if not rsp.rxAgcGetCgLevelAttenuationRsp.ok:
            raise EtwError("CarrierGetCcDigPowerDbfs failed: " + rsp.rxAgcGetCgLevelAttenuationRsp.err_msg)
        return rsp.rxAgcGetCgLevelAttenuationRsp
