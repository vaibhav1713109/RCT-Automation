from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libdatabase_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libdatabaseProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibdatabase", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def cmdHandler(self, cmd):
        _req = libdatabase_pb2.cmdHandlerReq()
        _req.cmd = cmd
        _inMsg = libdatabase_pb2.libdatabaseIn()
        _inMsg.cmdHandlerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libdatabase_pb2.libdatabaseOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "cmdHandlerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("cmdHandler failed: " + _rsp.zzerr_msg)
            raise EtwError("cmdHandler failed: no valid response found (cmdHandler)")
        return _rsp.cmdHandlerRsp._ret

    def saveflash(self, filepath):
        _req = libdatabase_pb2.saveflashReq()
        _req.filepath = filepath
        _inMsg = libdatabase_pb2.libdatabaseIn()
        _inMsg.saveflashReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libdatabase_pb2.libdatabaseOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "saveflashRsp":
            if _rsp.zzerr_msg:
                raise EtwError("saveflash failed: " + _rsp.zzerr_msg)
            raise EtwError("saveflash failed: no valid response found (saveflash)")
        return _rsp.saveflashRsp._ret

