from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib.etwmodel import EtwModel
from etw.lib import rfdc_pb2
from etw.lib import dbusgw_pb2
from google.protobuf import text_format

import time

BlockType_ADC = rfdc_pb2.BlockType_ADC
BlockType_DAC = rfdc_pb2.BlockType_DAC

EVNT_SRC_IMMEDIATE = 0x00000000
EVNT_SRC_SLICE     = 0x00000001
EVNT_SRC_TILE      = 0x00000002
EVNT_SRC_SYSREF    = 0x00000003
EVNT_SRC_MARKER    = 0x00000004
EVNT_SRC_PL        = 0x00000005

EVENT_MIXER    = 0x00000001
EVENT_CRSE_DLY = 0x00000002
EVENT_QMC      = 0x00000004

MIXER_TYPE_OFF      = 0x0
MIXER_TYPE_COARSE   = 0x1
MIXER_TYPE_FINE     = 0x2
MIXER_TYPE_DISABLED = 0x3

COARSE_MIX_OFF                     = 0x0
COARSE_MIX_SAMPLE_FREQ_BY_TWO      = 0x2
COARSE_MIX_SAMPLE_FREQ_BY_FOUR     = 0x4
COARSE_MIX_MIN_SAMPLE_FREQ_BY_FOUR = 0x8
COARSE_MIX_BYPASS                  = 0x10

MIXER_MODE_OFF = 0x0
MIXER_MODE_C2C = 0x1
MIXER_MODE_C2R = 0x2
MIXER_MODE_R2C = 0x3
MIXER_MODE_R2R = 0x4

MIXER_SCALE_AUTO = 0x0
MIXER_SCALE_1P0  = 0x1
MIXER_SCALE_0P7  = 0x2

ODD_NYQUIST_ZONE  = 0x1
EVEN_NYQUIST_ZONE = 0x2

debug_on = 0

def debug(msg):
    if debug_on: print(msg.__str__())

class Rfdc:
    model = None
    regs = {}
    
    def __init__(self, model):
        self.model = model
        self.dev = dev;

class RfdcProxy():
    gw = None
    
    def __init__(self, ipcLink):
        self.gw = DBusGwProxy(ipcLink, proto_name = 'etwrfdc')

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def startup(self, block_type, device_id=0, tile_id=-1):
        req = rfdc_pb2.StartupReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.startupReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.startupRsp:
            raise EtwError("startup failed: " + rsp.err_msg)
        if not rsp.startupRsp.ok:
            raise EtwError("startup failed: " + rsp.startupRsp.err_msg)
            
    def shutdown(self, block_type, device_id=0, tile_id=-1):
        req = rfdc_pb2.ShutdownReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.shutdownReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.shutdownRsp:
            raise EtwError("shutdown failed: " + rsp.err_msg)
        if not rsp.shutdownRsp.ok:
            raise EtwError("shutdown failed: " + rsp.shutdownRsp.err_msg)
            
    def reset(self, block_type, device_id=0, tile_id=-1):
        req = rfdc_pb2.ResetReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.resetReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.resetRsp:
            raise EtwError("reset failed: " + rsp.err_msg)
        if not rsp.resetRsp.ok:
            raise EtwError("reset failed: " + rsp.resetRsp.err_msg)
            
    def getIPStatus(self, device_id=0):
        req = rfdc_pb2.GetIPStatusReq();
        req.device_id = device_id
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.getIPStatusReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getIPStatusRsp:
            raise EtwError("getIPStatus failed: " + rsp.err_msg)
        if not rsp.getIPStatusRsp.ok:
            raise EtwError("getIPStatus failed: " + rsp.getIPStatusRsp.err_msg)
        return rsp.getIPStatusRsp.ip_status
            
    def getBlockStatus(self, block_type, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetBlockStatusReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getBlockStatusReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getBlockStatusRsp:
            raise EtwError("getBlockStatus failed: " + rsp.err_msg)
        if not rsp.getBlockStatusRsp.ok:
            raise EtwError("getBlockStatus failed: " + rsp.getBlockStatusRsp.err_msg)
        return rsp.getBlockStatusRsp.block_status
            
    def setMixerSettings(self, block_type, tile_id, block_id, device_id=0,
                         freq=0, phase_offs=0, event_source=0, mixer_type=0, coarse_mix_freq=0,
                         mixer_mode=0, fine_mixer_scale=0):
        req = rfdc_pb2.SetMixerSettingsReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        settings = rfdc_pb2.MixerSettings()
        settings.freq=freq
        settings.phase_offs=phase_offs
        settings.event_source=event_source
        settings.mixer_type=mixer_type
        settings.coarse_mix_freq=coarse_mix_freq
        settings.mixer_mode=mixer_mode
        settings.fine_mixer_scale=fine_mixer_scale
        req.settings.CopyFrom(settings)
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setMixerSettingsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setMixerSettingsRsp:
            raise EtwError("setMixerSettings failed: " + rsp.err_msg)
        if not rsp.setMixerSettingsRsp.ok:
            raise EtwError("setMixerSettings failed: " + rsp.setMixerSettingsRsp.err_msg)
            
    def getMixerSettings(self, block_type, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetMixerSettingsReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getMixerSettingsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getMixerSettingsRsp:
            raise EtwError("getMixerSettings failed: " + rsp.err_msg)
        if not rsp.getMixerSettingsRsp.ok:
            raise EtwError("getMixerSettings failed: " + rsp.getMixerSettingsRsp.err_msg)
        return rsp.getMixerSettingsRsp.settings
            
    def setQMCSettings(self, block_type, tile_id, block_id, device_id=0,
                       enable_phase=False, enable_gain=False,
                       gain_correction_factor=0.0, phase_correction_factor=0.0, offset_correction_factor=0.0,
                       event_source=0):
        req = rfdc_pb2.SetQMCSettingsReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        settings = rfdc_pb2.QMCSettings()
        settings.enable_phase = enable_phase
        settings.enable_gain = enable_gain
        settings.gain_correction_factor = gain_correction_factor
        settings.phase_correction_factor = phase_correction_factor
        settings.offset_correction_factor = offset_correction_factor
        settings.event_source = event_source
        req.settings.CopyFrom(settings)
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setQMCSettingsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setQMCSettingsRsp:
            raise EtwError("setQMCSettings failed: " + rsp.err_msg)
        if not rsp.setQMCSettingsRsp.ok:
            raise EtwError("setQMCSettings failed: " + rsp.setQMCSettingsRsp.err_msg)
            
    def getQMCSettings(self, block_type, device_id=0, tile_id=0, block_id=0):
        req = rfdc_pb2.GetQMCSettingsReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getQMCSettingsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getQMCSettingsRsp:
            raise EtwError("getQMCSettings failed: " + rsp.err_msg)
        if not rsp.getQMCSettingsRsp.ok:
            raise EtwError("getQMCSettings failed: " + rsp.getQMCSettingsRsp.err_msg)
        return rsp.getQMCSettingsRsp.settings
           
    def setCoarseDelaySettings(self, block_type, coarse_delay, event_source, device_id=0, tile_id=0, block_id=0):
        req = rfdc_pb2.SetCoarseDelaySettingsReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        settings = rfdc_pb2.CoarseDelaySettings()
        settings.coarse_delay = coarse_delay
        settings.event_source = event_source
        req.settings.CopyFrom(settings)
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setCoarseDelaySettingsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setCoarseDelaySettingsRsp:
            raise EtwError("setCoarseDelaySettings failed: " + rsp.err_msg)
        if not rsp.setCoarseDelaySettingsRsp.ok:
            raise EtwError("setCoarseDelaySettings failed: " + rsp.setCoarseDelaySettingsRsp.err_msg)
            
    def getCoarseDelaySettings(self, block_type, device_id=0, tile_id=0, block_id=0):
        req = rfdc_pb2.GetCoarseDelaySettingsReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getCoarseDelaySettingsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getCoarseDelaySettingsRsp:
            raise EtwError("getCoarseDelaySettings failed: " + rsp.err_msg)
        if not rsp.getCoarseDelaySettingsRsp.ok:
            raise EtwError("getCoarseDelaySettings failed: " + rsp.getCoarseDelaySettingsRsp.err_msg)
        return rsp.getCoarseDelaySettingsRsp.settings
           
    def setInterpolationFactor(self, tile_id, block_id, interpolation_factor, device_id=0):
        req = rfdc_pb2.SetInterpolationFactorReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.interpolation_factor = interpolation_factor;
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setInterpolationFactorReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setInterpolationFactorRsp:
            raise EtwError("setInterpolationFactor failed: " + rsp.err_msg)
        if not rsp.setInterpolationFactorRsp.ok:
            raise EtwError("setInterpolationFactor failed: " + rsp.setInterpolationFactorRsp.err_msg)
            
    def getInterpolationFactor(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetInterpolationFactorReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getInterpolationFactorReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getInterpolationFactorRsp:
            raise EtwError("getInterpolationFactor failed: " + rsp.err_msg)
        if not rsp.getInterpolationFactorRsp.ok:
            raise EtwError("getInterpolationFactor failed: " + rsp.getInterpolationFactorRsp.err_msg)
        return rsp.getInterpolationFactorRsp.interpolation_factor
           
    def setDecimationFactor(self, tile_id, block_id, decimation_factor, device_id=0):
        req = rfdc_pb2.SetDecimationFactorReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.decimation_factor = decimation_factor;
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDecimationFactorReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDecimationFactorRsp:
            raise EtwError("setDecimationFactor failed: " + rsp.err_msg)
        if not rsp.setDecimationFactorRsp.ok:
            raise EtwError("setDecimationFactor failed: " + rsp.setDecimationFactorRsp.err_msg)
            
    def getDecimationFactor(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDecimationFactorReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDecimationFactorReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDecimationFactorRsp:
            raise EtwError("getDecimationFactor failed: " + rsp.err_msg)
        if not rsp.getDecimationFactorRsp.ok:
            raise EtwError("getDecimationFactor failed: " + rsp.getDecimationFactorRsp.err_msg)
        return rsp.getDecimationFactorRsp.decimation_factor
           
    def setFabWrVldWords(self, tile_id, block_id, data_rate, device_id=0):
        req = rfdc_pb2.SetFabWrVldWordsReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.data_rate = data_rate
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setFabWrVldWordsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setFabWrVldWordsRsp:
            raise EtwError("setFabWrVldWords failed: " + rsp.err_msg)
        if not rsp.setFabWrVldWordsRsp.ok:
            raise EtwError("setFabWrVldWords failed: " + rsp.setFabWrVldWordsRsp.err_msg)
            
    def getFabWrVldWords(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetFabWrVldWordsReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getFabWrVldWordsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getFabWrVldWordsRsp:
            raise EtwError("getFabWrVldWords failed: " + rsp.err_msg)
        if not rsp.getFabWrVldWordsRsp.ok:
            raise EtwError("getFabWrVldWords failed: " + rsp.getFabWrVldWordsRsp.err_msg)
        return rsp.getFabWrVldWordsRsp.data_rate
           
    def setFabRdVldWords(self, tile_id, block_id, data_rate, device_id=0):
        req = rfdc_pb2.SetFabRdVldWordsReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.data_rate = data_rate
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setFabRdVldWordsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setFabRdVldWordsRsp:
            raise EtwError("setFabRdVldWords failed: " + rsp.err_msg)
        if not rsp.setFabRdVldWordsRsp.ok:
            raise EtwError("setFabRdVldWords failed: " + rsp.setFabRdVldWordsRsp.err_msg)
            
    def getFabRdVldWords(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetFabRdVldWordsReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getFabRdVldWordsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getFabRdVldWordsRsp:
            raise EtwError("getFabRdVldWords failed: " + rsp.err_msg)
        if not rsp.getFabRdVldWordsRsp.ok:
            raise EtwError("getFabRdVldWords failed: " + rsp.getFabRdVldWordsRsp.err_msg)
        return rsp.getFabRdVldWordsRsp.data_rate
           
    def setThresholdSettings(self, tile_id, block_id, device_id=0,
                             mode_0=0, mode_1=0,
                             avg_val_0=0, avg_val_1=0,
                             under_val_0=0, under_val_1=0,
                             over_val_0=0, over_val_1=0):
        req = rfdc_pb2.SetThresholdSettingsReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        settings = rfdc_pb2.ThresholdSettings()
        settings.threshold_mode_0 = mode_0
        settings.threshold_mode_1 = mode_1
        settings.threshold_avg_val_0 = avg_val_0
        settings.threshold_avg_val_1 = avg_val_1
        settings.threshold_under_val_0 = under_val_0
        settings.threshold_under_val_1 = under_val_1
        settings.threshold_over_val_0 = over_val_0
        settings.threshold_over_val_1 = over_val_1
        req.settings.CopyFrom(settings)
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setThresholdSettingsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setThresholdSettingsRsp:
            raise EtwError("setThresholdSettings failed: " + rsp.err_msg)
        if not rsp.setThresholdSettingsRsp.ok:
            raise EtwError("setThresholdSettings failed: " + rsp.setThresholdSettingsRsp.err_msg)
            
    def getThresholdSettings(self, device_id=0, tile_id=0, block_id=0):
        req = rfdc_pb2.GetThresholdSettingsReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getThresholdSettingsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getThresholdSettingsRsp:
            raise EtwError("getThresholdSettings failed: " + rsp.err_msg)
        if not rsp.getThresholdSettingsRsp.ok:
            raise EtwError("getThresholdSettings failed: " + rsp.getThresholdSettingsRsp.err_msg)
        return rsp.getThresholdSettingsRsp.settings
           
    def setDecoderMode(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetDecoderModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.decoder_mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDecoderModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDecoderModeRsp:
            raise EtwError("setDecoderMode failed: " + rsp.err_msg)
        if not rsp.setDecoderModeRsp.ok:
            raise EtwError("setDecoderMode failed: " + rsp.setDecoderModeRsp.err_msg)
            
    def getDecoderMode(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDecoderModeReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDecoderModeReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDecoderModeRsp:
            raise EtwError("getDecoderMode failed: " + rsp.err_msg)
        if not rsp.getDecoderModeRsp.ok:
            raise EtwError("getDecoderMode failed: " + rsp.getDecoderModeRsp.err_msg)
        return rsp.getDecoderModeRsp.decoder_mode
           
    def updateEvent(self, block_type, tile_id, block_id, event, device_id=0):
        req = rfdc_pb2.UpdateEventReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.event = event
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.updateEventReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.updateEventRsp:
            raise EtwError("updateEvent failed: " + rsp.err_msg)
        if not rsp.updateEventRsp.ok:
            raise EtwError("updateEvent failed: " + rsp.updateEventRsp.err_msg)
            

    def resetNCOPhase(self, block_type, tile_id, block_id, device_id=0):
        req = rfdc_pb2.ResetNCOPhaseReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.resetNCOPhaseReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.resetNCOPhaseRsp:
            raise EtwError("resetNCOPhase failed: " + rsp.err_msg)
        if not rsp.resetNCOPhaseRsp.ok:
            raise EtwError("resetNCOPhase failed: " + rsp.resetNCOPhaseRsp.err_msg)

        
    def multiBand(self, block_type, tile_id,
                  digital_data_path_mask, mixer_in_out_data_type, data_converter_mask,
                  device_id=0):
        req = rfdc_pb2.MultiBandReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.digital_data_path_mask = digital_data_path_mask
        req.mixer_in_out_data_type = mixer_in_out_data_type
        req.data_converter_mask = data_converter_mask
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.multiBandReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.multiBandRsp:
            raise EtwError("multiBand failed: " + rsp.err_msg)
        if not rsp.multiBandRsp.ok:
            raise EtwError("multiBand failed: " + rsp.multiBandRsp.err_msg)
            
    def intrClr(self, block_type, tile_id, block_id, intr_mask, device_id=0):
        req = rfdc_pb2.IntrClrReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.intr_mask = intr_mask
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.intrClrReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.intrClrRsp:
            raise EtwError("intrClr failed: " + rsp.err_msg)
        if not rsp.intrClrRsp.ok:
            raise EtwError("intrClr failed: " + rsp.intrClrRsp.err_msg)
            
    def getIntrStatus(self, block_type, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetIntrStatusReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getIntrStatusReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getIntrStatusRsp:
            raise EtwError("getIntrStatus failed: " + rsp.err_msg)
        if not rsp.getIntrStatusRsp.ok:
            raise EtwError("getIntrStatus failed: " + rsp.getIntrStatusRsp.err_msg)
        return rsp.getIntrStatusRsp.intr_status
           
    def setupFifo(self, block_type, tile_id, enable, device_id=0):
        req = rfdc_pb2.SetupFifoReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.enable = enable
        rfdcIn = rfdc_pb2.RfdcIn();
        rfdcIn.setupFifoReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setupFifoRsp:
            raise EtwError("setupFifo failed: " + rsp.err_msg)
        if not rsp.setupFifoRsp.ok:
            raise EtwError("setupFifo failed: " + rsp.setupFifoRsp.err_msg)

    def getFifoStatus(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetFifoStatusReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getFifoStatusReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getFifoStatusRsp:
            raise EtwError("getFifoStatus failed: " + rsp.err_msg)
        if not rsp.getFifoStatusRsp.ok:
            raise EtwError("getFifoStatus failed: " + rsp.getFifoStatusRsp.err_msg)
        return rsp.getFifoStatusRsp.enable
           
        
    def setNyquistZone(self, block_type, tile_id, block_id, zone, device_id=0):
        req = rfdc_pb2.SetNyquistZoneReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.nyquist_zone = zone
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setNyquistZoneReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setNyquistZoneRsp:
            raise EtwError("setNyquistZone failed: " + rsp.err_msg)
        if not rsp.setNyquistZoneRsp.ok:
            raise EtwError("setNyquistZone failed: " + rsp.setNyquistZoneRsp.err_msg)
            
    def getNyquistZone(self, block_type, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetNyquistZoneReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getNyquistZoneReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getNyquistZoneRsp:
            raise EtwError("getNyquistZone failed: " + rsp.err_msg)
        if not rsp.getNyquistZoneRsp.ok:
            raise EtwError("getNyquistZone failed: " + rsp.getNyquistZoneRsp.err_msg)
        return rsp.getNyquistZoneRsp.nyquist_zone
           
    def getOutputCurr(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetOutputCurrReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getOutputCurrReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getOutputCurrRsp:
            raise EtwError("getOutputCurr failed: " + rsp.err_msg)
        if not rsp.getOutputCurrRsp.ok:
            raise EtwError("getOutputCurr failed: " + rsp.getOutputCurrRsp.err_msg)
        return rsp.getOutputCurrRsp.output_curr
           
    def setFabClkOutDiv(self, block_type, tile_id, fab_clk_div, device_id=0):
        req = rfdc_pb2.SetFabClkOutDivReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.fab_clk_div = fab_clk_div
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setFabClkOutDivReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setFabClkOutDivRsp:
            raise EtwError("setFabClkOutDiv failed: " + rsp.err_msg)
        if not rsp.setFabClkOutDivRsp.ok:
            raise EtwError("setFabClkOutDiv failed: " + rsp.setFabClkOutDivRsp.err_msg)
            
    def getFabClkOutDiv(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetFabClkOutDivReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getFabClkOutDivReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getFabClkOutDivRsp:
            raise EtwError("getFabClkOutDiv failed: " + rsp.err_msg)
        if not rsp.getFabClkOutDivRsp.ok:
            raise EtwError("getFabClkOutDiv failed: " + rsp.getFabClkOutDivRsp.err_msg)
        return rsp.getFabClkOutDivRsp.fab_clk_div
           
    def setCalibrationMode(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetCalibrationModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.calibration_mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setCalibrationModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setCalibrationModeRsp:
            raise EtwError("setCalibrationMode failed: " + rsp.err_msg)
        if not rsp.setCalibrationModeRsp.ok:
            raise EtwError("setCalibrationMode failed: " + rsp.setCalibrationModeRsp.err_msg)
            
    def getCalibrationMode(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetCalibrationModeReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getCalibrationModeReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getCalibrationModeRsp:
            raise EtwError("getCalibrationMode failed: " + rsp.err_msg)
        if not rsp.getCalibrationModeRsp.ok:
            raise EtwError("getCalibrationMode failed: " + rsp.getCalibrationModeRsp.err_msg)
        return rsp.getCalibrationModeRsp.calibration_mode
           
    def getClockSource(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetClockSourceReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getClockSourceReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getClockSourceRsp:
            raise EtwError("getClockSource failed: " + rsp.err_msg)
        if not rsp.getClockSourceRsp.ok:
            raise EtwError("getClockSource failed: " + rsp.getClockSourceRsp.err_msg)
        return rsp.getClockSourceRsp.clock_source
           
    def getPLLLockStatus(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetPLLLockStatusReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getPLLLockStatusReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getPLLLockStatusRsp:
            raise EtwError("getPLLLockStatus failed: " + rsp.err_msg)
        if not rsp.getPLLLockStatusRsp.ok:
            raise EtwError("getPLLLockStatus failed: " + rsp.getPLLLockStatusRsp.err_msg)
        return rsp.getPLLLockStatusRsp.lock_status
           
    def getPLLConfig(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetPLLConfigReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getPLLConfigReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getPLLConfigRsp:
            raise EtwError("getPLLConfig failed: " + rsp.err_msg)
        if not rsp.getPLLConfigRsp.ok:
            raise EtwError("getPLLConfig failed: " + rsp.getPLLConfigRsp.err_msg)
        return rsp.getPLLConfigRsp.settings
           
    def dynamicPLLConfig(self, block_type, tile_id, source, ref_clk_freq, sampling_rate, device_id=0):
        req = rfdc_pb2.DynamicPLLConfigReq()
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        req.source = source
        req.ref_clk_freq = ref_clk_freq
        req.sampling_rate = sampling_rate
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.dynamicPLLConfigReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.dynamicPLLConfigRsp:
            raise EtwError("dynamicPLLConfig failed: " + rsp.err_msg)
        if not rsp.dynamicPLLConfigRsp.ok:
            raise EtwError("dynamicPLLConfig failed: " + rsp.dynamicPLLConfigRsp.err_msg)
            
    def setInvSincFIR(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetInvSincFIRReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setInvSincFIRReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setInvSincFIRRsp:
            raise EtwError("setInvSincFIR failed: " + rsp.err_msg)
        if not rsp.setInvSincFIRRsp.ok:
            raise EtwError("setInvSincFIR failed: " + rsp.setInvSincFIRRsp.err_msg)
            
    def getInvSincFIR(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetInvSincFIRReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getInvSincFIRReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getInvSincFIRRsp:
            raise EtwError("getInvSincFIR failed: " + rsp.err_msg)
        if not rsp.getInvSincFIRRsp.ok:
            raise EtwError("getInvSincFIR failed: " + rsp.getInvSincFIRRsp.err_msg)
        return rsp.getInvSincFIRRsp.mode
           
    def getLinkCoupling(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetLinkCouplingReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getLinkCouplingReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getLinkCouplingRsp:
            raise EtwError("getLinkCoupling failed: " + rsp.err_msg)
        if not rsp.getLinkCouplingRsp.ok:
            raise EtwError("getLinkCoupling failed: " + rsp.getLinkCouplingRsp.err_msg)
        return rsp.getLinkCouplingRsp.mode
           
    def setDither(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetDitherReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDitherReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDitherRsp:
            raise EtwError("setDither failed: " + rsp.err_msg)
        if not rsp.setDitherRsp.ok:
            raise EtwError("setDither failed: " + rsp.setDitherRsp.err_msg)
            
    def getDither(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDitherReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDitherReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDitherRsp:
            raise EtwError("getDither failed: " + rsp.err_msg)
        if not rsp.getDitherRsp.ok:
            raise EtwError("getDither failed: " + rsp.getDitherRsp.err_msg)
        return rsp.getDitherRsp.mode
           
    def setDataPathMode(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetDataPathModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDataPathModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDataPathModeRsp:
            raise EtwError("setDataPathMode failed: " + rsp.err_msg)
        if not rsp.setDataPathModeRsp.ok:
            raise EtwError("setDataPathMode failed: " + rsp.setDataPathModeRsp.err_msg)
            
    def getDataPathMode(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDataPathModeReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDataPathModeReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDataPathModeRsp:
            raise EtwError("getDataPathMode failed: " + rsp.err_msg)
        if not rsp.getDataPathModeRsp.ok:
            raise EtwError("getDataPathMode failed: " + rsp.getDataPathModeRsp.err_msg)
        return rsp.getDataPathModeRsp.mode
          
    def setIMRPassMode(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetIMRPassModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setIMRPassModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setIMRPassModeRsp:
            raise EtwError("setIMRPassMode failed: " + rsp.err_msg)
        if not rsp.setIMRPassModeRsp.ok:
            raise EtwError("setIMRPassMode failed: " + rsp.setIMRPassModeRsp.err_msg)
            
    def getIMRPassMode(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetIMRPassModeReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getIMRPassModeReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getIMRPassModeRsp:
            raise EtwError("getIMRPassMode failed: " + rsp.err_msg)
        if not rsp.getIMRPassModeRsp.ok:
            raise EtwError("getIMRPassMode failed: " + rsp.getIMRPassModeRsp.err_msg)
        return rsp.getIMRPassModeRsp.mode

    def setSignalDetector(self, tile_id, block_id, mode, time_constant, flush=False,
                          enable_integrator=False, high_threshold=0, low_threshold=0, hysteresis_enable=False, device_id=0):
        req = rfdc_pb2.SetSignalDetectorReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        
        settings = rfdc_pb2.SignalDetectorSettings()
        settings.mode = mode
        settings.time_constant = time_constant
        settings.flush = flush
        settings.enable_integrator = enable_integrator
        settings.high_threshold = high_threshold
        settings.low_threshold = low_threshold
        settings.hysteresis_enable = hysteresis_enable
        req.settings.CopyFrom(settings)
        
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setSignalDetectorReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setSignalDetectorRsp:
            raise EtwError("setSignalDetector failed: " + rsp.err_msg)
        if not rsp.setSignalDetectorRsp.ok:
            raise EtwError("setSignalDetector failed: " + rsp.setSignalDetectorRsp.err_msg)
            
    def getSignalDetector(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetSignalDetectorReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getSignalDetectorReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getSignalDetectorRsp:
            raise EtwError("getSignalDetector failed: " + rsp.err_msg)
        if not rsp.getSignalDetectorRsp.ok:
            raise EtwError("getSignalDetector failed: " + rsp.getSignalDetectorRsp.err_msg)
        return rsp.getSignalDetectorRsp.settings

    def disableCoefficientsOverride(self, tile_id, block_id, calibration_block, device_id=0):
        req = rfdc_pb2.DisableCoefficientsOverrideReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.calibration_block = calibration_block
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.disableCoefficientsOverrideReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.disableCoefficientsOverrideRsp:
            raise EtwError("DisableCoefficientsOverride failed: " + rsp.err_msg)
        if not rsp.disableCoefficientsOverrideRsp.ok:
            raise EtwError("DisableCoefficientsOverride failed: " + rsp.disableCoefficientsOverrideRsp.err_msg)
            
    def setCalCoefficients(self, tile_id, block_id, calibration_block, coefficients, device_id=0):
        req = rfdc_pb2.SetCalCoefficientsReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.calibration_block = calibration_block
        
        settings = rfdc_pb2.CalibrationCoefficients()
        settings.coeff_0 = coefficients[0]
        settings.coeff_1 = coefficients[1]
        settings.coeff_2 = coefficients[2]
        settings.coeff_3 = coefficients[3]
        settings.coeff_4 = coefficients[4]
        settings.coeff_5 = coefficients[5]
        settings.coeff_6 = coefficients[6]
        settings.coeff_7 = coefficients[7]
        req.settings.CopyFrom(settings)
        
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setCalCoefficientsReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setCalCoefficientsRsp:
            raise EtwError("setCalCoefficients failed: " + rsp.err_msg)
        if not rsp.setCalCoefficientsRsp.ok:
            raise EtwError("setCalCoefficients failed: " + rsp.setCalCoefficientsRsp.err_msg)
            
    def getCalCoefficients(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetCalCoefficientsReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getCalCoefficientsReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getCalCoefficientsRsp:
            raise EtwError("getCalCoefficients failed: " + rsp.err_msg)
        if not rsp.getCalCoefficientsRsp.ok:
            raise EtwError("getCalCoefficients failed: " + rsp.getCalCoefficientsRsp.err_msg)
        result = []
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_0)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_1)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_2)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_3)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_4)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_5)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_6)
        result.append(rsp.getCalCoefficientsRsp.settings.coeff_7)
    
        return result

    def setCalFreeze(self, tile_id, block_id, disable_freeze_pin, freeze_calibration, device_id=0):
        req = rfdc_pb2.SetCalFreezeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        
        settings = rfdc_pb2.CalibrationFreezeSettings()
        settings.disable_freeze_pin = disable_freeze_pin
        settings.freeze_calibration = freeze_calibration
        req.settings.CopyFrom(settings)
        
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setCalFreezeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setCalFreezeRsp:
            raise EtwError("setCalFreeze failed: " + rsp.err_msg)
        if not rsp.setCalFreezeRsp.ok:
            raise EtwError("setCalFreeze failed: " + rsp.setCalFreezeRsp.err_msg)
            
    def getCalFreeze(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetCalFreezeReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getCalFreezeReq.CopyFrom(req)
        debug(rfdcIn)
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp)
        if not rsp.getCalFreezeRsp:
            raise EtwError("getCalFreeze failed: " + rsp.err_msg)
        if not rsp.getCalFreezeRsp.ok:
            raise EtwError("getCalFreeze failed: " + rsp.getCalFreezeRsp.err_msg)
        return rsp.getCalFreezeRsp.settings

    def multiConverterInit(self, block_type, device_id=0):
        req = rfdc_pb2.MultiConverterInitReq();
        req.block_type = block_type
        req.device_id = device_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.multiConverterInitReq.CopyFrom(req)
        debug(rfdcIn)
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp)
        if not rsp.multiConverterInitRsp:
            raise EtwError("multiConverterInit failed: " + rsp.err_msg)
        if not rsp.multiConverterInitRsp.ok:
            raise EtwError("multiConverterInit failed: " + rsp.multiConverterInitRsp.err_msg)
        return rsp.multiConverterInitRsp.sync_config

    def multiConverterSync(self, block_type, sync_config, device_id=0):
        req = rfdc_pb2.MultiConverterSyncReq()
        req.block_type = block_type
        req.device_id = device_id
        req.sync_config.CopyFrom(sync_config)
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.multiConverterSyncReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.multiConverterSyncRsp:
            raise EtwError("multiConverterSync failed: " + rsp.err_msg)
        if not rsp.multiConverterSyncRsp.ok:
            raise EtwError("multiConverterSync failed: " + rsp.multiConverterSyncRsp.err_msg)
            
    def mtsSysRefConfig(self, dac_sync_config, adc_sync_config, sys_ref_enable, device_id=0):
        req = rfdc_pb2.MTSSysRefConfigReq()
        req.device_id = device_id
        req.dac_sync_config.CopyFrom(dac_sync_config)
        req.adc_sync_config.CopyFrom(adc_sync_config)
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.mtsSysRefConfigReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.mtsSysRefConfigRsp:
            raise EtwError("MTSSysRefConfig failed: " + rsp.err_msg)
        if not rsp.mtsSysRefConfigRsp.ok:
            raise EtwError("MTSSysRefConfig failed: " + rsp.MTSSysRefConfigRsp.err_msg)
            
    def getMTSEnable(self, block_type, tile_id, device_id=0):
        req = rfdc_pb2.GetMTSEnableReq();
        req.block_type = block_type
        req.device_id = device_id
        req.tile_id = tile_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getMTSEnableReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getMTSEnableRsp:
            raise EtwError("getMTSEnable failed: " + rsp.err_msg)
        if not rsp.getMTSEnableRsp.ok:
            raise EtwError("getMTSEnable failed: " + rsp.getMTSEnableRsp.err_msg)
        return rsp.getMTSEnableRsp.enable

    def setDSA(self, tile_id, block_id, attenuation, device_id=0):
        req = rfdc_pb2.SetDSAReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.attenuation = attenuation
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDSAReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDSARsp:
            raise EtwError("setDSA failed: " + rsp.err_msg)
        if not rsp.setDSARsp.ok:
            raise EtwError("setDSA failed: " + rsp.setDSARsp.err_msg)
            
    def getDSA(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDSAReq();
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDSAReq.CopyFrom(req)
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDSARsp:
            raise EtwError("getDSA failed: " + rsp.err_msg)
        if not rsp.getDSARsp.ok:
            raise EtwError("getDSA failed: " + rsp.getDSARsp.err_msg)
        return rsp.getDSARsp.attenuation

    def setDACVOP(self, tile_id, block_id, uACurrent, device_id=0):
        req = rfdc_pb2.SetDACVOPReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.uACurrent = uACurrent
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDACVOPReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDACVOPRsp:
            raise EtwError("setDACVOP failed: " + rsp.err_msg)
        if not rsp.setDACVOPRsp.ok:
            raise EtwError("setDACVOP failed: " + rsp.setDACVOPRsp.err_msg)
            
    def setDACCompMode(self, tile_id, block_id, mode, device_id=0):
        req = rfdc_pb2.SetDACCompModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        req.mode = mode
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.setDACCompModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.setDACCompModeRsp:
            raise EtwError("setDACCompMode failed: " + rsp.err_msg)
        if not rsp.setDACCompModeRsp.ok:
            raise EtwError("setDACCompMode failed: " + rsp.setDACCompModeRsp.err_msg)
            
    def getDACCompMode(self, tile_id, block_id, device_id=0):
        req = rfdc_pb2.GetDACCompModeReq()
        req.device_id = device_id
        req.tile_id = tile_id
        req.block_id = block_id
        rfdcIn = rfdc_pb2.RfdcIn()
        rfdcIn.getDACCompModeReq.CopyFrom(req);
        debug(rfdcIn) 
        rsp = self.gw.methodCall(rfdcIn, rfdc_pb2.RfdcOut)
        debug(rsp) 
        if not rsp.getDACCompModeRsp:
            raise EtwError("getDACCompMode failed: " + rsp.err_msg)
        if not rsp.getDACCompModeRsp.ok:
            raise EtwError("getDACCompMode failed: " + rsp.getDACCompModeRsp.err_msg)
        return rsp.getDACCompModeRsp.mode

        
