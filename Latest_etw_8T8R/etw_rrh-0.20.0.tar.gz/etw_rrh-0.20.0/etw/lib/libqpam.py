from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libqpam_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libqpamProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibqpam", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def QPAM_returnStatusType_fromDict(self, dict):
        x = libqpam_pb2.QPAM_returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def QPAM_current_monitorType_fromDict(self, dict):
        x = libqpam_pb2.QPAM_current_monitorType()
        if not dict: return x
        setattr(x, "Driver_Main_Amplifier", dict.get("Driver_Main_Amplifier", 0))
        setattr(x, "Final_Main_Amplifier", dict.get("Final_Main_Amplifier", 0))
        return x

    def QPAM_PA_BiasType_fromDict(self, dict):
        x = libqpam_pb2.QPAM_PA_BiasType()
        if not dict: return x
        setattr(x, "Pre_driver", dict.get("Pre_driver", 0))
        setattr(x, "Driver_Main_Amplifier", dict.get("Driver_Main_Amplifier", 0))
        setattr(x, "Driver_Peaking_Amplifier", dict.get("Driver_Peaking_Amplifier", 0))
        setattr(x, "Final_Main_Amplifier_1", dict.get("Final_Main_Amplifier_1", 0))
        setattr(x, "Final_Main_Amplifier_2", dict.get("Final_Main_Amplifier_2", 0))
        setattr(x, "Final_Peaking_Amplifier_1", dict.get("Final_Peaking_Amplifier_1", 0))
        setattr(x, "Final_Peaking_Amplifier_2", dict.get("Final_Peaking_Amplifier_2", 0))
        return x

    def QPAM_returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def QPAM_current_monitorType_toDict(self, v):
        dict = {}
        dict["Driver_Main_Amplifier"] = getattr(v, "Driver_Main_Amplifier")
        dict["Final_Main_Amplifier"] = getattr(v, "Final_Main_Amplifier")
        return dict

    def QPAM_PA_BiasType_toDict(self, v):
        dict = {}
        dict["Pre_driver"] = getattr(v, "Pre_driver")
        dict["Driver_Main_Amplifier"] = getattr(v, "Driver_Main_Amplifier")
        dict["Driver_Peaking_Amplifier"] = getattr(v, "Driver_Peaking_Amplifier")
        dict["Final_Main_Amplifier_1"] = getattr(v, "Final_Main_Amplifier_1")
        dict["Final_Main_Amplifier_2"] = getattr(v, "Final_Main_Amplifier_2")
        dict["Final_Peaking_Amplifier_1"] = getattr(v, "Final_Peaking_Amplifier_1")
        dict["Final_Peaking_Amplifier_2"] = getattr(v, "Final_Peaking_Amplifier_2")
        return dict

    def QPAM_Control_Init(self):
        _req = libqpam_pb2.QPAM_Control_InitReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_Init failed: no valid response found (qPAM_Control_Init)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_InitRsp._ret)

    def QPAM_MaxChip_Control_Init(self, qpamID):
        _req = libqpam_pb2.QPAM_MaxChip_Control_InitReq()
        _req.qpamID = qpamID
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_MaxChip_Control_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_MaxChip_Control_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_MaxChip_Control_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_MaxChip_Control_Init failed: no valid response found (qPAM_MaxChip_Control_Init)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_MaxChip_Control_InitRsp._ret)

    def QPAM_Setdefault_Bias_voltage(self, qpamID):
        _req = libqpam_pb2.QPAM_Setdefault_Bias_voltageReq()
        _req.qpamID = qpamID
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Setdefault_Bias_voltageReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Setdefault_Bias_voltageRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Setdefault_Bias_voltage failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Setdefault_Bias_voltage failed: no valid response found (qPAM_Setdefault_Bias_voltage)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Setdefault_Bias_voltageRsp._ret)

    def QPAM_Control_SetTxKey(self, port, enableDisable):
        _req = libqpam_pb2.QPAM_Control_SetTxKeyReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetTxKeyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetTxKeyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetTxKey failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetTxKey failed: no valid response found (qPAM_Control_SetTxKey)")

    def QPAM_Control_SetRxKey(self, port, enableDisable):
        _req = libqpam_pb2.QPAM_Control_SetRxKeyReq()
        _req.port = port
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetRxKeyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetRxKeyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetRxKey failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetRxKey failed: no valid response found (qPAM_Control_SetRxKey)")

    def QPAM_Control_SetPaVdd(self, qpamID, enableDisable):
        _req = libqpam_pb2.QPAM_Control_SetPaVddReq()
        _req.qpamID = qpamID
        _req.enableDisable = enableDisable
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetPaVddReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetPaVddRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetPaVdd failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetPaVdd failed: no valid response found (qPAM_Control_SetPaVdd)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_SetPaVddRsp._ret)

    def QPAM_Control_SetTddMode(self, qpamID, mode):
        _req = libqpam_pb2.QPAM_Control_SetTddModeReq()
        _req.qpamID = qpamID
        _req.mode = mode
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetTddModeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetTddModeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetTddMode failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetTddMode failed: no valid response found (qPAM_Control_SetTddMode)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_SetTddModeRsp._ret)

    def QPAM_Control_SetORxMuxCtrl(self, port, fwdRev):
        _req = libqpam_pb2.QPAM_Control_SetORxMuxCtrlReq()
        _req.port = port
        _req.fwdRev = fwdRev
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetORxMuxCtrlReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetORxMuxCtrlRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetORxMuxCtrl failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetORxMuxCtrl failed: no valid response found (qPAM_Control_SetORxMuxCtrl)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_SetORxMuxCtrlRsp._ret)

    def QPAM_Control_GetPaCurrentMonitorVoltage(self, port):
        _req = libqpam_pb2.QPAM_Control_GetPaCurrentMonitorVoltageReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_GetPaCurrentMonitorVoltageReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_GetPaCurrentMonitorVoltageRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_GetPaCurrentMonitorVoltage failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_GetPaCurrentMonitorVoltage failed: no valid response found (qPAM_Control_GetPaCurrentMonitorVoltage)")
        return self.QPAM_current_monitorType_toDict(_rsp.qPAM_Control_GetPaCurrentMonitorVoltageRsp.Current_Mon), self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_GetPaCurrentMonitorVoltageRsp._ret)

    def QPAM_Control_SetPaBias(self, port):
        _req = libqpam_pb2.QPAM_Control_SetPaBiasReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_SetPaBiasReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_SetPaBiasRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_SetPaBias failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_SetPaBias failed: no valid response found (qPAM_Control_SetPaBias)")
        return self.QPAM_PA_BiasType_toDict(_rsp.qPAM_Control_SetPaBiasRsp.PA_Bias_voltage), self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_SetPaBiasRsp._ret)

    def QPAM_Control_GetPaBias(self, port):
        _req = libqpam_pb2.QPAM_Control_GetPaBiasReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_GetPaBiasReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_GetPaBiasRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_GetPaBias failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_GetPaBias failed: no valid response found (qPAM_Control_GetPaBias)")
        return self.QPAM_PA_BiasType_toDict(_rsp.qPAM_Control_GetPaBiasRsp.PA_Bias_voltage), self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_GetPaBiasRsp._ret)

    def QPAM_Control_TxPortReadTemp(self, port):
        _req = libqpam_pb2.QPAM_Control_TxPortReadTempReq()
        _req.port = port
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_TxPortReadTempReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_TxPortReadTempRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_TxPortReadTemp failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_TxPortReadTemp failed: no valid response found (qPAM_Control_TxPortReadTemp)")
        return _rsp.qPAM_Control_TxPortReadTempRsp.TempDataCelsius, self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_TxPortReadTempRsp._ret)

    def QPAM_Control_GetPaBiasStepSize(self):
        _req = libqpam_pb2.QPAM_Control_GetPaBiasStepSizeReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_GetPaBiasStepSizeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_GetPaBiasStepSizeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_GetPaBiasStepSize failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_GetPaBiasStepSize failed: no valid response found (qPAM_Control_GetPaBiasStepSize)")
        return _rsp.qPAM_Control_GetPaBiasStepSizeRsp._ret

    def QPAM_Control_HasPaCurrentMonitor(self):
        _req = libqpam_pb2.QPAM_Control_HasPaCurrentMonitorReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_HasPaCurrentMonitorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_HasPaCurrentMonitorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_HasPaCurrentMonitor failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_HasPaCurrentMonitor failed: no valid response found (qPAM_Control_HasPaCurrentMonitor)")
        return _rsp.qPAM_Control_HasPaCurrentMonitorRsp.paCurrentMontiorExist, self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_HasPaCurrentMonitorRsp._ret)

    def QPAM_Control_GetMaxDeviceID(self, qpamID):
        _req = libqpam_pb2.QPAM_Control_GetMaxDeviceIDReq()
        _req.qpamID = qpamID
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_GetMaxDeviceIDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_GetMaxDeviceIDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_GetMaxDeviceID failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_GetMaxDeviceID failed: no valid response found (qPAM_Control_GetMaxDeviceID)")
        return _rsp.qPAM_Control_GetMaxDeviceIDRsp.deviceID, self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_GetMaxDeviceIDRsp._ret)

    def QPAM_Control_GetVoltage_PAVDD(self, qpamID):
        _req = libqpam_pb2.QPAM_Control_GetVoltage_PAVDDReq()
        _req.qpamID = qpamID
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_GetVoltage_PAVDDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_GetVoltage_PAVDDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_GetVoltage_PAVDD failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_GetVoltage_PAVDD failed: no valid response found (qPAM_Control_GetVoltage_PAVDD)")
        return _rsp.qPAM_Control_GetVoltage_PAVDDRsp.voltage_MAX_PD_15, self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_GetVoltage_PAVDDRsp._ret)

    def QPAM_Control_Deinit(self):
        _req = libqpam_pb2.QPAM_Control_DeinitReq()
        _inMsg = libqpam_pb2.libqpamIn()
        _inMsg.qPAM_Control_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libqpam_pb2.libqpamOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "qPAM_Control_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("QPAM_Control_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("QPAM_Control_Deinit failed: no valid response found (qPAM_Control_Deinit)")
        return self.QPAM_returnStatusType_toDict(_rsp.qPAM_Control_DeinitRsp._ret)

