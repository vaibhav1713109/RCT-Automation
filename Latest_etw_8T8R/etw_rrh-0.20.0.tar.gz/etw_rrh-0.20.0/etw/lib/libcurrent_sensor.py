from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libcurrent_sensor_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libcurrent_sensorProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibcurrent_sensor", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def temperatureValue_fromDict(self, dict):
        x = libcurrent_sensor_pb2.temperatureValue()
        if not dict: return x
        for v in dict.get("temperatureValues", []):
            getattr(x, "temperatureValues").append(v)
        for v in dict.get("tempReadBuf", []):
            getattr(x, "tempReadBuf").append(v)
        return x

    def temperatureValue_toDict(self, v):
        dict = {}
        dict["temperatureValues"] = getattr(v, "temperatureValues")[:]
        dict["tempReadBuf"] = getattr(v, "tempReadBuf")[:]
        return dict

    def SetTempLimit(self, diode):
        _req = libcurrent_sensor_pb2.SetTempLimitReq()
        _req.diode = diode
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.setTempLimitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "setTempLimitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("SetTempLimit failed: " + _rsp.zzerr_msg)
            raise EtwError("SetTempLimit failed: no valid response found (setTempLimit)")
        return _rsp.setTempLimitRsp.tmp468Slave, _rsp.setTempLimitRsp.lowLimit, _rsp.setTempLimitRsp.highLimit, _rsp.setTempLimitRsp._ret

    def GetTempThreshold(self, diode):
        _req = libcurrent_sensor_pb2.GetTempThresholdReq()
        _req.diode = diode
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.getTempThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getTempThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetTempThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("GetTempThreshold failed: no valid response found (getTempThreshold)")
        return _rsp.getTempThresholdRsp.tmp468Slave, _rsp.getTempThresholdRsp.threshold, _rsp.getTempThresholdRsp._ret

    def GetTempHysteresis(self):
        _req = libcurrent_sensor_pb2.GetTempHysteresisReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.getTempHysteresisReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getTempHysteresisRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetTempHysteresis failed: " + _rsp.zzerr_msg)
            raise EtwError("GetTempHysteresis failed: no valid response found (getTempHysteresis)")
        return _rsp.getTempHysteresisRsp.tmp468Slave, _rsp.getTempHysteresisRsp.hyteresis, _rsp.getTempHysteresisRsp._ret

    def GetTempStatus(self):
        _req = libcurrent_sensor_pb2.GetTempStatusReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.getTempStatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getTempStatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetTempStatus failed: " + _rsp.zzerr_msg)
            raise EtwError("GetTempStatus failed: no valid response found (getTempStatus)")
        return _rsp.getTempStatusRsp.tmp468Slave, _rsp.getTempStatusRsp.tempStatus, _rsp.getTempStatusRsp._ret

    def SetTempHysteresis(self):
        _req = libcurrent_sensor_pb2.SetTempHysteresisReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.setTempHysteresisReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "setTempHysteresisRsp":
            if _rsp.zzerr_msg:
                raise EtwError("SetTempHysteresis failed: " + _rsp.zzerr_msg)
            raise EtwError("SetTempHysteresis failed: no valid response found (setTempHysteresis)")
        return _rsp.setTempHysteresisRsp.tmp468Slave, _rsp.setTempHysteresisRsp.hysteresis, _rsp.setTempHysteresisRsp._ret

    def GetRegValue(self, SensorId, diodeAddress):
        _req = libcurrent_sensor_pb2.GetRegValueReq()
        _req.SensorId = SensorId
        _req.diodeAddress = diodeAddress
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.getRegValueReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getRegValueRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetRegValue failed: " + _rsp.zzerr_msg)
            raise EtwError("GetRegValue failed: no valid response found (getRegValue)")
        return _rsp.getRegValueRsp._ret

    def GetTemp(self):
        _req = libcurrent_sensor_pb2.GetTempReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.getTempReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "getTempRsp":
            if _rsp.zzerr_msg:
                raise EtwError("GetTemp failed: " + _rsp.zzerr_msg)
            raise EtwError("GetTemp failed: no valid response found (getTemp)")
        return _rsp.getTempRsp.tmp468Slave, _rsp.getTempRsp.readTemp, _rsp.getTempRsp.diodeStatus, _rsp.getTempRsp._ret

    def TemperatureSensorInit(self):
        _req = libcurrent_sensor_pb2.TemperatureSensorInitReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureSensorInitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureSensorInitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureSensorInit failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureSensorInit failed: no valid response found (temperatureSensorInit)")
        return _rsp.temperatureSensorInitRsp._ret

    def UnlockTemperatureSensor(self, arrcTempSensor):
        _req = libcurrent_sensor_pb2.UnlockTemperatureSensorReq()
        _req.arrcTempSensor = arrcTempSensor
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.unlockTemperatureSensorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "unlockTemperatureSensorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UnlockTemperatureSensor failed: " + _rsp.zzerr_msg)
            raise EtwError("UnlockTemperatureSensor failed: no valid response found (unlockTemperatureSensor)")
        return _rsp.unlockTemperatureSensorRsp._ret

    def TemperatureHystSet(self, SensorId, hyteresis):
        _req = libcurrent_sensor_pb2.TemperatureHystSetReq()
        _req.SensorId = SensorId
        _req.hyteresis = hyteresis
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureHystSetReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureHystSetRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureHystSet failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureHystSet failed: no valid response found (temperatureHystSet)")
        return _rsp.temperatureHystSetRsp._ret

    def TemperatureLimitSet(self, SensorId, highDiodeAddr, lowDiodeAddr, lowTemp, highTemp):
        _req = libcurrent_sensor_pb2.TemperatureLimitSetReq()
        _req.SensorId = SensorId
        _req.highDiodeAddr = highDiodeAddr
        _req.lowDiodeAddr = lowDiodeAddr
        _req.lowTemp = lowTemp
        _req.highTemp = highTemp
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureLimitSetReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureLimitSetRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureLimitSet failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureLimitSet failed: no valid response found (temperatureLimitSet)")
        return _rsp.temperatureLimitSetRsp._ret

    def OpenTemperatureSensor(self):
        _req = libcurrent_sensor_pb2.OpenTemperatureSensorReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.openTemperatureSensorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "openTemperatureSensorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("OpenTemperatureSensor failed: " + _rsp.zzerr_msg)
            raise EtwError("OpenTemperatureSensor failed: no valid response found (openTemperatureSensor)")
        return _rsp.openTemperatureSensorRsp.tmp468Slave, _rsp.openTemperatureSensorRsp._ret

    def TemperatureSensorAddress(self, SensorId, addressLsb, addressMsb, addressSize):
        _req = libcurrent_sensor_pb2.TemperatureSensorAddressReq()
        _req.SensorId = SensorId
        _req.addressLsb = addressLsb
        _req.addressMsb = addressMsb
        _req.addressSize = addressSize
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureSensorAddressReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureSensorAddressRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureSensorAddress failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureSensorAddress failed: no valid response found (temperatureSensorAddress)")
        return _rsp.temperatureSensorAddressRsp._ret

    def TemperatureSensorWrite(self, SensorId, addr, numberOfBytes):
        _req = libcurrent_sensor_pb2.TemperatureSensorWriteReq()
        _req.SensorId = SensorId
        _req.addr = addr
        _req.numberOfBytes = numberOfBytes
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureSensorWriteReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureSensorWriteRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureSensorWrite failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureSensorWrite failed: no valid response found (temperatureSensorWrite)")
        return _rsp.temperatureSensorWriteRsp.writeBuf, _rsp.temperatureSensorWriteRsp._ret

    def TemperatureSensorAddressRead(self, SensorId, addressLsb, addressMsb, addressSize):
        _req = libcurrent_sensor_pb2.TemperatureSensorAddressReadReq()
        _req.SensorId = SensorId
        _req.addressLsb = addressLsb
        _req.addressMsb = addressMsb
        _req.addressSize = addressSize
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureSensorAddressReadReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureSensorAddressReadRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureSensorAddressRead failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureSensorAddressRead failed: no valid response found (temperatureSensorAddressRead)")
        return _rsp.temperatureSensorAddressReadRsp._ret

    def TemperatureSensorRead(self, SensorId, numberOfBytes):
        _req = libcurrent_sensor_pb2.TemperatureSensorReadReq()
        _req.SensorId = SensorId
        _req.numberOfBytes = numberOfBytes
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.temperatureSensorReadReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "temperatureSensorReadRsp":
            if _rsp.zzerr_msg:
                raise EtwError("TemperatureSensorRead failed: " + _rsp.zzerr_msg)
            raise EtwError("TemperatureSensorRead failed: no valid response found (temperatureSensorRead)")
        return self.temperatureValue_toDict(_rsp.temperatureSensorReadRsp.readBuf), _rsp.temperatureSensorReadRsp._ret

    def ReadStatus(self, SensorId, statusRegAddr):
        _req = libcurrent_sensor_pb2.ReadStatusReq()
        _req.SensorId = SensorId
        _req.statusRegAddr = statusRegAddr
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.readStatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "readStatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("ReadStatus failed: " + _rsp.zzerr_msg)
            raise EtwError("ReadStatus failed: no valid response found (readStatus)")
        return _rsp.readStatusRsp._ret

    def ConvertFloatToInt(self, temp):
        _req = libcurrent_sensor_pb2.ConvertFloatToIntReq()
        _req.temp = temp
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.convertFloatToIntReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "convertFloatToIntRsp":
            if _rsp.zzerr_msg:
                raise EtwError("ConvertFloatToInt failed: " + _rsp.zzerr_msg)
            raise EtwError("ConvertFloatToInt failed: no valid response found (convertFloatToInt)")
        return _rsp.convertFloatToIntRsp._ret

    def CloseTemperatureSensor(self):
        _req = libcurrent_sensor_pb2.CloseTemperatureSensorReq()
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.closeTemperatureSensorReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "closeTemperatureSensorRsp":
            if _rsp.zzerr_msg:
                raise EtwError("CloseTemperatureSensor failed: " + _rsp.zzerr_msg)
            raise EtwError("CloseTemperatureSensor failed: no valid response found (closeTemperatureSensor)")

    def ReadDeviceID(self, SensorId):
        _req = libcurrent_sensor_pb2.ReadDeviceIDReq()
        _req.SensorId = SensorId
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.readDeviceIDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "readDeviceIDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("ReadDeviceID failed: " + _rsp.zzerr_msg)
            raise EtwError("ReadDeviceID failed: no valid response found (readDeviceID)")
        return _rsp.readDeviceIDRsp.device_id, _rsp.readDeviceIDRsp._ret

    def ReadManufacturerID(self, SensorId):
        _req = libcurrent_sensor_pb2.ReadManufacturerIDReq()
        _req.SensorId = SensorId
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.readManufacturerIDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "readManufacturerIDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("ReadManufacturerID failed: " + _rsp.zzerr_msg)
            raise EtwError("ReadManufacturerID failed: no valid response found (readManufacturerID)")
        return _rsp.readManufacturerIDRsp.manufacture_id, _rsp.readManufacturerIDRsp._ret

    def MAVU_8T8R_E2_Power_GetCurrent(self, option):
        _req = libcurrent_sensor_pb2.MAVU_8T8R_E2_Power_GetCurrentReq()
        _req.option = option
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.mAVU_8T8R_E2_Power_GetCurrentReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_E2_Power_GetCurrentRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_E2_Power_GetCurrent failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_E2_Power_GetCurrent failed: no valid response found (mAVU_8T8R_E2_Power_GetCurrent)")
        return _rsp.mAVU_8T8R_E2_Power_GetCurrentRsp.current, _rsp.mAVU_8T8R_E2_Power_GetCurrentRsp._ret

    def MAVU_8T8R_E2_Power_GetPower(self, Option):
        _req = libcurrent_sensor_pb2.MAVU_8T8R_E2_Power_GetPowerReq()
        _req.Option = Option
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.mAVU_8T8R_E2_Power_GetPowerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_E2_Power_GetPowerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_E2_Power_GetPower failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_E2_Power_GetPower failed: no valid response found (mAVU_8T8R_E2_Power_GetPower)")
        return _rsp.mAVU_8T8R_E2_Power_GetPowerRsp.power, _rsp.mAVU_8T8R_E2_Power_GetPowerRsp._ret

    def MAVU_8T8R_E2_Power_GetPowerStatus(self, option):
        _req = libcurrent_sensor_pb2.MAVU_8T8R_E2_Power_GetPowerStatusReq()
        _req.option = option
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.mAVU_8T8R_E2_Power_GetPowerStatusReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_E2_Power_GetPowerStatusRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_E2_Power_GetPowerStatus failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_E2_Power_GetPowerStatus failed: no valid response found (mAVU_8T8R_E2_Power_GetPowerStatus)")
        return _rsp.mAVU_8T8R_E2_Power_GetPowerStatusRsp.pStatus, _rsp.mAVU_8T8R_E2_Power_GetPowerStatusRsp._ret

    def MAVU_8T8R_E2_Power_SetInaThreshold(self, option):
        _req = libcurrent_sensor_pb2.MAVU_8T8R_E2_Power_SetInaThresholdReq()
        _req.option = option
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.mAVU_8T8R_E2_Power_SetInaThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_E2_Power_SetInaThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_E2_Power_SetInaThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_E2_Power_SetInaThreshold failed: no valid response found (mAVU_8T8R_E2_Power_SetInaThreshold)")
        return _rsp.mAVU_8T8R_E2_Power_SetInaThresholdRsp.curr_sensor_id, _rsp.mAVU_8T8R_E2_Power_SetInaThresholdRsp.threshold, _rsp.mAVU_8T8R_E2_Power_SetInaThresholdRsp._ret

    def MAVU_8T8R_E2_Power_GetInaThreshold(self, option):
        _req = libcurrent_sensor_pb2.MAVU_8T8R_E2_Power_GetInaThresholdReq()
        _req.option = option
        _inMsg = libcurrent_sensor_pb2.libcurrent_sensorIn()
        _inMsg.mAVU_8T8R_E2_Power_GetInaThresholdReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libcurrent_sensor_pb2.libcurrent_sensorOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "mAVU_8T8R_E2_Power_GetInaThresholdRsp":
            if _rsp.zzerr_msg:
                raise EtwError("MAVU_8T8R_E2_Power_GetInaThreshold failed: " + _rsp.zzerr_msg)
            raise EtwError("MAVU_8T8R_E2_Power_GetInaThreshold failed: no valid response found (mAVU_8T8R_E2_Power_GetInaThreshold)")
        return _rsp.mAVU_8T8R_E2_Power_GetInaThresholdRsp.curr_sensor_id, _rsp.mAVU_8T8R_E2_Power_GetInaThresholdRsp.current_value, _rsp.mAVU_8T8R_E2_Power_GetInaThresholdRsp._ret

