from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import transportprocctrl_service_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class transportprocctrl_serviceProxy:
    def __init__(self, ipcLink, service_name = "transportprocctrl"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "transportprocctrl", method_call="Method")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def SetDlFilterReq_FilterConfig_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetDlFilterReq_FilterConfig()
        if not dict: return x
        setattr(x, "ethernetInterface", dict.get("ethernetInterface", 0))
        setattr(x, "planeType", dict.get("planeType", 0))
        setattr(x, "changeIndicator", dict.get("changeIndicator", 0))
        setattr(x, "vlanId", dict.get("vlanId", 0))
        setattr(x, "ecpriMessage", dict.get("ecpriMessage", 0))
        setattr(x, "srcMacAddr", dict.get("srcMacAddr", 0))
        setattr(x, "destMacAddr", dict.get("destMacAddr", 0))
        setattr(x, "ethType", dict.get("ethType", 0))
        return x

    def SetDlFilterReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetDlFilterReq()
        if not dict: return x
        setattr(x, "filterConfig", dict.get("filterConfig", 0))
        return x

    def SetDlFilterRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetDlFilterRsp()
        if not dict: return x
        setattr(x, "result", dict.get("result", 0))
        return x

    def SetUlRouterReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetUlRouterReq()
        if not dict: return x
        setattr(x, "ethernetInterface", dict.get("ethernetInterface", 0))
        setattr(x, "srcMacAddr", dict.get("srcMacAddr", 0))
        return x

    def SetUlRouterRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetUlRouterRsp()
        if not dict: return x
        setattr(x, "result", dict.get("result", 0))
        return x

    def SetPortConfigReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetPortConfigReq()
        if not dict: return x
        for v in dict.get("portChanges", []):
            getattr(x, "portChanges").append(self.PortChanges_fromDict(v))
        return x

    def PortChanges_fromDict(self, dict):
        x = transportprocctrl_service_pb2.PortChanges()
        if not dict: return x
        setattr(x, "staticLowLevelEndpointName", dict.get("staticLowLevelEndpointName", ""))
        setattr(x, "changeIndicator", dict.get("changeIndicator", 0))
        setattr(x, "srcMacId", dict.get("srcMacId", 0))
        setattr(x, "vlanId", dict.get("vlanId", 0))
        setattr(x, "destMacAddr", dict.get("destMacAddr", 0))
        setattr(x, "duPort", dict.get("duPort", 0))
        setattr(x, "bandSector", dict.get("bandSector", 0))
        setattr(x, "ccid", dict.get("ccid", 0))
        setattr(x, "ruPort", dict.get("ruPort", 0))
        return x

    def SetPortConfigRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SetPortConfigRsp()
        if not dict: return x
        setattr(x, "errorOccurredDuringConfiguration", dict.get("errorOccurredDuringConfiguration", 0))
        return x

    def TransceiverStatsReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TransceiverStatsReq()
        if not dict: return x
        setattr(x, "measObj", dict.get("measObj", 0))
        setattr(x, "valueType", dict.get("valueType", 0))
        setattr(x, "valueScale", dict.get("valueScale", 0))
        setattr(x, "precision", dict.get("precision", 0))
        return x

    def TransceiverStatsRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TransceiverStatsRsp()
        if not dict: return x
        return x

    def RxPowerData_fromDict(self, dict):
        x = transportprocctrl_service_pb2.RxPowerData()
        if not dict: return x
        setattr(x, "data", dict.get("data", 0))
        setattr(x, "time", dict.get("time", ""))
        return x

    def TxPowerData_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TxPowerData()
        if not dict: return x
        setattr(x, "data", dict.get("data", 0))
        setattr(x, "time", dict.get("time", ""))
        return x

    def TxBiasCount_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TxBiasCount()
        if not dict: return x
        setattr(x, "data", dict.get("data", 0))
        setattr(x, "time", dict.get("time", ""))
        return x

    def Voltage_fromDict(self, dict):
        x = transportprocctrl_service_pb2.Voltage()
        if not dict: return x
        setattr(x, "data", dict.get("data", 0))
        setattr(x, "time", dict.get("time", ""))
        return x

    def Temperature_fromDict(self, dict):
        x = transportprocctrl_service_pb2.Temperature()
        if not dict: return x
        setattr(x, "data", dict.get("data", 0))
        setattr(x, "time", dict.get("time", ""))
        return x

    def TransceiverData_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TransceiverData()
        if not dict: return x
        setattr(x, "portNum", dict.get("portNum", 0))
        getattr(x, "rxPowerData").CopyFrom(self.RxPowerData_fromDict(dict.get("rxPowerData")))
        getattr(x, "txPowerData").CopyFrom(self.TxPowerData_fromDict(dict.get("txPowerData")))
        getattr(x, "txBiasCount").CopyFrom(self.TxBiasCount_fromDict(dict.get("txBiasCount")))
        getattr(x, "voltage").CopyFrom(self.Voltage_fromDict(dict.get("voltage")))
        getattr(x, "temperature").CopyFrom(self.Temperature_fromDict(dict.get("temperature")))
        return x

    def SfpReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpReq()
        if not dict: return x
        return x

    def SfpRsp_Sfp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpRsp_Sfp()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "interfaceName", dict.get("interfaceName", ""))
        setattr(x, "portNumber", dict.get("portNumber", 0))
        return x

    def SfpRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpRsp()
        if not dict: return x
        for v in dict.get("sfps", []):
            getattr(x, "sfps").append(v)
        return x

    def FhInterfacesReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.FhInterfacesReq()
        if not dict: return x
        return x

    def FhInterfacesRsp_Interface_fromDict(self, dict):
        x = transportprocctrl_service_pb2.FhInterfacesRsp_Interface()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "portName", dict.get("portName", ""))
        setattr(x, "portNumber", dict.get("portNumber", 0))
        return x

    def FhInterfacesRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.FhInterfacesRsp()
        if not dict: return x
        for v in dict.get("interfaces", []):
            getattr(x, "interfaces").append(v)
        return x

    def SfpDataReq_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpDataReq()
        if not dict: return x
        setattr(x, "name", dict.get("name", ""))
        return x

    def SfpData_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "present", dict.get("present", 0))
        setattr(x, "vendorId", dict.get("vendorId", ""))
        setattr(x, "vendorPart", dict.get("vendorPart", ""))
        setattr(x, "vendorRev", dict.get("vendorRev", ""))
        setattr(x, "serialNo", dict.get("serialNo", ""))
        setattr(x, "SFF8472Compliance", dict.get("SFF8472Compliance", 0))
        setattr(x, "connectorType", dict.get("connectorType", 0))
        setattr(x, "identifier", dict.get("identifier", 0))
        setattr(x, "nominalBitrate", dict.get("nominalBitrate", ""))
        setattr(x, "lowBitrateMargin", dict.get("lowBitrateMargin", ""))
        setattr(x, "highBitrateMargin", dict.get("highBitrateMargin", ""))
        setattr(x, "rxPowerType", dict.get("rxPowerType", 0))
        setattr(x, "rxPower", dict.get("rxPower", ""))
        setattr(x, "txPower", dict.get("txPower", ""))
        setattr(x, "txBiasCurrent", dict.get("txBiasCurrent", ""))
        setattr(x, "voltage", dict.get("voltage", ""))
        setattr(x, "temperature", dict.get("temperature", ""))
        return x

    def SfpDataRsp_fromDict(self, dict):
        x = transportprocctrl_service_pb2.SfpDataRsp()
        if not dict: return x
        getattr(x, "sfpData").CopyFrom(self.SfpData_fromDict(dict.get("sfpData")))
        return x

    def TransportProcCtrlIn_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TransportProcCtrlIn()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "setDlFilterReq").CopyFrom(self.SetDlFilterReq_fromDict(dict.get("setDlFilterReq")))
        getattr(x, "setUlRouterReq").CopyFrom(self.SetUlRouterReq_fromDict(dict.get("setUlRouterReq")))
        getattr(x, "setPortConfigReq").CopyFrom(self.SetPortConfigReq_fromDict(dict.get("setPortConfigReq")))
        getattr(x, "sfpReq").CopyFrom(self.SfpReq_fromDict(dict.get("sfpReq")))
        getattr(x, "sfpDataReq").CopyFrom(self.SfpDataReq_fromDict(dict.get("sfpDataReq")))
        getattr(x, "fhInterfacesReq").CopyFrom(self.FhInterfacesReq_fromDict(dict.get("fhInterfacesReq")))
        getattr(x, "transceiverStatsReq").CopyFrom(self.TransceiverStatsReq_fromDict(dict.get("transceiverStatsReq")))
        return x

    def TransportProcCtrlOut_fromDict(self, dict):
        x = transportprocctrl_service_pb2.TransportProcCtrlOut()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "setDlFilterRsp").CopyFrom(self.SetDlFilterRsp_fromDict(dict.get("setDlFilterRsp")))
        getattr(x, "setUlRouterRsp").CopyFrom(self.SetUlRouterRsp_fromDict(dict.get("setUlRouterRsp")))
        getattr(x, "setPortConfigRsp").CopyFrom(self.SetPortConfigRsp_fromDict(dict.get("setPortConfigRsp")))
        getattr(x, "sfpRsp").CopyFrom(self.SfpRsp_fromDict(dict.get("sfpRsp")))
        getattr(x, "sfpDataRsp").CopyFrom(self.SfpDataRsp_fromDict(dict.get("sfpDataRsp")))
        getattr(x, "fhInterfacesRsp").CopyFrom(self.FhInterfacesRsp_fromDict(dict.get("fhInterfacesRsp")))
        getattr(x, "transceiverStatsRsp").CopyFrom(self.TransceiverStatsRsp_fromDict(dict.get("transceiverStatsRsp")))
        return x

    def SetDlFilterReq_FilterConfig_toDict(self, v):
        dict = {}
        dict["ethernetInterface"] = getattr(v, "ethernetInterface")
        dict["planeType"] = getattr(v, "planeType")
        dict["changeIndicator"] = getattr(v, "changeIndicator")
        dict["vlanId"] = getattr(v, "vlanId")
        dict["ecpriMessage"] = getattr(v, "ecpriMessage")
        dict["srcMacAddr"] = getattr(v, "srcMacAddr")
        dict["destMacAddr"] = getattr(v, "destMacAddr")
        dict["ethType"] = getattr(v, "ethType")
        return dict

    def SetDlFilterReq_toDict(self, v):
        dict = {}
        dict["filterConfig"] = getattr(v, "filterConfig")
        return dict

    def SetDlFilterRsp_toDict(self, v):
        dict = {}
        dict["result"] = getattr(v, "result")
        return dict

    def SetUlRouterReq_toDict(self, v):
        dict = {}
        dict["ethernetInterface"] = getattr(v, "ethernetInterface")
        dict["srcMacAddr"] = getattr(v, "srcMacAddr")
        return dict

    def SetUlRouterRsp_toDict(self, v):
        dict = {}
        dict["result"] = getattr(v, "result")
        return dict

    def SetPortConfigReq_toDict(self, v):
        dict = {}
        dict["portChanges"] = []
        for x in getattr(v, "portChanges"):
            dict["portChanges"].append(self.PortChanges_toDict(x))
        return dict

    def PortChanges_toDict(self, v):
        dict = {}
        dict["staticLowLevelEndpointName"] = getattr(v, "staticLowLevelEndpointName")
        dict["changeIndicator"] = getattr(v, "changeIndicator")
        dict["srcMacId"] = getattr(v, "srcMacId")
        dict["vlanId"] = getattr(v, "vlanId")
        dict["destMacAddr"] = getattr(v, "destMacAddr")
        dict["duPort"] = getattr(v, "duPort")
        dict["bandSector"] = getattr(v, "bandSector")
        dict["ccid"] = getattr(v, "ccid")
        dict["ruPort"] = getattr(v, "ruPort")
        return dict

    def SetPortConfigRsp_toDict(self, v):
        dict = {}
        dict["errorOccurredDuringConfiguration"] = getattr(v, "errorOccurredDuringConfiguration")
        return dict

    def TransceiverStatsReq_toDict(self, v):
        dict = {}
        dict["measObj"] = getattr(v, "measObj")
        dict["valueType"] = getattr(v, "valueType")
        dict["valueScale"] = getattr(v, "valueScale")
        dict["precision"] = getattr(v, "precision")
        return dict

    def TransceiverStatsRsp_toDict(self, v):
        dict = {}
        return dict

    def RxPowerData_toDict(self, v):
        dict = {}
        dict["data"] = getattr(v, "data")
        dict["time"] = getattr(v, "time")
        return dict

    def TxPowerData_toDict(self, v):
        dict = {}
        dict["data"] = getattr(v, "data")
        dict["time"] = getattr(v, "time")
        return dict

    def TxBiasCount_toDict(self, v):
        dict = {}
        dict["data"] = getattr(v, "data")
        dict["time"] = getattr(v, "time")
        return dict

    def Voltage_toDict(self, v):
        dict = {}
        dict["data"] = getattr(v, "data")
        dict["time"] = getattr(v, "time")
        return dict

    def Temperature_toDict(self, v):
        dict = {}
        dict["data"] = getattr(v, "data")
        dict["time"] = getattr(v, "time")
        return dict

    def TransceiverData_toDict(self, v):
        dict = {}
        dict["portNum"] = getattr(v, "portNum")
        dict["rxPowerData"] = self.RxPowerData_toDict(getattr(v, "rxPowerData"))
        dict["txPowerData"] = self.TxPowerData_toDict(getattr(v, "txPowerData"))
        dict["txBiasCount"] = self.TxBiasCount_toDict(getattr(v, "txBiasCount"))
        dict["voltage"] = self.Voltage_toDict(getattr(v, "voltage"))
        dict["temperature"] = self.Temperature_toDict(getattr(v, "temperature"))
        return dict

    def SfpReq_toDict(self, v):
        dict = {}
        return dict

    def SfpRsp_Sfp_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        dict["interfaceName"] = getattr(v, "interfaceName")
        dict["portNumber"] = getattr(v, "portNumber")
        return dict

    def SfpRsp_toDict(self, v):
        dict = {}
        dict["sfps"] = getattr(v, "sfps")[:]
        return dict

    def FhInterfacesReq_toDict(self, v):
        dict = {}
        return dict

    def FhInterfacesRsp_Interface_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        dict["portName"] = getattr(v, "portName")
        dict["portNumber"] = getattr(v, "portNumber")
        return dict

    def FhInterfacesRsp_toDict(self, v):
        dict = {}
        dict["interfaces"] = getattr(v, "interfaces")[:]
        return dict

    def SfpDataReq_toDict(self, v):
        dict = {}
        dict["name"] = getattr(v, "name")
        return dict

    def SfpData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["present"] = getattr(v, "present")
        dict["vendorId"] = getattr(v, "vendorId")
        dict["vendorPart"] = getattr(v, "vendorPart")
        dict["vendorRev"] = getattr(v, "vendorRev")
        dict["serialNo"] = getattr(v, "serialNo")
        dict["SFF8472Compliance"] = getattr(v, "SFF8472Compliance")
        dict["connectorType"] = getattr(v, "connectorType")
        dict["identifier"] = getattr(v, "identifier")
        dict["nominalBitrate"] = getattr(v, "nominalBitrate")
        dict["lowBitrateMargin"] = getattr(v, "lowBitrateMargin")
        dict["highBitrateMargin"] = getattr(v, "highBitrateMargin")
        dict["rxPowerType"] = getattr(v, "rxPowerType")
        dict["rxPower"] = getattr(v, "rxPower")
        dict["txPower"] = getattr(v, "txPower")
        dict["txBiasCurrent"] = getattr(v, "txBiasCurrent")
        dict["voltage"] = getattr(v, "voltage")
        dict["temperature"] = getattr(v, "temperature")
        return dict

    def SfpDataRsp_toDict(self, v):
        dict = {}
        dict["sfpData"] = self.SfpData_toDict(getattr(v, "sfpData"))
        return dict

    def TransportProcCtrlIn_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["setDlFilterReq"] = self.SetDlFilterReq_toDict(getattr(v, "setDlFilterReq"))
        dict["setUlRouterReq"] = self.SetUlRouterReq_toDict(getattr(v, "setUlRouterReq"))
        dict["setPortConfigReq"] = self.SetPortConfigReq_toDict(getattr(v, "setPortConfigReq"))
        dict["sfpReq"] = self.SfpReq_toDict(getattr(v, "sfpReq"))
        dict["sfpDataReq"] = self.SfpDataReq_toDict(getattr(v, "sfpDataReq"))
        dict["fhInterfacesReq"] = self.FhInterfacesReq_toDict(getattr(v, "fhInterfacesReq"))
        dict["transceiverStatsReq"] = self.TransceiverStatsReq_toDict(getattr(v, "transceiverStatsReq"))
        return dict

    def TransportProcCtrlOut_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["setDlFilterRsp"] = self.SetDlFilterRsp_toDict(getattr(v, "setDlFilterRsp"))
        dict["setUlRouterRsp"] = self.SetUlRouterRsp_toDict(getattr(v, "setUlRouterRsp"))
        dict["setPortConfigRsp"] = self.SetPortConfigRsp_toDict(getattr(v, "setPortConfigRsp"))
        dict["sfpRsp"] = self.SfpRsp_toDict(getattr(v, "sfpRsp"))
        dict["sfpDataRsp"] = self.SfpDataRsp_toDict(getattr(v, "sfpDataRsp"))
        dict["fhInterfacesRsp"] = self.FhInterfacesRsp_toDict(getattr(v, "fhInterfacesRsp"))
        dict["transceiverStatsRsp"] = self.TransceiverStatsRsp_toDict(getattr(v, "transceiverStatsRsp"))
        return dict

    def SetDlFilter(self, filterConfig):
        _req = transportprocctrl_service_pb2.SetDlFilterReq()
        _req.filterConfig = filterConfig
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.setDlFilterReq.CopyFrom(_req)
        debug(_inMsg)

    def SetUlRouter(self, ethernetInterface, srcMacAddr):
        _req = transportprocctrl_service_pb2.SetUlRouterReq()
        _req.ethernetInterface = ethernetInterface
        _req.srcMacAddr = srcMacAddr
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.setUlRouterReq.CopyFrom(_req)
        debug(_inMsg)

    def SetPortConfig(self, portChanges):
        _req = transportprocctrl_service_pb2.SetPortConfigReq()
        for _x in portChanges:
            _req.portChanges.append(self.PortChanges_fromDict(_x))
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.setPortConfigReq.CopyFrom(_req)
        debug(_inMsg)

    def TransceiverStats(self, measObj, valueType, valueScale, precision):
        _req = transportprocctrl_service_pb2.TransceiverStatsReq()
        _req.measObj = measObj
        _req.valueType = valueType
        _req.valueScale = valueScale
        _req.precision = precision
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.transceiverStatsReq.CopyFrom(_req)
        debug(_inMsg)

    def Sfp(self):
        _req = transportprocctrl_service_pb2.SfpReq()
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.sfpReq.CopyFrom(_req)
        debug(_inMsg)

    def FhInterfaces(self):
        _req = transportprocctrl_service_pb2.FhInterfacesReq()
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.fhInterfacesReq.CopyFrom(_req)
        debug(_inMsg)

    def SfpData(self, name):
        _req = transportprocctrl_service_pb2.SfpDataReq()
        _req.name = name
        _inMsg = transportprocctrl_service_pb2.TransportProcCtrlIn()
        _inMsg.sfpDataReq.CopyFrom(_req)
        debug(_inMsg)

