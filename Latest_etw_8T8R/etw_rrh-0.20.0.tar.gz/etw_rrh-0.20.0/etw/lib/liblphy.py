from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import liblphy_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class liblphyProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwliblphy", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def returnStatusType_fromDict(self, dict):
        x = liblphy_pb2.returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", 0))
        return x

    def returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def LPhy_Init(self):
        _req = liblphy_pb2.LPhy_InitReq()
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.lPhy_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "lPhy_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("LPhy_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("LPhy_Init failed: no valid response found (lPhy_Init)")
        return self.returnStatusType_toDict(_rsp.lPhy_InitRsp._ret)

    def LPhy_Deinit(self):
        _req = liblphy_pb2.LPhy_DeinitReq()
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.lPhy_DeinitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "lPhy_DeinitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("LPhy_Deinit failed: " + _rsp.zzerr_msg)
            raise EtwError("LPhy_Deinit failed: no valid response found (lPhy_Deinit)")
        return self.returnStatusType_toDict(_rsp.lPhy_DeinitRsp._ret)

    def DL_LPhyInitialise(self, DlLowPhyIndex, beamformEnabled):
        _req = liblphy_pb2.DL_LPhyInitialiseReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.beamformEnabled = beamformEnabled
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhyInitialiseReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhyInitialiseRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhyInitialise failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhyInitialise failed: no valid response found (dL_LPhyInitialise)")
        return self.returnStatusType_toDict(_rsp.dL_LPhyInitialiseRsp._ret)

    def DL_LPhyEnableCC(self, DlLowPhyIndex, ccConfigIndex, oranCCID, ifftSizeCtrl, ccUramStartAddr, UPlaneDataStartAddr, numOfPrbs):
        _req = liblphy_pb2.DL_LPhyEnableCCReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.ccConfigIndex = ccConfigIndex
        _req.oranCCID = oranCCID
        _req.ifftSizeCtrl = ifftSizeCtrl
        _req.ccUramStartAddr = ccUramStartAddr
        _req.UPlaneDataStartAddr = UPlaneDataStartAddr
        _req.numOfPrbs = numOfPrbs
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhyEnableCCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhyEnableCCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhyEnableCC failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhyEnableCC failed: no valid response found (dL_LPhyEnableCC)")
        return self.returnStatusType_toDict(_rsp.dL_LPhyEnableCCRsp._ret)

    def UL_LPhySetLayer(self, UlLowPhyIndex, layerNumber, flag):
        _req = liblphy_pb2.UL_LPhySetLayerReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _req.layerNumber = layerNumber
        _req.flag = flag
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.uL_LPhySetLayerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "uL_LPhySetLayerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UL_LPhySetLayer failed: " + _rsp.zzerr_msg)
            raise EtwError("UL_LPhySetLayer failed: no valid response found (uL_LPhySetLayer)")

    def DL_LPhySetLTimeFlag(self, DlLowPhyIndex, lTimeEnable):
        _req = liblphy_pb2.DL_LPhySetLTimeFlagReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.lTimeEnable = lTimeEnable
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhySetLTimeFlagReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhySetLTimeFlagRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhySetLTimeFlag failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhySetLTimeFlag failed: no valid response found (dL_LPhySetLTimeFlag)")
        return self.returnStatusType_toDict(_rsp.dL_LPhySetLTimeFlagRsp._ret)

    def DL_LPhySetLayer(self, DlLowPhyIndex, layerNumber, flag):
        _req = liblphy_pb2.DL_LPhySetLayerReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.layerNumber = layerNumber
        _req.flag = flag
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhySetLayerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhySetLayerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhySetLayer failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhySetLayer failed: no valid response found (dL_LPhySetLayer)")

    def DL_LPhySetNumerology(self, DlLowPhyIndex, SCS, ExtendedCp):
        _req = liblphy_pb2.DL_LPhySetNumerologyReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.SCS = SCS
        _req.ExtendedCp = ExtendedCp
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhySetNumerologyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhySetNumerologyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhySetNumerology failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhySetNumerology failed: no valid response found (dL_LPhySetNumerology)")
        return self.returnStatusType_toDict(_rsp.dL_LPhySetNumerologyRsp._ret)

    def DL_LPhyDisableCC(self, DlLowPhyIndex, ccConfigIndex):
        _req = liblphy_pb2.DL_LPhyDisableCCReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.ccConfigIndex = ccConfigIndex
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhyDisableCCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhyDisableCCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhyDisableCC failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhyDisableCC failed: no valid response found (dL_LPhyDisableCC)")
        return self.returnStatusType_toDict(_rsp.dL_LPhyDisableCCRsp._ret)

    def DlLowPhyLoadUPlaneStart(self, DlLowPhyIndex):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneStartReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneStartReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneStartRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneStart failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneStart failed: no valid response found (dlLowPhyLoadUPlaneStart)")

    def DlLowPhyLoadUPlaneEnd(self, DlLowPhyIndex):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneEndReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneEndReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneEndRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneEnd failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneEnd failed: no valid response found (dlLowPhyLoadUPlaneEnd)")

    def DlLowPhyLoadUPlaneDataWord(self, DlLowPhyIndex, UPlaneDataStartAddr, reNumber, ReDataI, ReDataQ):
        _req = liblphy_pb2.DlLowPhyLoadUPlaneDataWordReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.UPlaneDataStartAddr = UPlaneDataStartAddr
        _req.reNumber = reNumber
        _req.ReDataI = ReDataI
        _req.ReDataQ = ReDataQ
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dlLowPhyLoadUPlaneDataWordReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dlLowPhyLoadUPlaneDataWordRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DlLowPhyLoadUPlaneDataWord failed: " + _rsp.zzerr_msg)
            raise EtwError("DlLowPhyLoadUPlaneDataWord failed: no valid response found (dlLowPhyLoadUPlaneDataWord)")

    def DL_LPhyGetUPlaneDataStartAddr(self, DlLowPhyIndex, CCID):
        _req = liblphy_pb2.DL_LPhyGetUPlaneDataStartAddrReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.CCID = CCID
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhyGetUPlaneDataStartAddrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhyGetUPlaneDataStartAddrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhyGetUPlaneDataStartAddr failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhyGetUPlaneDataStartAddr failed: no valid response found (dL_LPhyGetUPlaneDataStartAddr)")
        return _rsp.dL_LPhyGetUPlaneDataStartAddrRsp._ret

    def DL_LPhyUpdateCcSequence(self, DlLowPhyIndex, ccSequenceID, ccSequenceOffset):
        _req = liblphy_pb2.DL_LPhyUpdateCcSequenceReq()
        _req.DlLowPhyIndex = DlLowPhyIndex
        _req.ccSequenceID = ccSequenceID
        _req.ccSequenceOffset = ccSequenceOffset
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.dL_LPhyUpdateCcSequenceReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "dL_LPhyUpdateCcSequenceRsp":
            if _rsp.zzerr_msg:
                raise EtwError("DL_LPhyUpdateCcSequence failed: " + _rsp.zzerr_msg)
            raise EtwError("DL_LPhyUpdateCcSequence failed: no valid response found (dL_LPhyUpdateCcSequence)")
        return self.returnStatusType_toDict(_rsp.dL_LPhyUpdateCcSequenceRsp._ret)

    def UL_LPhyInitialise(self, UlLowPhyIndex):
        _req = liblphy_pb2.UL_LPhyInitialiseReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.uL_LPhyInitialiseReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "uL_LPhyInitialiseRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UL_LPhyInitialise failed: " + _rsp.zzerr_msg)
            raise EtwError("UL_LPhyInitialise failed: no valid response found (uL_LPhyInitialise)")
        return self.returnStatusType_toDict(_rsp.uL_LPhyInitialiseRsp._ret)

    def UL_LPhyEnableCC(self, UlLowPhyIndex, ccConfigIndex, oranCCID, FftSize, UramStartAddr, UramEndAddr, numOfPrbs):
        _req = liblphy_pb2.UL_LPhyEnableCCReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _req.ccConfigIndex = ccConfigIndex
        _req.oranCCID = oranCCID
        _req.FftSize = FftSize
        _req.UramStartAddr = UramStartAddr
        _req.UramEndAddr = UramEndAddr
        _req.numOfPrbs = numOfPrbs
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.uL_LPhyEnableCCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "uL_LPhyEnableCCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UL_LPhyEnableCC failed: " + _rsp.zzerr_msg)
            raise EtwError("UL_LPhyEnableCC failed: no valid response found (uL_LPhyEnableCC)")
        return self.returnStatusType_toDict(_rsp.uL_LPhyEnableCCRsp._ret)

    def UL_LPhySetLTimeFlag(self, UlLowPhyIndex, lTimeEnable):
        _req = liblphy_pb2.UL_LPhySetLTimeFlagReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _req.lTimeEnable = lTimeEnable
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.uL_LPhySetLTimeFlagReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "uL_LPhySetLTimeFlagRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UL_LPhySetLTimeFlag failed: " + _rsp.zzerr_msg)
            raise EtwError("UL_LPhySetLTimeFlag failed: no valid response found (uL_LPhySetLTimeFlag)")
        return self.returnStatusType_toDict(_rsp.uL_LPhySetLTimeFlagRsp._ret)

    def UlLowPhySetNumerology(self, UlLowPhyIndex, SCS, extendedCp):
        _req = liblphy_pb2.UlLowPhySetNumerologyReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _req.SCS = SCS
        _req.extendedCp = extendedCp
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.ulLowPhySetNumerologyReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "ulLowPhySetNumerologyRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UlLowPhySetNumerology failed: " + _rsp.zzerr_msg)
            raise EtwError("UlLowPhySetNumerology failed: no valid response found (ulLowPhySetNumerology)")
        return self.returnStatusType_toDict(_rsp.ulLowPhySetNumerologyRsp._ret)

    def UL_LPhyDisableCC(self, UlLowPhyIndex, ccConfigIndex):
        _req = liblphy_pb2.UL_LPhyDisableCCReq()
        _req.UlLowPhyIndex = UlLowPhyIndex
        _req.ccConfigIndex = ccConfigIndex
        _inMsg = liblphy_pb2.liblphyIn()
        _inMsg.uL_LPhyDisableCCReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, liblphy_pb2.liblphyOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "uL_LPhyDisableCCRsp":
            if _rsp.zzerr_msg:
                raise EtwError("UL_LPhyDisableCC failed: " + _rsp.zzerr_msg)
            raise EtwError("UL_LPhyDisableCC failed: no valid response found (uL_LPhyDisableCC)")
        return self.returnStatusType_toDict(_rsp.uL_LPhyDisableCCRsp._ret)

