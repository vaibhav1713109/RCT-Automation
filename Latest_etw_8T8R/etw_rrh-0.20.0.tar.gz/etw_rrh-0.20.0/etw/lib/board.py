from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import board_pb2

debug_on = 0

def debug(msg):
    if debug_on: print(msg.__str__())

class BoardProxy():
    def __init__(self, etwProxy = None, target = None):
        if etwProxy:
            self.__etwProxy = etwProxy
        elif target is None:
            self.__etwProxy = self
        else:
            self.__etwProxy = EtwProxy(target.ip_address, target.port)
        self.__gw = DBusGwProxy(self.__etwProxy.ipc_link, proto_name = 'etwboard')

    def connect(self):
        self.__gw.connect()

    def disconnect(self):
        self.__gw.disconnect()

    def cold_reset(self):
        raise EtwError("cold_reset not implemented")

    def power_cycle_reset(self):
        raise EtwError("power_cycle_reset not implemented")

    def reboot(self):
        exit_code, output = self.__etwProxy.execCmd("echo 'Rebooting...'; (sleep 3; reboot) >&- &", "")
        return output

    ## Get temp sensor info
    def getTempSensorInfo(self):
        req = board_pb2.GetTempSensorInfoReq()
        boardIn = board_pb2.BoardIn();
        boardIn.getTempSensorInfoReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getTempSensorInfoRsp:
            raise EtwError("getTempSensorInfo failed: " + rsp.err_msg)
        if not rsp.getTempSensorInfoRsp.ok:
            raise EtwError("getTempSensorInfo failed: " + rsp.getTempSensorInfoRsp.err_msg)
        return rsp.getTempSensorInfoRsp.temp_sensors

    ## Get temp sensor info
    def setTempSensorLimits(self, sensor_name, high_limit=80.0, low_limit=75.0):
        req = board_pb2.SetTempSensorLimitsReq()
        req.sensor_name = sensor_name
        req.high_limit = high_limit
        req.low_limit = low_limit
        boardIn = board_pb2.BoardIn();
        boardIn.setTempSensorLimitsReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setTempSensorLimitsRsp:
            raise EtwError("setTempSensorLimits failed: " + rsp.err_msg)
        if not rsp.setTempSensorLimitsRsp.ok:
            raise EtwError("setTempSensorLimits failed: " + rsp.setTempSensorLimitsRsp.err_msg)

    def getSfpInfo(self):
        req = board_pb2.GetSfpInfoReq()
        boardIn = board_pb2.BoardIn();
        boardIn.getSfpInfoReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getSfpInfoRsp:
            raise EtwError("getSfpInfo failed: " + rsp.err_msg)
        if not rsp.getSfpInfoRsp.ok:
            raise EtwError("getSfpInfo failed: " + rsp.getSfpInfoRsp.err_msg)
        return rsp.getSfpInfoRsp.sfp_modules

    def getAttenuation(self, attenuator_id):
        req = board_pb2.GetAttenuationReq()
        req.attenuator_id = attenuator_id
        boardIn = board_pb2.BoardIn();
        boardIn.getAttenuationReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getAttenuationRsp:
            raise EtwError("getAttenuation failed: " + rsp.err_msg)
        if not rsp.getAttenuationRsp.ok:
            raise EtwError("getAttenuation failed: " + rsp.getAttenuationRsp.err_msg)
        return rsp.getAttenuationRsp.attenuation

    def setAttenuation(self, attenuator_id, attenuation):
        req = board_pb2.SetAttenuationReq()
        req.attenuator_id = attenuator_id
        req.attenuation = attenuation
        boardIn = board_pb2.BoardIn();
        boardIn.setAttenuationReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setAttenuationRsp:
            raise EtwError("setAttenuation failed: " + rsp.err_msg)
        if not rsp.setAttenuationRsp.ok:
            raise EtwError("setAttenuation failed: " + rsp.setAttenuationRsp.err_msg)

    def getPsuInfo(self):
        req = board_pb2.GetPsuInfoReq()
        boardIn = board_pb2.BoardIn();
        boardIn.getPsuInfoReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getPsuInfoRsp:
            raise EtwError("getPsuInfo failed: " + rsp.err_msg)
        if not rsp.getPsuInfoRsp.ok:
            raise EtwError("getPsuInfo failed: " + rsp.getPsuInfoRsp.err_msg)
        return rsp.getPsuInfoRsp.psu_info
        
    def setPsuLimits(self, vin_high_limit, vin_low_limit, vout_low_limit, iin_high_limit, temp_warn_limit = 125.0, temp_fault_limit = 150.0):
        req = board_pb2.SetPsuLimitsReq()
        req.vin_high_limit = vin_high_limit
        req.vout_low_limit = vout_low_limit
        req.vin_low_limit = vin_low_limit
        req.iin_high_limit = iin_high_limit
        req.over_temp_warn_limit = temp_warn_limit
        req.over_temp_fault_limit = temp_fault_limit
        boardIn = board_pb2.BoardIn();
        boardIn.setPsuLimitsReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setPsuLimitsRsp:
            raise EtwError("setPsuLimits failed: " + rsp.err_msg)
        if not rsp.setPsuLimitsRsp.ok:
            raise EtwError("setPsuLimits failed: " + rsp.setPsuLimitsRsp.err_msg)

    def setPsuSenseResistance(self, resistance):
        req = board_pb2.SetPsuSenseResistanceReq()
        req.resistance = resistance
        boardIn = board_pb2.BoardIn();
        boardIn.setPsuSenseResistanceReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setPsuSenseResistanceRsp:
            raise EtwError("setPsuSenseResistance failed: " + rsp.err_msg)
        if not rsp.setPsuSenseResistanceRsp.ok:
            raise EtwError("setPsuSenseResistance failed: " + rsp.setPsuSenseResistanceRsp.err_msg)

    def clearPsuFaults(self):
        req = board_pb2.ClearPsuFaultsReq()
        boardIn = board_pb2.BoardIn();
        boardIn.clearPsuFaultsReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.clearPsuFaultsRsp:
            raise EtwError("clearPsuFaults failed: " + rsp.err_msg)
        if not rsp.clearPsuFaultsRsp.ok:
            raise EtwError("clearPsuFaults failed: " + rsp.clearPsuFaultsRsp.err_msg)

    def getSwStatus(self):
        req = board_pb2.GetSwStatusReq()
        boardIn = board_pb2.BoardIn();
        boardIn.getSwStatusReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getSwStatusRsp:
            raise EtwError("getSwStatus failed: " + rsp.err_msg)
        if not rsp.getSwStatusRsp.ok:
            raise EtwError("getSwStatus failed: " + rsp.getSwStatusRsp.err_msg)
        return rsp.getSwStatusRsp.sw_status
        
    def updateSwImage(self, image_id, filename):
        req = board_pb2.UpdateSwImageReq()
        req.image_num = image_id
        req.filename = filename
        boardIn = board_pb2.BoardIn()
        boardIn.updateSwImageReq.CopyFrom(req)
        debug(boardIn)
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp)
        if not rsp.updateSwImageRsp:
            raise EtwError(f"updateSwImage failed: {rsp.err_msg}")
        if not rsp.updateSwImageRsp.ok:
            raise EtwError(f"updateSwImage failed: {rsp.updateSwImageRsp.err_msg}")

    def setSwImageStatus(self, image_id, status):
        req = board_pb2.SetSwImageStatusReq()
        req.image_id = image_id
        if status == 'invalid':
            req.status = board_pb2.SwImage_INVALID
        elif status == 'unverified':
            req.status = board_pb2.SwImage_UNVERIFIED
        elif status == 'verified':
            req.status = board_pb2.SwImage_VERIFIED
        elif status == 'failed':
            req.status = board_pb2.SwImage_FAILED
        else:
            req.status = status
        boardIn = board_pb2.BoardIn();
        boardIn.setSwImageStatusReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setSwImageStatusRsp:
            raise EtwError("setSwImageStatus failed: " + rsp.err_msg)
        if not rsp.setSwImageStatusRsp.ok:
            raise EtwError("setSwImageStatus failed: " + rsp.setSwImageStatusRsp.err_msg)
        
    def setActiveSwImageIndex(self, image_id):
        req = board_pb2.SetActiveSwImageIndexReq()
        req.image_id = image_id
        boardIn = board_pb2.BoardIn();
        boardIn.setActiveSwImageIndexReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setActiveSwImageIndexRsp:
            raise EtwError("setActiveSwImageIndex failed: " + rsp.err_msg)
        if not rsp.setActiveSwImageIndexRsp.ok:
            raise EtwError("setActiveSwImageIndex failed: " + rsp.setActiveSwImageIndexRsp.err_msg)
        
    def getSwImageTag(self, image_id):
        req = board_pb2.GetSwImageTagReq()
        req.image_id = image_id
        boardIn = board_pb2.BoardIn();
        boardIn.getSwImageTagReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getSwImageTagRsp:
            raise EtwError("getSwImageTag failed: " + rsp.err_msg)
        if not rsp.getSwImageTagRsp.ok:
            raise EtwError("getSwImageTag failed: " + rsp.getSwImageTagRsp.err_msg)
        
    def setActiveSwImageVersion(self, version):
        req = board_pb2.SetActiveSwImageVersionReq()
        req.version = version
        boardIn = board_pb2.BoardIn();
        boardIn.setActiveSwImageVersionReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setActiveSwImageVersionRsp:
            raise EtwError("setActiveSwImageVersion failed: " + rsp.err_msg)
        if not rsp.setActiveSwImageVersionRsp.ok:
            raise EtwError("setActiveSwImageVersion failed: " + rsp.setActiveSwImageVersionRsp.err_msg)

    def getLedState(self):
        req = board_pb2.GetLedStateReq()
        boardIn = board_pb2.BoardIn();
        boardIn.getLedStateReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.getLedStateRsp:
            raise EtwError("getLedState failed: " + rsp.err_msg)
        if not rsp.getLedStateRsp.ok:
            raise EtwError("getLedState failed: " + rsp.getLedStateRsp.err_msg)
        return rsp.getLedStateRsp.led_state

    def setLedState(self, led_name, color, freq = 0.0, duty_cycle = 100):
        req = board_pb2.SetLedStateReq()
        state = board_pb2.LedState()
        state.led_id = led_name
        state.color = color
        state.freq = freq
        state.duty_cycle = duty_cycle
        req.led_state.CopyFrom(state) 
        boardIn = board_pb2.BoardIn();
        boardIn.setLedStateReq.CopyFrom(req)
        debug(boardIn) 
        rsp = self.__gw.methodCall(boardIn, board_pb2.BoardOut)
        debug(rsp) 
        if not rsp.setLedStateRsp:
            raise EtwError("setLedState failed: " + rsp.err_msg)
        if not rsp.setLedStateRsp.ok:
            raise EtwError("setLedState failed: " + rsp.setLedStateRsp.err_msg)

