from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import syncprocctrl_service_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class syncprocctrl_serviceProxy:
    def __init__(self, ipcLink, service_name = "syncprocctrl"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "syncprocctrl", method_call="Method")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def GetTimeInfoReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.GetTimeInfoReq()
        if not dict: return x
        return x

    def GetTimeInfoRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.GetTimeInfoRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "syncState", dict.get("syncState", 0))
        return x

    def SyncRefTypesReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncRefTypesReq()
        if not dict: return x
        return x

    def SyncRefTypesRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncRefTypesRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        for v in dict.get("supportedRefTypes", []):
            getattr(x, "supportedRefTypes").append(v)
        return x

    def SyncCapabilityReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncCapabilityReq()
        if not dict: return x
        return x

    def SyncCapabilityRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncCapabilityRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "syncTTsc", dict.get("syncTTsc", 0))
        return x

    def SyncEGetInitCfgReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEGetInitCfgReq()
        if not dict: return x
        return x

    def SyncEGetInitCfgRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEGetInitCfgRsp()
        if not dict: return x
        getattr(x, "syncConfData").CopyFrom(self.SyncEConfigData_fromDict(dict.get("syncConfData")))
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def SyncEConfigData_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEConfigData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        for v in dict.get("listSsm", []):
            getattr(x, "listSsm").append(v)
        setattr(x, "ssmTimeout", dict.get("ssmTimeout", 0))
        setattr(x, "reportingPeriod", dict.get("reportingPeriod", 0))
        return x

    def SyncEStatusReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEStatusReq()
        if not dict: return x
        return x

    def SyncEStatusRsp_SourceData_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEStatusRsp_SourceData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "localPortNumber", dict.get("localPortNumber", 0))
        setattr(x, "state", dict.get("state", 0))
        setattr(x, "qualityLevel", dict.get("qualityLevel", 0))
        return x

    def SyncEStatusRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEStatusRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "lockState", dict.get("lockState", 0))
        for v in dict.get("sources", []):
            getattr(x, "sources").append(v)
        return x

    def SyncEConfigValidateReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEConfigValidateReq()
        if not dict: return x
        getattr(x, "syncEConfigData").CopyFrom(self.SyncEConfigData_fromDict(dict.get("syncEConfigData")))
        return x

    def SyncEConfigValidateRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEConfigValidateRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def SyncEConfigApplyReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEConfigApplyReq()
        if not dict: return x
        getattr(x, "syncEConfigData").CopyFrom(self.SyncEConfigData_fromDict(dict.get("syncEConfigData")))
        return x

    def SyncEConfigApplyRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncEConfigApplyRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        return x

    def PtpStatusReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpStatusReq()
        if not dict: return x
        return x

    def PtpStatusRsp_PtpStatusData_SourceData_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpStatusRsp_PtpStatusData_SourceData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "localPortNumber", dict.get("localPortNumber", 0))
        setattr(x, "state", dict.get("state", 0))
        setattr(x, "twoStepFlag", dict.get("twoStepFlag", 0))
        setattr(x, "leap61", dict.get("leap61", 0))
        setattr(x, "leap59", dict.get("leap59", 0))
        setattr(x, "currentUtcOffsetValid", dict.get("currentUtcOffsetValid", 0))
        setattr(x, "ptpTimescale", dict.get("ptpTimescale", 0))
        setattr(x, "timeTraceable", dict.get("timeTraceable", 0))
        setattr(x, "frequencyTraceable", dict.get("frequencyTraceable", 0))
        setattr(x, "sourceClockIdentity", dict.get("sourceClockIdentity", ""))
        setattr(x, "sourcePortNumber", dict.get("sourcePortNumber", 0))
        setattr(x, "currentUtcOffset", dict.get("currentUtcOffset", 0))
        setattr(x, "priority1", dict.get("priority1", 0))
        setattr(x, "clockClass", dict.get("clockClass", 0))
        setattr(x, "clockAccuracy", dict.get("clockAccuracy", 0))
        setattr(x, "offsetScaledLogVariance", dict.get("offsetScaledLogVariance", 0))
        setattr(x, "priority2", dict.get("priority2", 0))
        setattr(x, "grandmasterClockIdentity", dict.get("grandmasterClockIdentity", ""))
        setattr(x, "stepsRemoved", dict.get("stepsRemoved", 0))
        setattr(x, "timeSource", dict.get("timeSource", 0))
        return x

    def PtpStatusRsp_PtpStatusData_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpStatusRsp_PtpStatusData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "lockState", dict.get("lockState", 0))
        setattr(x, "clockClass", dict.get("clockClass", 0))
        setattr(x, "clockIdentity", dict.get("clockIdentity", ""))
        setattr(x, "partialTimingSupported", dict.get("partialTimingSupported", 0))
        for v in dict.get("sources", []):
            getattr(x, "sources").append(v)
        return x

    def PtpStatusRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpStatusRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "ptpStatusData", dict.get("ptpStatusData", 0))
        return x

    def PtpConfigData_MasterIpConfiguration_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigData_MasterIpConfiguration()
        if not dict: return x
        setattr(x, "localPriority", dict.get("localPriority", 0))
        setattr(x, "ipAddress", dict.get("ipAddress", ""))
        return x

    def PtpConfigData_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigData()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "domainNumber", dict.get("domainNumber", 0))
        for v in dict.get("clockClasses", []):
            getattr(x, "clockClasses").append(v)
        setattr(x, "ptpProfile", dict.get("ptpProfile", 0))
        setattr(x, "multicastMacAddress", dict.get("multicastMacAddress", 0))
        setattr(x, "delayAsymmetry", dict.get("delayAsymmetry", 0))
        setattr(x, "localIpPort", dict.get("localIpPort", ""))
        for v in dict.get("masterIpConfiguration", []):
            getattr(x, "masterIpConfiguration").append(v)
        setattr(x, "logInterSyncPeriod", dict.get("logInterSyncPeriod", 0))
        setattr(x, "logInterAnnouncePeriod", dict.get("logInterAnnouncePeriod", 0))
        setattr(x, "reportingPeriod", dict.get("reportingPeriod", 0))
        return x

    def PtpConfigValidateReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigValidateReq()
        if not dict: return x
        getattr(x, "ptpConfigData").CopyFrom(self.PtpConfigData_fromDict(dict.get("ptpConfigData")))
        return x

    def PtpConfigValidateRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigValidateRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def PtpConfigApplyReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigApplyReq()
        if not dict: return x
        getattr(x, "ptpConfigData").CopyFrom(self.PtpConfigData_fromDict(dict.get("ptpConfigData")))
        return x

    def PtpConfigApplyRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpConfigApplyRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def PtpInitCfgReq_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpInitCfgReq()
        if not dict: return x
        return x

    def PtpInitCfgRsp_fromDict(self, dict):
        x = syncprocctrl_service_pb2.PtpInitCfgRsp()
        if not dict: return x
        getattr(x, "ptpConfigData").CopyFrom(self.PtpConfigData_fromDict(dict.get("ptpConfigData")))
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def SyncProcCtrlIn_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncProcCtrlIn()
        if not dict: return x
        getattr(x, "getTimeInfoReq").CopyFrom(self.GetTimeInfoReq_fromDict(dict.get("getTimeInfoReq")))
        getattr(x, "syncRefTypesReq").CopyFrom(self.SyncRefTypesReq_fromDict(dict.get("syncRefTypesReq")))
        getattr(x, "syncCapabilityReq").CopyFrom(self.SyncCapabilityReq_fromDict(dict.get("syncCapabilityReq")))
        getattr(x, "syncEGetInitCfgReq").CopyFrom(self.SyncEGetInitCfgReq_fromDict(dict.get("syncEGetInitCfgReq")))
        getattr(x, "syncEStatusReq").CopyFrom(self.SyncEStatusReq_fromDict(dict.get("syncEStatusReq")))
        getattr(x, "syncEConfigValidateReq").CopyFrom(self.SyncEConfigValidateReq_fromDict(dict.get("syncEConfigValidateReq")))
        getattr(x, "syncEConfigApplyReq").CopyFrom(self.SyncEConfigApplyReq_fromDict(dict.get("syncEConfigApplyReq")))
        getattr(x, "ptpStatusReq").CopyFrom(self.PtpStatusReq_fromDict(dict.get("ptpStatusReq")))
        getattr(x, "ptpConfigValidateReq").CopyFrom(self.PtpConfigValidateReq_fromDict(dict.get("ptpConfigValidateReq")))
        getattr(x, "ptpConfigApplyReq").CopyFrom(self.PtpConfigApplyReq_fromDict(dict.get("ptpConfigApplyReq")))
        getattr(x, "ptpInitCfgReq").CopyFrom(self.PtpInitCfgReq_fromDict(dict.get("ptpInitCfgReq")))
        return x

    def SyncProcCtrlOut_fromDict(self, dict):
        x = syncprocctrl_service_pb2.SyncProcCtrlOut()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "getTimeInfoRsp").CopyFrom(self.GetTimeInfoRsp_fromDict(dict.get("getTimeInfoRsp")))
        getattr(x, "syncRefTypesRsp").CopyFrom(self.SyncRefTypesRsp_fromDict(dict.get("syncRefTypesRsp")))
        getattr(x, "syncCapabilityRsp").CopyFrom(self.SyncCapabilityRsp_fromDict(dict.get("syncCapabilityRsp")))
        getattr(x, "syncEGetInitCfgRsp").CopyFrom(self.SyncEGetInitCfgRsp_fromDict(dict.get("syncEGetInitCfgRsp")))
        getattr(x, "syncEStatusRsp").CopyFrom(self.SyncEStatusRsp_fromDict(dict.get("syncEStatusRsp")))
        getattr(x, "syncEConfigValidateRsp").CopyFrom(self.SyncEConfigValidateRsp_fromDict(dict.get("syncEConfigValidateRsp")))
        getattr(x, "syncEConfigApplyRsp").CopyFrom(self.SyncEConfigApplyRsp_fromDict(dict.get("syncEConfigApplyRsp")))
        getattr(x, "ptpStatusRsp").CopyFrom(self.PtpStatusRsp_fromDict(dict.get("ptpStatusRsp")))
        getattr(x, "ptpConfigValidateRsp").CopyFrom(self.PtpConfigValidateRsp_fromDict(dict.get("ptpConfigValidateRsp")))
        getattr(x, "ptpConfigApplyRsp").CopyFrom(self.PtpConfigApplyRsp_fromDict(dict.get("ptpConfigApplyRsp")))
        getattr(x, "ptpInitCfgRsp").CopyFrom(self.PtpInitCfgRsp_fromDict(dict.get("ptpInitCfgRsp")))
        return x

    def GetTimeInfoReq_toDict(self, v):
        dict = {}
        return dict

    def GetTimeInfoRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["syncState"] = getattr(v, "syncState")
        return dict

    def SyncRefTypesReq_toDict(self, v):
        dict = {}
        return dict

    def SyncRefTypesRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["supportedRefTypes"] = getattr(v, "supportedRefTypes")[:]
        return dict

    def SyncCapabilityReq_toDict(self, v):
        dict = {}
        return dict

    def SyncCapabilityRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["syncTTsc"] = getattr(v, "syncTTsc")
        return dict

    def SyncEGetInitCfgReq_toDict(self, v):
        dict = {}
        return dict

    def SyncEGetInitCfgRsp_toDict(self, v):
        dict = {}
        dict["syncConfData"] = self.SyncEConfigData_toDict(getattr(v, "syncConfData"))
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def SyncEConfigData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["listSsm"] = getattr(v, "listSsm")[:]
        dict["ssmTimeout"] = getattr(v, "ssmTimeout")
        dict["reportingPeriod"] = getattr(v, "reportingPeriod")
        return dict

    def SyncEStatusReq_toDict(self, v):
        dict = {}
        return dict

    def SyncEStatusRsp_SourceData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["localPortNumber"] = getattr(v, "localPortNumber")
        dict["state"] = getattr(v, "state")
        dict["qualityLevel"] = getattr(v, "qualityLevel")
        return dict

    def SyncEStatusRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["lockState"] = getattr(v, "lockState")
        dict["sources"] = getattr(v, "sources")[:]
        return dict

    def SyncEConfigValidateReq_toDict(self, v):
        dict = {}
        dict["syncEConfigData"] = self.SyncEConfigData_toDict(getattr(v, "syncEConfigData"))
        return dict

    def SyncEConfigValidateRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def SyncEConfigApplyReq_toDict(self, v):
        dict = {}
        dict["syncEConfigData"] = self.SyncEConfigData_toDict(getattr(v, "syncEConfigData"))
        return dict

    def SyncEConfigApplyRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        return dict

    def PtpStatusReq_toDict(self, v):
        dict = {}
        return dict

    def PtpStatusRsp_PtpStatusData_SourceData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["localPortNumber"] = getattr(v, "localPortNumber")
        dict["state"] = getattr(v, "state")
        dict["twoStepFlag"] = getattr(v, "twoStepFlag")
        dict["leap61"] = getattr(v, "leap61")
        dict["leap59"] = getattr(v, "leap59")
        dict["currentUtcOffsetValid"] = getattr(v, "currentUtcOffsetValid")
        dict["ptpTimescale"] = getattr(v, "ptpTimescale")
        dict["timeTraceable"] = getattr(v, "timeTraceable")
        dict["frequencyTraceable"] = getattr(v, "frequencyTraceable")
        dict["sourceClockIdentity"] = getattr(v, "sourceClockIdentity")
        dict["sourcePortNumber"] = getattr(v, "sourcePortNumber")
        dict["currentUtcOffset"] = getattr(v, "currentUtcOffset")
        dict["priority1"] = getattr(v, "priority1")
        dict["clockClass"] = getattr(v, "clockClass")
        dict["clockAccuracy"] = getattr(v, "clockAccuracy")
        dict["offsetScaledLogVariance"] = getattr(v, "offsetScaledLogVariance")
        dict["priority2"] = getattr(v, "priority2")
        dict["grandmasterClockIdentity"] = getattr(v, "grandmasterClockIdentity")
        dict["stepsRemoved"] = getattr(v, "stepsRemoved")
        dict["timeSource"] = getattr(v, "timeSource")
        return dict

    def PtpStatusRsp_PtpStatusData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["lockState"] = getattr(v, "lockState")
        dict["clockClass"] = getattr(v, "clockClass")
        dict["clockIdentity"] = getattr(v, "clockIdentity")
        dict["partialTimingSupported"] = getattr(v, "partialTimingSupported")
        dict["sources"] = getattr(v, "sources")[:]
        return dict

    def PtpStatusRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["ptpStatusData"] = getattr(v, "ptpStatusData")
        return dict

    def PtpConfigData_MasterIpConfiguration_toDict(self, v):
        dict = {}
        dict["localPriority"] = getattr(v, "localPriority")
        dict["ipAddress"] = getattr(v, "ipAddress")
        return dict

    def PtpConfigData_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["domainNumber"] = getattr(v, "domainNumber")
        dict["clockClasses"] = getattr(v, "clockClasses")[:]
        dict["ptpProfile"] = getattr(v, "ptpProfile")
        dict["multicastMacAddress"] = getattr(v, "multicastMacAddress")
        dict["delayAsymmetry"] = getattr(v, "delayAsymmetry")
        dict["localIpPort"] = getattr(v, "localIpPort")
        dict["masterIpConfiguration"] = getattr(v, "masterIpConfiguration")[:]
        dict["logInterSyncPeriod"] = getattr(v, "logInterSyncPeriod")
        dict["logInterAnnouncePeriod"] = getattr(v, "logInterAnnouncePeriod")
        dict["reportingPeriod"] = getattr(v, "reportingPeriod")
        return dict

    def PtpConfigValidateReq_toDict(self, v):
        dict = {}
        dict["ptpConfigData"] = self.PtpConfigData_toDict(getattr(v, "ptpConfigData"))
        return dict

    def PtpConfigValidateRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def PtpConfigApplyReq_toDict(self, v):
        dict = {}
        dict["ptpConfigData"] = self.PtpConfigData_toDict(getattr(v, "ptpConfigData"))
        return dict

    def PtpConfigApplyRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def PtpInitCfgReq_toDict(self, v):
        dict = {}
        return dict

    def PtpInitCfgRsp_toDict(self, v):
        dict = {}
        dict["ptpConfigData"] = self.PtpConfigData_toDict(getattr(v, "ptpConfigData"))
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def SyncProcCtrlIn_toDict(self, v):
        dict = {}
        dict["getTimeInfoReq"] = self.GetTimeInfoReq_toDict(getattr(v, "getTimeInfoReq"))
        dict["syncRefTypesReq"] = self.SyncRefTypesReq_toDict(getattr(v, "syncRefTypesReq"))
        dict["syncCapabilityReq"] = self.SyncCapabilityReq_toDict(getattr(v, "syncCapabilityReq"))
        dict["syncEGetInitCfgReq"] = self.SyncEGetInitCfgReq_toDict(getattr(v, "syncEGetInitCfgReq"))
        dict["syncEStatusReq"] = self.SyncEStatusReq_toDict(getattr(v, "syncEStatusReq"))
        dict["syncEConfigValidateReq"] = self.SyncEConfigValidateReq_toDict(getattr(v, "syncEConfigValidateReq"))
        dict["syncEConfigApplyReq"] = self.SyncEConfigApplyReq_toDict(getattr(v, "syncEConfigApplyReq"))
        dict["ptpStatusReq"] = self.PtpStatusReq_toDict(getattr(v, "ptpStatusReq"))
        dict["ptpConfigValidateReq"] = self.PtpConfigValidateReq_toDict(getattr(v, "ptpConfigValidateReq"))
        dict["ptpConfigApplyReq"] = self.PtpConfigApplyReq_toDict(getattr(v, "ptpConfigApplyReq"))
        dict["ptpInitCfgReq"] = self.PtpInitCfgReq_toDict(getattr(v, "ptpInitCfgReq"))
        return dict

    def SyncProcCtrlOut_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["getTimeInfoRsp"] = self.GetTimeInfoRsp_toDict(getattr(v, "getTimeInfoRsp"))
        dict["syncRefTypesRsp"] = self.SyncRefTypesRsp_toDict(getattr(v, "syncRefTypesRsp"))
        dict["syncCapabilityRsp"] = self.SyncCapabilityRsp_toDict(getattr(v, "syncCapabilityRsp"))
        dict["syncEGetInitCfgRsp"] = self.SyncEGetInitCfgRsp_toDict(getattr(v, "syncEGetInitCfgRsp"))
        dict["syncEStatusRsp"] = self.SyncEStatusRsp_toDict(getattr(v, "syncEStatusRsp"))
        dict["syncEConfigValidateRsp"] = self.SyncEConfigValidateRsp_toDict(getattr(v, "syncEConfigValidateRsp"))
        dict["syncEConfigApplyRsp"] = self.SyncEConfigApplyRsp_toDict(getattr(v, "syncEConfigApplyRsp"))
        dict["ptpStatusRsp"] = self.PtpStatusRsp_toDict(getattr(v, "ptpStatusRsp"))
        dict["ptpConfigValidateRsp"] = self.PtpConfigValidateRsp_toDict(getattr(v, "ptpConfigValidateRsp"))
        dict["ptpConfigApplyRsp"] = self.PtpConfigApplyRsp_toDict(getattr(v, "ptpConfigApplyRsp"))
        dict["ptpInitCfgRsp"] = self.PtpInitCfgRsp_toDict(getattr(v, "ptpInitCfgRsp"))
        return dict

    def GetTimeInfo(self):
        _req = syncprocctrl_service_pb2.GetTimeInfoReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.getTimeInfoReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncRefTypes(self):
        _req = syncprocctrl_service_pb2.SyncRefTypesReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncRefTypesReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncCapability(self):
        _req = syncprocctrl_service_pb2.SyncCapabilityReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncCapabilityReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncEGetInitCfg(self):
        _req = syncprocctrl_service_pb2.SyncEGetInitCfgReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncEGetInitCfgReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncEStatus(self):
        _req = syncprocctrl_service_pb2.SyncEStatusReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncEStatusReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncEConfigValidate(self, syncEConfigData):
        _req = syncprocctrl_service_pb2.SyncEConfigValidateReq()
        _req.syncEConfigData.CopyFrom(self.SyncEConfigData_fromDict(syncEConfigData))
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncEConfigValidateReq.CopyFrom(_req)
        debug(_inMsg)

    def SyncEConfigApply(self, syncEConfigData):
        _req = syncprocctrl_service_pb2.SyncEConfigApplyReq()
        _req.syncEConfigData.CopyFrom(self.SyncEConfigData_fromDict(syncEConfigData))
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.syncEConfigApplyReq.CopyFrom(_req)
        debug(_inMsg)

    def PtpStatus(self):
        _req = syncprocctrl_service_pb2.PtpStatusReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.ptpStatusReq.CopyFrom(_req)
        debug(_inMsg)

    def PtpConfigValidate(self, ptpConfigData):
        _req = syncprocctrl_service_pb2.PtpConfigValidateReq()
        _req.ptpConfigData.CopyFrom(self.PtpConfigData_fromDict(ptpConfigData))
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.ptpConfigValidateReq.CopyFrom(_req)
        debug(_inMsg)

    def PtpConfigApply(self, ptpConfigData):
        _req = syncprocctrl_service_pb2.PtpConfigApplyReq()
        _req.ptpConfigData.CopyFrom(self.PtpConfigData_fromDict(ptpConfigData))
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.ptpConfigApplyReq.CopyFrom(_req)
        debug(_inMsg)

    def PtpInitCfg(self):
        _req = syncprocctrl_service_pb2.PtpInitCfgReq()
        _inMsg = syncprocctrl_service_pb2.SyncProcCtrlIn()
        _inMsg.ptpInitCfgReq.CopyFrom(_req)
        debug(_inMsg)

