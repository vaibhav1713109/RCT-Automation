from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libeeprom_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libeepromProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibeeprom", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def passwordCompare(self):
        _req = libeeprom_pb2.passwordCompareReq()
        _inMsg = libeeprom_pb2.libeepromIn()
        _inMsg.passwordCompareReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libeeprom_pb2.libeepromOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "passwordCompareRsp":
            if _rsp.zzerr_msg:
                raise EtwError("passwordCompare failed: " + _rsp.zzerr_msg)
            raise EtwError("passwordCompare failed: no valid response found (passwordCompare)")
        return _rsp.passwordCompareRsp.password, _rsp.passwordCompareRsp._ret

