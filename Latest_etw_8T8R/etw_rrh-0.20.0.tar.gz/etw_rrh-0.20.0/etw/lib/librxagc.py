from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import librxagc_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class librxagcProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibrxagc", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def Rx_AGC_returnStatusType_fromDict(self, dict):
        x = librxagc_pb2.Rx_AGC_returnStatusType()
        if not dict: return x
        setattr(x, "Status", dict.get("Status", 0))
        setattr(x, "ErrorString", dict.get("ErrorString", ""))
        return x

    def Rx_Agc_TableEntry_fromDict(self, dict):
        x = librxagc_pb2.Rx_Agc_TableEntry()
        if not dict: return x
        setattr(x, "adcInternalDsaAttenuation", dict.get("adcInternalDsaAttenuation", 0))
        setattr(x, "rxAgcDsaAttenuation", dict.get("rxAgcDsaAttenuation", 0))
        setattr(x, "digitalGain", dict.get("digitalGain", 0))
        return x

    def Rx_AGC_returnStatusType_toDict(self, v):
        dict = {}
        dict["Status"] = getattr(v, "Status")
        dict["ErrorString"] = getattr(v, "ErrorString")
        return dict

    def Rx_Agc_TableEntry_toDict(self, v):
        dict = {}
        dict["adcInternalDsaAttenuation"] = getattr(v, "adcInternalDsaAttenuation")
        dict["rxAgcDsaAttenuation"] = getattr(v, "rxAgcDsaAttenuation")
        dict["digitalGain"] = getattr(v, "digitalGain")
        return dict

    def Rx_AGC_Init(self):
        _req = librxagc_pb2.Rx_AGC_InitReq()
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_InitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_InitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_Init failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_Init failed: no valid response found (rx_AGC_Init)")
        return self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_InitRsp._ret)

    def Rx_AGC_configureCgStepTrigger(self, RxAntennaChainID, cgStepUpCount, cgStepDownCount):
        _req = librxagc_pb2.Rx_AGC_configureCgStepTriggerReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _req.cgStepUpCount = cgStepUpCount
        _req.cgStepDownCount = cgStepDownCount
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_configureCgStepTriggerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_configureCgStepTriggerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_configureCgStepTrigger failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_configureCgStepTrigger failed: no valid response found (rx_AGC_configureCgStepTrigger)")
        return self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_configureCgStepTriggerRsp._ret)

    def Rx_AGC_getCgStepTrigger(self, RxAntennaChainID):
        _req = librxagc_pb2.Rx_AGC_getCgStepTriggerReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_getCgStepTriggerReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_getCgStepTriggerRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_getCgStepTrigger failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_getCgStepTrigger failed: no valid response found (rx_AGC_getCgStepTrigger)")
        return _rsp.rx_AGC_getCgStepTriggerRsp.cgStepUpCountPtr, _rsp.rx_AGC_getCgStepTriggerRsp.cgStepDownCountPtr, self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_getCgStepTriggerRsp._ret)

    def Rx_AGC_configureAnalogToDigitalDelay(self, RxAntennaChainID, localRxPortNo):
        _req = librxagc_pb2.Rx_AGC_configureAnalogToDigitalDelayReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _req.localRxPortNo = localRxPortNo
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_configureAnalogToDigitalDelayReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_configureAnalogToDigitalDelayRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_configureAnalogToDigitalDelay failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_configureAnalogToDigitalDelay failed: no valid response found (rx_AGC_configureAnalogToDigitalDelay)")
        return self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_configureAnalogToDigitalDelayRsp._ret)

    def Rx_AGC_configureRxAGCTable(self, RxAntennaChainID, localRxPortNo, rxAgcTableSize):
        _req = librxagc_pb2.Rx_AGC_configureRxAGCTableReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _req.localRxPortNo = localRxPortNo
        _req.rxAgcTableSize = rxAgcTableSize
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_configureRxAGCTableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_configureRxAGCTableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_configureRxAGCTable failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_configureRxAGCTable failed: no valid response found (rx_AGC_configureRxAGCTable)")
        return self.Rx_Agc_TableEntry_toDict(_rsp.rx_AGC_configureRxAGCTableRsp.rxAgcTablePtr), self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_configureRxAGCTableRsp._ret)

    def Rx_AGC_getRxAgcTable(self, RxAntennaChainID, localRxPortNo):
        _req = librxagc_pb2.Rx_AGC_getRxAgcTableReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _req.localRxPortNo = localRxPortNo
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_getRxAgcTableReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_getRxAgcTableRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_getRxAgcTable failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_getRxAgcTable failed: no valid response found (rx_AGC_getRxAgcTable)")
        return self.Rx_Agc_TableEntry_toDict(_rsp.rx_AGC_getRxAgcTableRsp.rxAgcTablePtr), _rsp.rx_AGC_getRxAgcTableRsp.rxAgcTableSizePtr, self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_getRxAgcTableRsp._ret)

    def Rx_AGC_setMode(self, RxAntennaChainID, rxAgcMode):
        _req = librxagc_pb2.Rx_AGC_setModeReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _req.rxAgcMode = rxAgcMode
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_setModeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_setModeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_setMode failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_setMode failed: no valid response found (rx_AGC_setMode)")
        return self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_setModeRsp._ret)

    def Rx_AGC_getMode(self, RxAntennaChainID):
        _req = librxagc_pb2.Rx_AGC_getModeReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_getModeReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_getModeRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_getMode failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_getMode failed: no valid response found (rx_AGC_getMode)")
        return _rsp.rx_AGC_getModeRsp.rxAgcModePtr, self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_getModeRsp._ret)

    def Rx_AGC_getCapability(self, RxAntennaChainID):
        _req = librxagc_pb2.Rx_AGC_getCapabilityReq()
        _req.RxAntennaChainID = RxAntennaChainID
        _inMsg = librxagc_pb2.librxagcIn()
        _inMsg.rx_AGC_getCapabilityReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, librxagc_pb2.librxagcOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "rx_AGC_getCapabilityRsp":
            if _rsp.zzerr_msg:
                raise EtwError("Rx_AGC_getCapability failed: " + _rsp.zzerr_msg)
            raise EtwError("Rx_AGC_getCapability failed: no valid response found (rx_AGC_getCapability)")
        return _rsp.rx_AGC_getCapabilityRsp.numOfRxPortsPtr, _rsp.rx_AGC_getCapabilityRsp.numOfCgStepsPtr, self.Rx_AGC_returnStatusType_toDict(_rsp.rx_AGC_getCapabilityRsp._ret)

