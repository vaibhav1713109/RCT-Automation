from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libwdt_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libwdtProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibwdt", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def resetHW(self):
        _req = libwdt_pb2.resetHWReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.resetHWReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "resetHWRsp":
            if _rsp.zzerr_msg:
                raise EtwError("resetHW failed: " + _rsp.zzerr_msg)
            raise EtwError("resetHW failed: no valid response found (resetHW)")

    def resetWD(self):
        _req = libwdt_pb2.resetWDReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.resetWDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "resetWDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("resetWD failed: " + _rsp.zzerr_msg)
            raise EtwError("resetWD failed: no valid response found (resetWD)")

    def enableUserSupervision(self):
        _req = libwdt_pb2.enableUserSupervisionReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.enableUserSupervisionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "enableUserSupervisionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("enableUserSupervision failed: " + _rsp.zzerr_msg)
            raise EtwError("enableUserSupervision failed: no valid response found (enableUserSupervision)")

    def disableUserSupervision(self):
        _req = libwdt_pb2.disableUserSupervisionReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.disableUserSupervisionReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "disableUserSupervisionRsp":
            if _rsp.zzerr_msg:
                raise EtwError("disableUserSupervision failed: " + _rsp.zzerr_msg)
            raise EtwError("disableUserSupervision failed: no valid response found (disableUserSupervision)")

    def enableWD(self):
        _req = libwdt_pb2.enableWDReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.enableWDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "enableWDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("enableWD failed: " + _rsp.zzerr_msg)
            raise EtwError("enableWD failed: no valid response found (enableWD)")

    def disableWD(self):
        _req = libwdt_pb2.disableWDReq()
        _inMsg = libwdt_pb2.libwdtIn()
        _inMsg.disableWDReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libwdt_pb2.libwdtOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "disableWDRsp":
            if _rsp.zzerr_msg:
                raise EtwError("disableWD failed: " + _rsp.zzerr_msg)
            raise EtwError("disableWD failed: no valid response found (disableWD)")

