from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import libetap_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class libetapProxy:
    def __init__(self, ipcLink, service_name = "etwserver"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "etwlibetap", method_call="MethodCall")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def injectDmaDdr(self, tap_point, antenna_port_id, cc_id, ccid_pattern, first_desc, tail_desc, circular_inject):
        _req = libetap_pb2.injectDmaDdrReq()
        _req.tap_point = tap_point
        _req.antenna_port_id = antenna_port_id
        _req.cc_id = cc_id
        _req.ccid_pattern = ccid_pattern
        _req.first_desc = first_desc
        _req.tail_desc = tail_desc
        _req.circular_inject = circular_inject
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.injectDmaDdrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "injectDmaDdrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("injectDmaDdr failed: " + _rsp.zzerr_msg)
            raise EtwError("injectDmaDdr failed: no valid response found (injectDmaDdr)")
        return _rsp.injectDmaDdrRsp._ret

    def captureDmaDdr(self, tap_point, antenna_port_id, cc_id, no_frames, first_desc, tail_desc, circular_capture):
        _req = libetap_pb2.captureDmaDdrReq()
        _req.tap_point = tap_point
        _req.antenna_port_id = antenna_port_id
        _req.cc_id = cc_id
        _req.no_frames = no_frames
        _req.first_desc = first_desc
        _req.tail_desc = tail_desc
        _req.circular_capture = circular_capture
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.captureDmaDdrReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "captureDmaDdrRsp":
            if _rsp.zzerr_msg:
                raise EtwError("captureDmaDdr failed: " + _rsp.zzerr_msg)
            raise EtwError("captureDmaDdr failed: no valid response found (captureDmaDdr)")
        return _rsp.captureDmaDdrRsp._ret

    def etapInit(self):
        _req = libetap_pb2.etapInitReq()
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.etapInitReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "etapInitRsp":
            if _rsp.zzerr_msg:
                raise EtwError("etapInit failed: " + _rsp.zzerr_msg)
            raise EtwError("etapInit failed: no valid response found (etapInit)")
        return _rsp.etapInitRsp._ret

    def startCapture(self):
        _req = libetap_pb2.startCaptureReq()
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.startCaptureReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "startCaptureRsp":
            if _rsp.zzerr_msg:
                raise EtwError("startCapture failed: " + _rsp.zzerr_msg)
            raise EtwError("startCapture failed: no valid response found (startCapture)")
        return _rsp.startCaptureRsp._ret

    def stopCapture(self):
        _req = libetap_pb2.stopCaptureReq()
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.stopCaptureReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "stopCaptureRsp":
            if _rsp.zzerr_msg:
                raise EtwError("stopCapture failed: " + _rsp.zzerr_msg)
            raise EtwError("stopCapture failed: no valid response found (stopCapture)")
        return _rsp.stopCaptureRsp._ret

    def startInject(self):
        _req = libetap_pb2.startInjectReq()
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.startInjectReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "startInjectRsp":
            if _rsp.zzerr_msg:
                raise EtwError("startInject failed: " + _rsp.zzerr_msg)
            raise EtwError("startInject failed: no valid response found (startInject)")
        return _rsp.startInjectRsp._ret

    def stopInject(self):
        _req = libetap_pb2.stopInjectReq()
        _inMsg = libetap_pb2.libetapIn()
        _inMsg.stopInjectReq.CopyFrom(_req)
        debug(_inMsg)
        _rsp = self.gw.methodCall(_inMsg, libetap_pb2.libetapOut)
        debug(_rsp)
        if _rsp.WhichOneof("out") != "stopInjectRsp":
            if _rsp.zzerr_msg:
                raise EtwError("stopInject failed: " + _rsp.zzerr_msg)
            raise EtwError("stopInject failed: no valid response found (stopInject)")
        return _rsp.stopInjectRsp._ret

