from etw.lib.etwproxy import DBusGwProxy, EtwProxy, EtwError
from etw.lib import dbusgw_pb2
import cuplanectrl_service_pb2
debug_on = 0
def debug(msg):
    if debug_on: print(msg.__str__())

class cuplanectrl_serviceProxy:
    def __init__(self, ipcLink, service_name = "cuplanectrl"):
        self.gw = DBusGwProxy(ipcLink, service_name = service_name,
                              proto_name = "cuplanectrl", method_call="Method")

    def connect(self):
        self.gw.connect()

    def disconnect(self):
        self.gw.disconnect()

    def EndpointTypes_SupportedSectionTypes_fromDict(self, dict):
        x = cuplanectrl_service_pb2.EndpointTypes_SupportedSectionTypes()
        if not dict: return x
        setattr(x, "sectionType", dict.get("sectionType", 0))
        for v in dict.get("supportedSectionExtensions", []):
            getattr(x, "supportedSectionExtensions").append(v)
        return x

    def EndpointTypes_fromDict(self, dict):
        x = cuplanectrl_service_pb2.EndpointTypes()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "id", dict.get("id", 0))
        for v in dict.get("supportedSectionTypes", []):
            getattr(x, "supportedSectionTypes").append(v)
        for v in dict.get("supportedFrameStructures", []):
            getattr(x, "supportedFrameStructures").append(v)
        setattr(x, "managedDelaySupport", dict.get("managedDelaySupport", 0))
        setattr(x, "multipleNumerologySupported", dict.get("multipleNumerologySupported", 0))
        setattr(x, "maxNumerologyChangeDuration", dict.get("maxNumerologyChangeDuration", 0))
        setattr(x, "maxControlSectionsPerDataSection", dict.get("maxControlSectionsPerDataSection", 0))
        setattr(x, "maxSectionsPerSymbol", dict.get("maxSectionsPerSymbol", 0))
        setattr(x, "maxSectionsPerSlot", dict.get("maxSectionsPerSlot", 0))
        setattr(x, "maxBeamsPerSymbol", dict.get("maxBeamsPerSymbol", 0))
        setattr(x, "maxBeamsPerSlot", dict.get("maxBeamsPerSlot", 0))
        setattr(x, "maxPrbPerSymbol", dict.get("maxPrbPerSymbol", 0))
        for v in dict.get("prbCapacityAllocationGranularity", []):
            getattr(x, "prbCapacityAllocationGranularity").append(v)
        setattr(x, "maxNumerologiesPerSymbol", dict.get("maxNumerologiesPerSymbol", 0))
        return x

    def StaticLowLevelTxEndpoints_fromDict(self, dict):
        x = cuplanectrl_service_pb2.StaticLowLevelTxEndpoints()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "restrictedInterfaces", dict.get("restrictedInterfaces", ""))
        setattr(x, "array", dict.get("array", ""))
        setattr(x, "endpointType", dict.get("endpointType", 0))
        return x

    def StaticLowLevelRxEndpoints_fromDict(self, dict):
        x = cuplanectrl_service_pb2.StaticLowLevelRxEndpoints()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "restrictedInterfaces", dict.get("restrictedInterfaces", ""))
        setattr(x, "array", dict.get("array", ""))
        setattr(x, "endpointType", dict.get("endpointType", 0))
        return x

    def Polarisations_fromDict(self, dict):
        x = cuplanectrl_service_pb2.Polarisations()
        if not dict: return x
        setattr(x, "polarisationIndex", dict.get("polarisationIndex", 0))
        setattr(x, "polarisationType", dict.get("polarisationType", 0))
        return x

    def TxArrays_DlCapabilities_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxArrays_DlCapabilities()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "maxSupportedFrequencyDl", dict.get("maxSupportedFrequencyDl", 0))
        setattr(x, "minSupportedFrequencyDl", dict.get("minSupportedFrequencyDl", 0))
        setattr(x, "maxSupportedBandwidthDl", dict.get("maxSupportedBandwidthDl", 0))
        setattr(x, "maxNumCarriersDl", dict.get("maxNumCarriersDl", 0))
        setattr(x, "maxCarrierBandwidthDl", dict.get("maxCarrierBandwidthDl", 0))
        setattr(x, "minCarrierBandwidthDl", dict.get("minCarrierBandwidthDl", 0))
        return x

    def TxArrays_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxArrays()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "numberOfRows", dict.get("numberOfRows", 0))
        setattr(x, "numberOfColumns", dict.get("numberOfColumns", 0))
        setattr(x, "numberOfArrayLayers", dict.get("numberOfArrayLayers", 0))
        setattr(x, "horizontalSpacing", dict.get("horizontalSpacing", 0))
        setattr(x, "verticalSpacing", dict.get("verticalSpacing", 0))
        setattr(x, "normalVectorAzimuthAngle", dict.get("normalVectorAzimuthAngle", 0))
        setattr(x, "normalVectorZenithAngle", dict.get("normalVectorZenithAngle", 0))
        setattr(x, "leftmostBottomArrayElementPositionX", dict.get("leftmostBottomArrayElementPositionX", 0))
        setattr(x, "leftmostBottomArrayElementPositionY", dict.get("leftmostBottomArrayElementPositionY", 0))
        setattr(x, "leftmostBottomArrayElementPositionZ", dict.get("leftmostBottomArrayElementPositionZ", 0))
        for v in dict.get("polarisations", []):
            getattr(x, "polarisations").append(self.Polarisations_fromDict(v))
        setattr(x, "bandNumber", dict.get("bandNumber", 0))
        setattr(x, "maxGain", dict.get("maxGain", 0))
        setattr(x, "independentPowerBudget", dict.get("independentPowerBudget", 0))
        for v in dict.get("dlCapabilities", []):
            getattr(x, "dlCapabilities").append(v)
        return x

    def RxArrays_UlCapabilities_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxArrays_UlCapabilities()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "maxSupportedFrequencyUl", dict.get("maxSupportedFrequencyUl", 0))
        setattr(x, "minSupportedFrequencyUl", dict.get("minSupportedFrequencyUl", 0))
        setattr(x, "maxSupportedBandwidthUl", dict.get("maxSupportedBandwidthUl", 0))
        setattr(x, "maxNumCarriersUl", dict.get("maxNumCarriersUl", 0))
        setattr(x, "maxCarrierBandwidthUl", dict.get("maxCarrierBandwidthUl", 0))
        setattr(x, "minCarrierBandwidthUl", dict.get("minCarrierBandwidthUl", 0))
        return x

    def RxArrays_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxArrays()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "name", dict.get("name", ""))
        setattr(x, "numberOfRows", dict.get("numberOfRows", 0))
        setattr(x, "numberOfColumns", dict.get("numberOfColumns", 0))
        setattr(x, "numberOfArrayLayers", dict.get("numberOfArrayLayers", 0))
        setattr(x, "horizontalSpacing", dict.get("horizontalSpacing", 0))
        setattr(x, "verticalSpacing", dict.get("verticalSpacing", 0))
        setattr(x, "normalVectorAzimuthAngle", dict.get("normalVectorAzimuthAngle", 0))
        setattr(x, "normalVectorZenithAngle", dict.get("normalVectorZenithAngle", 0))
        setattr(x, "leftmostBottomArrayElementPositionX", dict.get("leftmostBottomArrayElementPositionX", 0))
        setattr(x, "leftmostBottomArrayElementPositionY", dict.get("leftmostBottomArrayElementPositionY", 0))
        setattr(x, "leftmostBottomArrayElementPositionZ", dict.get("leftmostBottomArrayElementPositionZ", 0))
        for v in dict.get("polarisations", []):
            getattr(x, "polarisations").append(self.Polarisations_fromDict(v))
        setattr(x, "bandNumber", dict.get("bandNumber", 0))
        setattr(x, "maxGainCorrectionRange", dict.get("maxGainCorrectionRange", 0))
        setattr(x, "minGainCorrectionRange", dict.get("minGainCorrectionRange", 0))
        for v in dict.get("ulCapabilities", []):
            getattr(x, "ulCapabilities").append(v)
        return x

    def TxRxRelations_RelationTypes_PairsOfTxRxArrayElements_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxRelations_RelationTypes_PairsOfTxRxArrayElements()
        if not dict: return x
        setattr(x, "txArrayElement", dict.get("txArrayElement", 0))
        setattr(x, "rxArrayElement", dict.get("rxArrayElement", 0))
        return x

    def TxRxRelations_RelationTypes_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxRelations_RelationTypes()
        if not dict: return x
        setattr(x, "relationType", dict.get("relationType", 0))
        for v in dict.get("pairsOfTxRxArrayElements", []):
            getattr(x, "pairsOfTxRxArrayElements").append(v)
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        return x

    def TxRxRelations_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxRelations()
        if not dict: return x
        setattr(x, "entity", dict.get("entity", 0))
        setattr(x, "txArrayName", dict.get("txArrayName", ""))
        setattr(x, "rxArrayName", dict.get("rxArrayName", ""))
        for v in dict.get("relationTypes", []):
            getattr(x, "relationTypes").append(v)
        return x

    def BandCapabilities_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BandCapabilities()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "bandNumber", dict.get("bandNumber", 0))
        setattr(x, "maxSupportedFrequencyDl", dict.get("maxSupportedFrequencyDl", 0))
        setattr(x, "minSupportedFrequencyDl", dict.get("minSupportedFrequencyDl", 0))
        setattr(x, "maxSupportedBandwidthDl", dict.get("maxSupportedBandwidthDl", 0))
        setattr(x, "maxNumCarriersDl", dict.get("maxNumCarriersDl", 0))
        setattr(x, "maxCarrierBandwidthDl", dict.get("maxCarrierBandwidthDl", 0))
        setattr(x, "minCarrierBandwidthDl", dict.get("minCarrierBandwidthDl", 0))
        setattr(x, "maxSupportedFrequencyUl", dict.get("maxSupportedFrequencyUl", 0))
        setattr(x, "minSupportedFrequencyUl", dict.get("minSupportedFrequencyUl", 0))
        setattr(x, "maxSupportedBandwidthUl", dict.get("maxSupportedBandwidthUl", 0))
        setattr(x, "maxNumCarriersUl", dict.get("maxNumCarriersUl", 0))
        setattr(x, "maxCarrierBandwidthUl", dict.get("maxCarrierBandwidthUl", 0))
        setattr(x, "minCarrierBandwidthUl", dict.get("minCarrierBandwidthUl", 0))
        setattr(x, "maxNumComponentCarriers", dict.get("maxNumComponentCarriers", 0))
        setattr(x, "maxNumBands", dict.get("maxNumBands", 0))
        setattr(x, "maxNumSectors", dict.get("maxNumSectors", 0))
        setattr(x, "maxPowerPerAntenna", dict.get("maxPowerPerAntenna", 0))
        setattr(x, "minPowerPerAntenna", dict.get("minPowerPerAntenna", 0))
        setattr(x, "codebookConfigurationNg", dict.get("codebookConfigurationNg", 0))
        setattr(x, "codebookConfigurationN1", dict.get("codebookConfigurationN1", 0))
        setattr(x, "codebookConfigurationN2", dict.get("codebookConfigurationN2", 0))
        setattr(x, "minArfcnUl", dict.get("minArfcnUl", 0))
        setattr(x, "maxArfcnUl", dict.get("maxArfcnUl", 0))
        setattr(x, "minArfcnDl", dict.get("minArfcnDl", 0))
        setattr(x, "maxArfcnDl", dict.get("maxArfcnDl", 0))
        setattr(x, "carrierType", dict.get("carrierType", 0))
        setattr(x, "duplexScheme", dict.get("duplexScheme", 0))
        return x

    def CompFormat_fromDict(self, dict):
        x = cuplanectrl_service_pb2.CompFormat()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "exponent", dict.get("exponent", 0))
        setattr(x, "blockScalar", dict.get("blockScalar", 0))
        setattr(x, "compBitWidth", dict.get("compBitWidth", 0))
        setattr(x, "compShift", dict.get("compShift", 0))
        for v in dict.get("activeBeamSpaceCoeficientMask", []):
            getattr(x, "activeBeamSpaceCoeficientMask").append(v)
        setattr(x, "blockScaler", dict.get("blockScaler", 0))
        setattr(x, "csf", dict.get("csf", 0))
        setattr(x, "modCompScaler", dict.get("modCompScaler", 0))
        return x

    def CompMethodSupported_fromDict(self, dict):
        x = cuplanectrl_service_pb2.CompMethodSupported()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "iqBitwidth", dict.get("iqBitwidth", 0))
        setattr(x, "compressionType", dict.get("compressionType", 0))
        getattr(x, "compressionFormat").CopyFrom(self.CompFormat_fromDict(dict.get("compressionFormat")))
        return x

    def FormatOfIqSample_fromDict(self, dict):
        x = cuplanectrl_service_pb2.FormatOfIqSample()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "dynamicCompressionSupported", dict.get("dynamicCompressionSupported", 0))
        setattr(x, "realtimeVariableBitWidthSupported", dict.get("realtimeVariableBitWidthSupported", 0))
        for v in dict.get("compressionMethodSupported", []):
            getattr(x, "compressionMethodSupported").append(self.CompMethodSupported_fromDict(v))
        setattr(x, "variableBitwidthPerChannelSupported", dict.get("variableBitwidthPerChannelSupported", 0))
        setattr(x, "symincSupported", dict.get("symincSupported", 0))
        return x

    def RuCapabilities_UlMixedNumReqGuardRbs_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RuCapabilities_UlMixedNumReqGuardRbs()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "scsA", dict.get("scsA", 0))
        setattr(x, "scsB", dict.get("scsB", 0))
        setattr(x, "numberOfGuardRbsUl", dict.get("numberOfGuardRbsUl", 0))
        return x

    def RuCapabilities_DlMixedNumReqGuardRbs_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RuCapabilities_DlMixedNumReqGuardRbs()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "scsA", dict.get("scsA", 0))
        setattr(x, "scsB", dict.get("scsB", 0))
        setattr(x, "numberOfGuardRbsDl", dict.get("numberOfGuardRbsDl", 0))
        return x

    def RuCapabilities_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RuCapabilities()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "ruSupportedCategory", dict.get("ruSupportedCategory", 0))
        setattr(x, "numberOfRuPorts", dict.get("numberOfRuPorts", 0))
        setattr(x, "numberOfSpatialStreams", dict.get("numberOfSpatialStreams", 0))
        setattr(x, "maxPowerPerPaAntenna", dict.get("maxPowerPerPaAntenna", 0))
        setattr(x, "minPowerPerPaAntenna", dict.get("minPowerPerPaAntenna", 0))
        setattr(x, "fronthaulSplitOption", dict.get("fronthaulSplitOption", 0))
        getattr(x, "formatOfIqSample").CopyFrom(self.FormatOfIqSample_fromDict(dict.get("formatOfIqSample")))
        for v in dict.get("ulMixedNumRequiredGuardRbs", []):
            getattr(x, "ulMixedNumRequiredGuardRbs").append(v)
        for v in dict.get("dlMixedNumRequiredGuardRbs", []):
            getattr(x, "dlMixedNumRequiredGuardRbs").append(v)
        setattr(x, "energySavingByTransmissionBlanks", dict.get("energySavingByTransmissionBlanks", 0))
        setattr(x, "dynamicTransportDelayManagementSupported", dict.get("dynamicTransportDelayManagementSupported", 0))
        return x

    def GetRadioConfReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.GetRadioConfReq()
        if not dict: return x
        return x

    def RadioConfData_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RadioConfData()
        if not dict: return x
        setattr(x, "mPlaneVersion", dict.get("mPlaneVersion", 0))
        for v in dict.get("endpointTypes", []):
            getattr(x, "endpointTypes").append(self.EndpointTypes_fromDict(v))
        for v in dict.get("staticLowLevelTxEndpoints", []):
            getattr(x, "staticLowLevelTxEndpoints").append(self.StaticLowLevelTxEndpoints_fromDict(v))
        for v in dict.get("staticLowLevelRxEndpoints", []):
            getattr(x, "staticLowLevelRxEndpoints").append(self.StaticLowLevelRxEndpoints_fromDict(v))
        for v in dict.get("txArrays", []):
            getattr(x, "txArrays").append(self.TxArrays_fromDict(v))
        for v in dict.get("rxArrays", []):
            getattr(x, "rxArrays").append(self.RxArrays_fromDict(v))
        for v in dict.get("txRxRelations", []):
            getattr(x, "txRxRelations").append(self.TxRxRelations_fromDict(v))
        for v in dict.get("bandCapabilities", []):
            getattr(x, "bandCapabilities").append(self.BandCapabilities_fromDict(v))
        getattr(x, "ruCapabilities").CopyFrom(self.RuCapabilities_fromDict(dict.get("ruCapabilities")))
        return x

    def GetRadioConfRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.GetRadioConfRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        getattr(x, "radioConfData").CopyFrom(self.RadioConfData_fromDict(dict.get("radioConfData")))
        return x

    def NumberOfPrbsPerScs_fromDict(self, dict):
        x = cuplanectrl_service_pb2.NumberOfPrbsPerScs()
        if not dict: return x
        setattr(x, "scs", dict.get("scs", 0))
        setattr(x, "numberOfPrb", dict.get("numberOfPrb", 0))
        return x

    def EaxcId_fromDict(self, dict):
        x = cuplanectrl_service_pb2.EaxcId()
        if not dict: return x
        setattr(x, "oDuPortBitmask", dict.get("oDuPortBitmask", 0))
        setattr(x, "bandSectorBitmask", dict.get("bandSectorBitmask", 0))
        setattr(x, "ccidBitmask", dict.get("ccidBitmask", 0))
        setattr(x, "ruPortBitmask", dict.get("ruPortBitmask", 0))
        setattr(x, "eaxcId", dict.get("eaxcId", 0))
        return x

    def LteTddFrame_fromDict(self, dict):
        x = cuplanectrl_service_pb2.LteTddFrame()
        if not dict: return x
        setattr(x, "subframeAssignment", dict.get("subframeAssignment", 0))
        setattr(x, "specialSubFramePattern", dict.get("specialSubFramePattern", 0))
        return x

    def LaaCarrierConfiguration_MaxCwUsageCounter_fromDict(self, dict):
        x = cuplanectrl_service_pb2.LaaCarrierConfiguration_MaxCwUsageCounter()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "priority", dict.get("priority", 0))
        setattr(x, "counterValue", dict.get("counterValue", 0))
        return x

    def LaaCarrierConfiguration_fromDict(self, dict):
        x = cuplanectrl_service_pb2.LaaCarrierConfiguration()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "edThresholdPdsch", dict.get("edThresholdPdsch", 0))
        setattr(x, "edThresholdDrs", dict.get("edThresholdDrs", 0))
        setattr(x, "txAntennaPorts", dict.get("txAntennaPorts", 0))
        setattr(x, "transmissionPowerForDrs", dict.get("transmissionPowerForDrs", 0))
        setattr(x, "dmtcPeriod", dict.get("dmtcPeriod", 0))
        setattr(x, "dmtcOffset", dict.get("dmtcOffset", 0))
        setattr(x, "lbtTimer", dict.get("lbtTimer", 0))
        for v in dict.get("maxCwUsageCounter", []):
            getattr(x, "maxCwUsageCounter").append(v)
        return x

    def ProcessingElementConf_fromDict(self, dict):
        x = cuplanectrl_service_pb2.ProcessingElementConf()
        if not dict: return x
        setattr(x, "vlanId", dict.get("vlanId", 0))
        setattr(x, "ruMacAddress", dict.get("ruMacAddress", 0))
        setattr(x, "duMacAddress", dict.get("duMacAddress", 0))
        return x

    def TxPath_LowLevelTxEndpointConf_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxPath_LowLevelTxEndpointConf()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        getattr(x, "compressionMethodSupported").CopyFrom(self.CompMethodSupported_fromDict(dict.get("compressionMethodSupported")))
        setattr(x, "frameStructure", dict.get("frameStructure", 0))
        setattr(x, "cpType", dict.get("cpType", 0))
        setattr(x, "cpLength", dict.get("cpLength", 0))
        setattr(x, "cpLengthOther", dict.get("cpLengthOther", 0))
        setattr(x, "offsetToAbsoluteFrequencyCenter", dict.get("offsetToAbsoluteFrequencyCenter", 0))
        for v in dict.get("numberOfPrbsPerScs", []):
            getattr(x, "numberOfPrbsPerScs").append(self.NumberOfPrbsPerScs_fromDict(v))
        getattr(x, "eaxcid").CopyFrom(self.EaxcId_fromDict(dict.get("eaxcid")))
        return x

    def TxPath_TxArrayCarrierConf_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxPath_TxArrayCarrierConf()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "absoluteFrequencyCenter", dict.get("absoluteFrequencyCenter", 0))
        setattr(x, "centerOfChannelBandwidth", dict.get("centerOfChannelBandwidth", 0))
        setattr(x, "channelBandWidth", dict.get("channelBandWidth", 0))
        setattr(x, "active", dict.get("active", 0))
        setattr(x, "bandNumber", dict.get("bandNumber", 0))
        getattr(x, "lteTddFrame").CopyFrom(self.LteTddFrame_fromDict(dict.get("lteTddFrame")))
        getattr(x, "laaCarrierConfiguration").CopyFrom(self.LaaCarrierConfiguration_fromDict(dict.get("laaCarrierConfiguration")))
        setattr(x, "gain", dict.get("gain", 0))
        setattr(x, "downlinkRadioFrameOffset", dict.get("downlinkRadioFrameOffset", 0))
        setattr(x, "downlinkSfnOffset", dict.get("downlinkSfnOffset", 0))
        return x

    def TxPath_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxPath()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "staticLowLevelTxEndpointName", dict.get("staticLowLevelTxEndpointName", ""))
        setattr(x, "lowLevelTxEndpointConf", dict.get("lowLevelTxEndpointConf", 0))
        setattr(x, "txArrayCarrierConf", dict.get("txArrayCarrierConf", 0))
        getattr(x, "processingElementConf").CopyFrom(self.ProcessingElementConf_fromDict(dict.get("processingElementConf")))
        return x

    def RxPath_LowLevelRxEndpointConf_UlFftSamplingOffsets_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxPath_LowLevelRxEndpointConf_UlFftSamplingOffsets()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "scs", dict.get("scs", 0))
        setattr(x, "ulFftSamplingOffset", dict.get("ulFftSamplingOffset", 0))
        return x

    def RxPath_LowLevelRxEndpointConf_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxPath_LowLevelRxEndpointConf()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        getattr(x, "compressionMethodSupported").CopyFrom(self.CompMethodSupported_fromDict(dict.get("compressionMethodSupported")))
        setattr(x, "frameStructure", dict.get("frameStructure", 0))
        setattr(x, "cpType", dict.get("cpType", 0))
        setattr(x, "cpLength", dict.get("cpLength", 0))
        setattr(x, "cpLengthOther", dict.get("cpLengthOther", 0))
        setattr(x, "offsetToAbsoluteFrequencyCenter", dict.get("offsetToAbsoluteFrequencyCenter", 0))
        for v in dict.get("numberOfPrbsPerScs", []):
            getattr(x, "numberOfPrbsPerScs").append(self.NumberOfPrbsPerScs_fromDict(v))
        for v in dict.get("ulFftSamplingOffsets", []):
            getattr(x, "ulFftSamplingOffsets").append(v)
        getattr(x, "eaxcid").CopyFrom(self.EaxcId_fromDict(dict.get("eaxcid")))
        setattr(x, "nonTimeManagedDelayEnabled", dict.get("nonTimeManagedDelayEnabled", 0))
        return x

    def RxPath_RxArrayCarrierConf_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxPath_RxArrayCarrierConf()
        if not dict: return x
        setattr(x, "absoluteFrequencyCenter", dict.get("absoluteFrequencyCenter", 0))
        setattr(x, "centerOfChannelBandwidth", dict.get("centerOfChannelBandwidth", 0))
        setattr(x, "channelBandwidth", dict.get("channelBandwidth", 0))
        setattr(x, "active", dict.get("active", 0))
        setattr(x, "downlinkRadioFrameOffset", dict.get("downlinkRadioFrameOffset", 0))
        setattr(x, "downlinkSfnOffset", dict.get("downlinkSfnOffset", 0))
        setattr(x, "gainCorrection", dict.get("gainCorrection", 0))
        setattr(x, "nTaOffset", dict.get("nTaOffset", 0))
        return x

    def RxPath_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxPath()
        if not dict: return x
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        setattr(x, "staticLowLevelRxEndpointName", dict.get("staticLowLevelRxEndpointName", ""))
        setattr(x, "lowLevelRxEndpointConf", dict.get("lowLevelRxEndpointConf", 0))
        setattr(x, "rxArrayCarrierConf", dict.get("rxArrayCarrierConf", 0))
        getattr(x, "processingElementConf").CopyFrom(self.ProcessingElementConf_fromDict(dict.get("processingElementConf")))
        return x

    def TxRxPathStateChangeReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathStateChangeReq()
        if not dict: return x
        setattr(x, "state", dict.get("state", 0))
        setattr(x, "staticLowLevelTxEndpointNames", dict.get("staticLowLevelTxEndpointNames", ""))
        setattr(x, "staticLowLevelRxEndpointNames", dict.get("staticLowLevelRxEndpointNames", ""))
        return x

    def TxRxPathStateChangeRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathStateChangeRsp()
        if not dict: return x
        setattr(x, "status", dict.get("status", 0))
        return x

    def TxRxPathConfigReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathConfigReq()
        if not dict: return x
        setattr(x, "staticLowLevelTxEndpointNames", dict.get("staticLowLevelTxEndpointNames", ""))
        setattr(x, "staticLowLevelRxEndpointNames", dict.get("staticLowLevelRxEndpointNames", ""))
        return x

    def TxRxPathConfigRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathConfigRsp()
        if not dict: return x
        setattr(x, "errorOccurredDuringConfiguration", dict.get("errorOccurredDuringConfiguration", 0))
        return x

    def TxRxPathPrepareAndValidateReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathPrepareAndValidateReq()
        if not dict: return x
        for v in dict.get("txPath", []):
            getattr(x, "txPath").append(self.TxPath_fromDict(v))
        for v in dict.get("rxPath", []):
            getattr(x, "rxPath").append(self.RxPath_fromDict(v))
        return x

    def TxRxPathPrepareAndValidateRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.TxRxPathPrepareAndValidateRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def RegisterEventListenerInd_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RegisterEventListenerInd()
        if not dict: return x
        setattr(x, "clientName", dict.get("clientName", ""))
        setattr(x, "event", dict.get("event", 0))
        return x

    def AntCalCapabilitiesReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalCapabilitiesReq()
        if not dict: return x
        return x

    def AntCalCapabilitiesData_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalCapabilitiesData()
        if not dict: return x
        setattr(x, "selfCalSupport", dict.get("selfCalSupport", 0))
        setattr(x, "numberOfCalSymbolsPerBlockDL", dict.get("numberOfCalSymbolsPerBlockDL", 0))
        setattr(x, "numberOfCalSymbolsPerBlockUL", dict.get("numberOfCalSymbolsPerBlockUL", 0))
        setattr(x, "intervalBetweenCalBlocks", dict.get("intervalBetweenCalBlocks", 0))
        setattr(x, "numberOfCalBlocksPerStepDL", dict.get("numberOfCalBlocksPerStepDL", 0))
        setattr(x, "numberOfCalBlocksPerStepUL", dict.get("numberOfCalBlocksPerStepUL", 0))
        setattr(x, "intervalBetweenCalSteps", dict.get("intervalBetweenCalSteps", 0))
        setattr(x, "numberOfCalSteps", dict.get("numberOfCalSteps", 0))
        return x

    def AntCalCapabilitiesRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalCapabilitiesRsp()
        if not dict: return x
        getattr(x, "antCalCapabilitiesData").CopyFrom(self.AntCalCapabilitiesData_fromDict(dict.get("antCalCapabilitiesData")))
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        return x

    def AntCalStartInfo_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalStartInfo()
        if not dict: return x
        setattr(x, "symbolBitmaskDL", dict.get("symbolBitmaskDL", ""))
        setattr(x, "symbolBitmaskUL", dict.get("symbolBitmaskUL", ""))
        setattr(x, "slotBitmaskDL", dict.get("slotBitmaskDL", ""))
        setattr(x, "slotBitmaskUL", dict.get("slotBitmaskUL", ""))
        setattr(x, "frameBitmaskDL", dict.get("frameBitmaskDL", ""))
        setattr(x, "frameBitmaskUL", dict.get("frameBitmaskUL", ""))
        setattr(x, "calibrationStepSize", dict.get("calibrationStepSize", 0))
        setattr(x, "calibrationStepNumber", dict.get("calibrationStepNumber", 0))
        setattr(x, "startSFN", dict.get("startSFN", 0))
        return x

    def AntCalStartReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalStartReq()
        if not dict: return x
        getattr(x, "antCalStartInfo").CopyFrom(self.AntCalStartInfo_fromDict(dict.get("antCalStartInfo")))
        return x

    def AntCalStartRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalStartRsp()
        if not dict: return x
        setattr(x, "status", dict.get("status", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def AntCalValidateReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalValidateReq()
        if not dict: return x
        setattr(x, "selfCalAllowed", dict.get("selfCalAllowed", 0))
        return x

    def AntCalValidateRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalValidateRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def AntCalApplyReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalApplyReq()
        if not dict: return x
        setattr(x, "selfCalAllowed", dict.get("selfCalAllowed", 0))
        return x

    def AntCalApplyRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.AntCalApplyRsp()
        if not dict: return x
        setattr(x, "ok", dict.get("ok", 0))
        setattr(x, "errorMsg", dict.get("errorMsg", ""))
        return x

    def BeamformingConfigReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingConfigReq()
        if not dict: return x
        return x

    def BeamformingParameters_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingParameters()
        if not dict: return x
        setattr(x, "maxNumberOfBeamIds", dict.get("maxNumberOfBeamIds", 0))
        setattr(x, "initialBeamId", dict.get("initialBeamId", 0))
        return x

    def BeamformingType_FrequencyDomainBeams_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingType_FrequencyDomainBeams()
        if not dict: return x
        getattr(x, "beamformingParameters").CopyFrom(self.BeamformingParameters_fromDict(dict.get("beamformingParameters")))
        getattr(x, "compressionMethod").CopyFrom(self.CompMethodSupported_fromDict(dict.get("compressionMethod")))
        for v in dict.get("additionalCompressionMethodSupported", []):
            getattr(x, "additionalCompressionMethodSupported").append(self.CompMethodSupported_fromDict(v))
        return x

    def BeamformingType_TimeDomainBeams_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingType_TimeDomainBeams()
        if not dict: return x
        getattr(x, "beamformingParameters").CopyFrom(self.BeamformingParameters_fromDict(dict.get("beamformingParameters")))
        setattr(x, "frequencyGranularity", dict.get("frequencyGranularity", 0))
        setattr(x, "timeGranularity", dict.get("timeGranularity", 0))
        getattr(x, "compressionMethod").CopyFrom(self.CompMethodSupported_fromDict(dict.get("compressionMethod")))
        for v in dict.get("additionalCompressionMethodSupported", []):
            getattr(x, "additionalCompressionMethodSupported").append(self.CompMethodSupported_fromDict(v))
        return x

    def BeamformingType_HybridBeams_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingType_HybridBeams()
        if not dict: return x
        getattr(x, "beamformingParameters").CopyFrom(self.BeamformingParameters_fromDict(dict.get("beamformingParameters")))
        setattr(x, "frequencyGranularity", dict.get("frequencyGranularity", 0))
        setattr(x, "timeGranularity", dict.get("timeGranularity", 0))
        getattr(x, "compressionMethod").CopyFrom(self.CompMethodSupported_fromDict(dict.get("compressionMethod")))
        for v in dict.get("additionalcompressionmethodsupported", []):
            getattr(x, "additionalcompressionmethodsupported").append(self.CompMethodSupported_fromDict(v))
        return x

    def BeamformingType_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingType()
        if not dict: return x
        setattr(x, "frequency", dict.get("frequency", 0))
        setattr(x, "time", dict.get("time", 0))
        setattr(x, "hybrid", dict.get("hybrid", 0))
        return x

    def BeamformingProperties_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingProperties()
        if not dict: return x
        setattr(x, "beamId", dict.get("beamId", 0))
        setattr(x, "beamType", dict.get("beamType", 0))
        setattr(x, "beamGroupId", dict.get("beamGroupId", 0))
        for v in dict.get("coarseFineBeamCapabilityBasedRelation", []):
            getattr(x, "coarseFineBeamCapabilityBasedRelation").append(v)
        for v in dict.get("neighbourBeamsCapabilityBased", []):
            getattr(x, "neighbourBeamsCapabilityBased").append(v)
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        return x

    def BeamInformation_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamInformation()
        if not dict: return x
        setattr(x, "numberOfBeamformingProperties", dict.get("numberOfBeamformingProperties", 0))
        for v in dict.get("beamformingProperties", []):
            getattr(x, "beamformingProperties").append(self.BeamformingProperties_fromDict(v))
        return x

    def BeamformingCapabilitiesGroup_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingCapabilitiesGroup()
        if not dict: return x
        setattr(x, "capabilitiesGroup", dict.get("capabilitiesGroup", 0))
        setattr(x, "bandNumber", dict.get("bandNumber", 0))
        setattr(x, "txArray", dict.get("txArray", ""))
        setattr(x, "rxArray", dict.get("rxArray", ""))
        setattr(x, "rtBfWeightsUpdateSupport", dict.get("rtBfWeightsUpdateSupport", 0))
        getattr(x, "beamformingType").CopyFrom(self.BeamformingType_fromDict(dict.get("beamformingType")))
        setattr(x, "numberOfBeams", dict.get("numberOfBeams", 0))
        getattr(x, "beamInformation").CopyFrom(self.BeamInformation_fromDict(dict.get("beamInformation")))
        setattr(x, "validIndicator", dict.get("validIndicator", 0))
        return x

    def BeamformingConfigRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.BeamformingConfigRsp()
        if not dict: return x
        for v in dict.get("capabilitiesGroups", []):
            getattr(x, "capabilitiesGroups").append(self.BeamformingCapabilitiesGroup_fromDict(v))
        return x

    def RxWindowData_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxWindowData()
        if not dict: return x
        setattr(x, "eaxcId", dict.get("eaxcId", 0))
        setattr(x, "count", dict.get("count", 0))
        return x

    def RxWindowStatsReq_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxWindowStatsReq()
        if not dict: return x
        setattr(x, "measObj", dict.get("measObj", 0))
        return x

    def RxWindowStatsRsp_fromDict(self, dict):
        x = cuplanectrl_service_pb2.RxWindowStatsRsp()
        if not dict: return x
        for v in dict.get("rxWindowData", []):
            getattr(x, "rxWindowData").append(self.RxWindowData_fromDict(v))
        return x

    def CUPlaneCtrlIn_fromDict(self, dict):
        x = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        if not dict: return x
        getattr(x, "getRadioConfReq").CopyFrom(self.GetRadioConfReq_fromDict(dict.get("getRadioConfReq")))
        getattr(x, "registerEventListenerInd").CopyFrom(self.RegisterEventListenerInd_fromDict(dict.get("registerEventListenerInd")))
        getattr(x, "txRxPathPrepareAndValidateReq").CopyFrom(self.TxRxPathPrepareAndValidateReq_fromDict(dict.get("txRxPathPrepareAndValidateReq")))
        getattr(x, "txRxPathConfigReq").CopyFrom(self.TxRxPathConfigReq_fromDict(dict.get("txRxPathConfigReq")))
        getattr(x, "txRxPathStateChangeReq").CopyFrom(self.TxRxPathStateChangeReq_fromDict(dict.get("txRxPathStateChangeReq")))
        getattr(x, "antCalCapabilitiesReq").CopyFrom(self.AntCalCapabilitiesReq_fromDict(dict.get("antCalCapabilitiesReq")))
        getattr(x, "antCalStartReq").CopyFrom(self.AntCalStartReq_fromDict(dict.get("antCalStartReq")))
        getattr(x, "antCalValidateReq").CopyFrom(self.AntCalValidateReq_fromDict(dict.get("antCalValidateReq")))
        getattr(x, "antCalApplyReq").CopyFrom(self.AntCalApplyReq_fromDict(dict.get("antCalApplyReq")))
        getattr(x, "beamformingConfigReq").CopyFrom(self.BeamformingConfigReq_fromDict(dict.get("beamformingConfigReq")))
        getattr(x, "rxWindowStatsReq").CopyFrom(self.RxWindowStatsReq_fromDict(dict.get("rxWindowStatsReq")))
        return x

    def CUPlaneCtrlOut_fromDict(self, dict):
        x = cuplanectrl_service_pb2.CUPlaneCtrlOut()
        if not dict: return x
        setattr(x, "errorInd", dict.get("errorInd", 0))
        getattr(x, "getRadioConfRsp").CopyFrom(self.GetRadioConfRsp_fromDict(dict.get("getRadioConfRsp")))
        getattr(x, "txRxPathPrepareAndValidateRsp").CopyFrom(self.TxRxPathPrepareAndValidateRsp_fromDict(dict.get("txRxPathPrepareAndValidateRsp")))
        getattr(x, "txRxPathConfigRsp").CopyFrom(self.TxRxPathConfigRsp_fromDict(dict.get("txRxPathConfigRsp")))
        getattr(x, "txRxPathStateChangeRsp").CopyFrom(self.TxRxPathStateChangeRsp_fromDict(dict.get("txRxPathStateChangeRsp")))
        getattr(x, "antCalCapabilitiesRsp").CopyFrom(self.AntCalCapabilitiesRsp_fromDict(dict.get("antCalCapabilitiesRsp")))
        getattr(x, "antCalStartRsp").CopyFrom(self.AntCalStartRsp_fromDict(dict.get("antCalStartRsp")))
        getattr(x, "antCalValidateRsp").CopyFrom(self.AntCalValidateRsp_fromDict(dict.get("antCalValidateRsp")))
        getattr(x, "antCalApplyRsp").CopyFrom(self.AntCalApplyRsp_fromDict(dict.get("antCalApplyRsp")))
        getattr(x, "beamformingConfigRsp").CopyFrom(self.BeamformingConfigRsp_fromDict(dict.get("beamformingConfigRsp")))
        getattr(x, "rxWindowStatsRsp").CopyFrom(self.RxWindowStatsRsp_fromDict(dict.get("rxWindowStatsRsp")))
        return x

    def EndpointTypes_SupportedSectionTypes_toDict(self, v):
        dict = {}
        dict["sectionType"] = getattr(v, "sectionType")
        dict["supportedSectionExtensions"] = getattr(v, "supportedSectionExtensions")[:]
        return dict

    def EndpointTypes_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["id"] = getattr(v, "id")
        dict["supportedSectionTypes"] = getattr(v, "supportedSectionTypes")[:]
        dict["supportedFrameStructures"] = getattr(v, "supportedFrameStructures")[:]
        dict["managedDelaySupport"] = getattr(v, "managedDelaySupport")
        dict["multipleNumerologySupported"] = getattr(v, "multipleNumerologySupported")
        dict["maxNumerologyChangeDuration"] = getattr(v, "maxNumerologyChangeDuration")
        dict["maxControlSectionsPerDataSection"] = getattr(v, "maxControlSectionsPerDataSection")
        dict["maxSectionsPerSymbol"] = getattr(v, "maxSectionsPerSymbol")
        dict["maxSectionsPerSlot"] = getattr(v, "maxSectionsPerSlot")
        dict["maxBeamsPerSymbol"] = getattr(v, "maxBeamsPerSymbol")
        dict["maxBeamsPerSlot"] = getattr(v, "maxBeamsPerSlot")
        dict["maxPrbPerSymbol"] = getattr(v, "maxPrbPerSymbol")
        dict["prbCapacityAllocationGranularity"] = getattr(v, "prbCapacityAllocationGranularity")[:]
        dict["maxNumerologiesPerSymbol"] = getattr(v, "maxNumerologiesPerSymbol")
        return dict

    def StaticLowLevelTxEndpoints_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["name"] = getattr(v, "name")
        dict["restrictedInterfaces"] = getattr(v, "restrictedInterfaces")
        dict["array"] = getattr(v, "array")
        dict["endpointType"] = getattr(v, "endpointType")
        return dict

    def StaticLowLevelRxEndpoints_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["name"] = getattr(v, "name")
        dict["restrictedInterfaces"] = getattr(v, "restrictedInterfaces")
        dict["array"] = getattr(v, "array")
        dict["endpointType"] = getattr(v, "endpointType")
        return dict

    def Polarisations_toDict(self, v):
        dict = {}
        dict["polarisationIndex"] = getattr(v, "polarisationIndex")
        dict["polarisationType"] = getattr(v, "polarisationType")
        return dict

    def TxArrays_DlCapabilities_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["maxSupportedFrequencyDl"] = getattr(v, "maxSupportedFrequencyDl")
        dict["minSupportedFrequencyDl"] = getattr(v, "minSupportedFrequencyDl")
        dict["maxSupportedBandwidthDl"] = getattr(v, "maxSupportedBandwidthDl")
        dict["maxNumCarriersDl"] = getattr(v, "maxNumCarriersDl")
        dict["maxCarrierBandwidthDl"] = getattr(v, "maxCarrierBandwidthDl")
        dict["minCarrierBandwidthDl"] = getattr(v, "minCarrierBandwidthDl")
        return dict

    def TxArrays_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["name"] = getattr(v, "name")
        dict["numberOfRows"] = getattr(v, "numberOfRows")
        dict["numberOfColumns"] = getattr(v, "numberOfColumns")
        dict["numberOfArrayLayers"] = getattr(v, "numberOfArrayLayers")
        dict["horizontalSpacing"] = getattr(v, "horizontalSpacing")
        dict["verticalSpacing"] = getattr(v, "verticalSpacing")
        dict["normalVectorAzimuthAngle"] = getattr(v, "normalVectorAzimuthAngle")
        dict["normalVectorZenithAngle"] = getattr(v, "normalVectorZenithAngle")
        dict["leftmostBottomArrayElementPositionX"] = getattr(v, "leftmostBottomArrayElementPositionX")
        dict["leftmostBottomArrayElementPositionY"] = getattr(v, "leftmostBottomArrayElementPositionY")
        dict["leftmostBottomArrayElementPositionZ"] = getattr(v, "leftmostBottomArrayElementPositionZ")
        dict["polarisations"] = []
        for x in getattr(v, "polarisations"):
            dict["polarisations"].append(self.Polarisations_toDict(x))
        dict["bandNumber"] = getattr(v, "bandNumber")
        dict["maxGain"] = getattr(v, "maxGain")
        dict["independentPowerBudget"] = getattr(v, "independentPowerBudget")
        dict["dlCapabilities"] = getattr(v, "dlCapabilities")[:]
        return dict

    def RxArrays_UlCapabilities_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["maxSupportedFrequencyUl"] = getattr(v, "maxSupportedFrequencyUl")
        dict["minSupportedFrequencyUl"] = getattr(v, "minSupportedFrequencyUl")
        dict["maxSupportedBandwidthUl"] = getattr(v, "maxSupportedBandwidthUl")
        dict["maxNumCarriersUl"] = getattr(v, "maxNumCarriersUl")
        dict["maxCarrierBandwidthUl"] = getattr(v, "maxCarrierBandwidthUl")
        dict["minCarrierBandwidthUl"] = getattr(v, "minCarrierBandwidthUl")
        return dict

    def RxArrays_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["name"] = getattr(v, "name")
        dict["numberOfRows"] = getattr(v, "numberOfRows")
        dict["numberOfColumns"] = getattr(v, "numberOfColumns")
        dict["numberOfArrayLayers"] = getattr(v, "numberOfArrayLayers")
        dict["horizontalSpacing"] = getattr(v, "horizontalSpacing")
        dict["verticalSpacing"] = getattr(v, "verticalSpacing")
        dict["normalVectorAzimuthAngle"] = getattr(v, "normalVectorAzimuthAngle")
        dict["normalVectorZenithAngle"] = getattr(v, "normalVectorZenithAngle")
        dict["leftmostBottomArrayElementPositionX"] = getattr(v, "leftmostBottomArrayElementPositionX")
        dict["leftmostBottomArrayElementPositionY"] = getattr(v, "leftmostBottomArrayElementPositionY")
        dict["leftmostBottomArrayElementPositionZ"] = getattr(v, "leftmostBottomArrayElementPositionZ")
        dict["polarisations"] = []
        for x in getattr(v, "polarisations"):
            dict["polarisations"].append(self.Polarisations_toDict(x))
        dict["bandNumber"] = getattr(v, "bandNumber")
        dict["maxGainCorrectionRange"] = getattr(v, "maxGainCorrectionRange")
        dict["minGainCorrectionRange"] = getattr(v, "minGainCorrectionRange")
        dict["ulCapabilities"] = getattr(v, "ulCapabilities")[:]
        return dict

    def TxRxRelations_RelationTypes_PairsOfTxRxArrayElements_toDict(self, v):
        dict = {}
        dict["txArrayElement"] = getattr(v, "txArrayElement")
        dict["rxArrayElement"] = getattr(v, "rxArrayElement")
        return dict

    def TxRxRelations_RelationTypes_toDict(self, v):
        dict = {}
        dict["relationType"] = getattr(v, "relationType")
        dict["pairsOfTxRxArrayElements"] = getattr(v, "pairsOfTxRxArrayElements")[:]
        dict["validIndicator"] = getattr(v, "validIndicator")
        return dict

    def TxRxRelations_toDict(self, v):
        dict = {}
        dict["entity"] = getattr(v, "entity")
        dict["txArrayName"] = getattr(v, "txArrayName")
        dict["rxArrayName"] = getattr(v, "rxArrayName")
        dict["relationTypes"] = getattr(v, "relationTypes")[:]
        return dict

    def BandCapabilities_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["bandNumber"] = getattr(v, "bandNumber")
        dict["maxSupportedFrequencyDl"] = getattr(v, "maxSupportedFrequencyDl")
        dict["minSupportedFrequencyDl"] = getattr(v, "minSupportedFrequencyDl")
        dict["maxSupportedBandwidthDl"] = getattr(v, "maxSupportedBandwidthDl")
        dict["maxNumCarriersDl"] = getattr(v, "maxNumCarriersDl")
        dict["maxCarrierBandwidthDl"] = getattr(v, "maxCarrierBandwidthDl")
        dict["minCarrierBandwidthDl"] = getattr(v, "minCarrierBandwidthDl")
        dict["maxSupportedFrequencyUl"] = getattr(v, "maxSupportedFrequencyUl")
        dict["minSupportedFrequencyUl"] = getattr(v, "minSupportedFrequencyUl")
        dict["maxSupportedBandwidthUl"] = getattr(v, "maxSupportedBandwidthUl")
        dict["maxNumCarriersUl"] = getattr(v, "maxNumCarriersUl")
        dict["maxCarrierBandwidthUl"] = getattr(v, "maxCarrierBandwidthUl")
        dict["minCarrierBandwidthUl"] = getattr(v, "minCarrierBandwidthUl")
        dict["maxNumComponentCarriers"] = getattr(v, "maxNumComponentCarriers")
        dict["maxNumBands"] = getattr(v, "maxNumBands")
        dict["maxNumSectors"] = getattr(v, "maxNumSectors")
        dict["maxPowerPerAntenna"] = getattr(v, "maxPowerPerAntenna")
        dict["minPowerPerAntenna"] = getattr(v, "minPowerPerAntenna")
        dict["codebookConfigurationNg"] = getattr(v, "codebookConfigurationNg")
        dict["codebookConfigurationN1"] = getattr(v, "codebookConfigurationN1")
        dict["codebookConfigurationN2"] = getattr(v, "codebookConfigurationN2")
        dict["minArfcnUl"] = getattr(v, "minArfcnUl")
        dict["maxArfcnUl"] = getattr(v, "maxArfcnUl")
        dict["minArfcnDl"] = getattr(v, "minArfcnDl")
        dict["maxArfcnDl"] = getattr(v, "maxArfcnDl")
        dict["carrierType"] = getattr(v, "carrierType")
        dict["duplexScheme"] = getattr(v, "duplexScheme")
        return dict

    def CompFormat_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["exponent"] = getattr(v, "exponent")
        dict["blockScalar"] = getattr(v, "blockScalar")
        dict["compBitWidth"] = getattr(v, "compBitWidth")
        dict["compShift"] = getattr(v, "compShift")
        dict["activeBeamSpaceCoeficientMask"] = getattr(v, "activeBeamSpaceCoeficientMask")[:]
        dict["blockScaler"] = getattr(v, "blockScaler")
        dict["csf"] = getattr(v, "csf")
        dict["modCompScaler"] = getattr(v, "modCompScaler")
        return dict

    def CompMethodSupported_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["iqBitwidth"] = getattr(v, "iqBitwidth")
        dict["compressionType"] = getattr(v, "compressionType")
        dict["compressionFormat"] = self.CompFormat_toDict(getattr(v, "compressionFormat"))
        return dict

    def FormatOfIqSample_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["dynamicCompressionSupported"] = getattr(v, "dynamicCompressionSupported")
        dict["realtimeVariableBitWidthSupported"] = getattr(v, "realtimeVariableBitWidthSupported")
        dict["compressionMethodSupported"] = []
        for x in getattr(v, "compressionMethodSupported"):
            dict["compressionMethodSupported"].append(self.CompMethodSupported_toDict(x))
        dict["variableBitwidthPerChannelSupported"] = getattr(v, "variableBitwidthPerChannelSupported")
        dict["symincSupported"] = getattr(v, "symincSupported")
        return dict

    def RuCapabilities_UlMixedNumReqGuardRbs_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["scsA"] = getattr(v, "scsA")
        dict["scsB"] = getattr(v, "scsB")
        dict["numberOfGuardRbsUl"] = getattr(v, "numberOfGuardRbsUl")
        return dict

    def RuCapabilities_DlMixedNumReqGuardRbs_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["scsA"] = getattr(v, "scsA")
        dict["scsB"] = getattr(v, "scsB")
        dict["numberOfGuardRbsDl"] = getattr(v, "numberOfGuardRbsDl")
        return dict

    def RuCapabilities_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["ruSupportedCategory"] = getattr(v, "ruSupportedCategory")
        dict["numberOfRuPorts"] = getattr(v, "numberOfRuPorts")
        dict["numberOfSpatialStreams"] = getattr(v, "numberOfSpatialStreams")
        dict["maxPowerPerPaAntenna"] = getattr(v, "maxPowerPerPaAntenna")
        dict["minPowerPerPaAntenna"] = getattr(v, "minPowerPerPaAntenna")
        dict["fronthaulSplitOption"] = getattr(v, "fronthaulSplitOption")
        dict["formatOfIqSample"] = self.FormatOfIqSample_toDict(getattr(v, "formatOfIqSample"))
        dict["ulMixedNumRequiredGuardRbs"] = getattr(v, "ulMixedNumRequiredGuardRbs")[:]
        dict["dlMixedNumRequiredGuardRbs"] = getattr(v, "dlMixedNumRequiredGuardRbs")[:]
        dict["energySavingByTransmissionBlanks"] = getattr(v, "energySavingByTransmissionBlanks")
        dict["dynamicTransportDelayManagementSupported"] = getattr(v, "dynamicTransportDelayManagementSupported")
        return dict

    def GetRadioConfReq_toDict(self, v):
        dict = {}
        return dict

    def RadioConfData_toDict(self, v):
        dict = {}
        dict["mPlaneVersion"] = getattr(v, "mPlaneVersion")
        dict["endpointTypes"] = []
        for x in getattr(v, "endpointTypes"):
            dict["endpointTypes"].append(self.EndpointTypes_toDict(x))
        dict["staticLowLevelTxEndpoints"] = []
        for x in getattr(v, "staticLowLevelTxEndpoints"):
            dict["staticLowLevelTxEndpoints"].append(self.StaticLowLevelTxEndpoints_toDict(x))
        dict["staticLowLevelRxEndpoints"] = []
        for x in getattr(v, "staticLowLevelRxEndpoints"):
            dict["staticLowLevelRxEndpoints"].append(self.StaticLowLevelRxEndpoints_toDict(x))
        dict["txArrays"] = []
        for x in getattr(v, "txArrays"):
            dict["txArrays"].append(self.TxArrays_toDict(x))
        dict["rxArrays"] = []
        for x in getattr(v, "rxArrays"):
            dict["rxArrays"].append(self.RxArrays_toDict(x))
        dict["txRxRelations"] = []
        for x in getattr(v, "txRxRelations"):
            dict["txRxRelations"].append(self.TxRxRelations_toDict(x))
        dict["bandCapabilities"] = []
        for x in getattr(v, "bandCapabilities"):
            dict["bandCapabilities"].append(self.BandCapabilities_toDict(x))
        dict["ruCapabilities"] = self.RuCapabilities_toDict(getattr(v, "ruCapabilities"))
        return dict

    def GetRadioConfRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["radioConfData"] = self.RadioConfData_toDict(getattr(v, "radioConfData"))
        return dict

    def NumberOfPrbsPerScs_toDict(self, v):
        dict = {}
        dict["scs"] = getattr(v, "scs")
        dict["numberOfPrb"] = getattr(v, "numberOfPrb")
        return dict

    def EaxcId_toDict(self, v):
        dict = {}
        dict["oDuPortBitmask"] = getattr(v, "oDuPortBitmask")
        dict["bandSectorBitmask"] = getattr(v, "bandSectorBitmask")
        dict["ccidBitmask"] = getattr(v, "ccidBitmask")
        dict["ruPortBitmask"] = getattr(v, "ruPortBitmask")
        dict["eaxcId"] = getattr(v, "eaxcId")
        return dict

    def LteTddFrame_toDict(self, v):
        dict = {}
        dict["subframeAssignment"] = getattr(v, "subframeAssignment")
        dict["specialSubFramePattern"] = getattr(v, "specialSubFramePattern")
        return dict

    def LaaCarrierConfiguration_MaxCwUsageCounter_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["priority"] = getattr(v, "priority")
        dict["counterValue"] = getattr(v, "counterValue")
        return dict

    def LaaCarrierConfiguration_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["edThresholdPdsch"] = getattr(v, "edThresholdPdsch")
        dict["edThresholdDrs"] = getattr(v, "edThresholdDrs")
        dict["txAntennaPorts"] = getattr(v, "txAntennaPorts")
        dict["transmissionPowerForDrs"] = getattr(v, "transmissionPowerForDrs")
        dict["dmtcPeriod"] = getattr(v, "dmtcPeriod")
        dict["dmtcOffset"] = getattr(v, "dmtcOffset")
        dict["lbtTimer"] = getattr(v, "lbtTimer")
        dict["maxCwUsageCounter"] = getattr(v, "maxCwUsageCounter")[:]
        return dict

    def ProcessingElementConf_toDict(self, v):
        dict = {}
        dict["vlanId"] = getattr(v, "vlanId")
        dict["ruMacAddress"] = getattr(v, "ruMacAddress")
        dict["duMacAddress"] = getattr(v, "duMacAddress")
        return dict

    def TxPath_LowLevelTxEndpointConf_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["compressionMethodSupported"] = self.CompMethodSupported_toDict(getattr(v, "compressionMethodSupported"))
        dict["frameStructure"] = getattr(v, "frameStructure")
        dict["cpType"] = getattr(v, "cpType")
        dict["cpLength"] = getattr(v, "cpLength")
        dict["cpLengthOther"] = getattr(v, "cpLengthOther")
        dict["offsetToAbsoluteFrequencyCenter"] = getattr(v, "offsetToAbsoluteFrequencyCenter")
        dict["numberOfPrbsPerScs"] = []
        for x in getattr(v, "numberOfPrbsPerScs"):
            dict["numberOfPrbsPerScs"].append(self.NumberOfPrbsPerScs_toDict(x))
        dict["eaxcid"] = self.EaxcId_toDict(getattr(v, "eaxcid"))
        return dict

    def TxPath_TxArrayCarrierConf_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["absoluteFrequencyCenter"] = getattr(v, "absoluteFrequencyCenter")
        dict["centerOfChannelBandwidth"] = getattr(v, "centerOfChannelBandwidth")
        dict["channelBandWidth"] = getattr(v, "channelBandWidth")
        dict["active"] = getattr(v, "active")
        dict["bandNumber"] = getattr(v, "bandNumber")
        dict["lteTddFrame"] = self.LteTddFrame_toDict(getattr(v, "lteTddFrame"))
        dict["laaCarrierConfiguration"] = self.LaaCarrierConfiguration_toDict(getattr(v, "laaCarrierConfiguration"))
        dict["gain"] = getattr(v, "gain")
        dict["downlinkRadioFrameOffset"] = getattr(v, "downlinkRadioFrameOffset")
        dict["downlinkSfnOffset"] = getattr(v, "downlinkSfnOffset")
        return dict

    def TxPath_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["staticLowLevelTxEndpointName"] = getattr(v, "staticLowLevelTxEndpointName")
        dict["lowLevelTxEndpointConf"] = getattr(v, "lowLevelTxEndpointConf")
        dict["txArrayCarrierConf"] = getattr(v, "txArrayCarrierConf")
        dict["processingElementConf"] = self.ProcessingElementConf_toDict(getattr(v, "processingElementConf"))
        return dict

    def RxPath_LowLevelRxEndpointConf_UlFftSamplingOffsets_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["scs"] = getattr(v, "scs")
        dict["ulFftSamplingOffset"] = getattr(v, "ulFftSamplingOffset")
        return dict

    def RxPath_LowLevelRxEndpointConf_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["compressionMethodSupported"] = self.CompMethodSupported_toDict(getattr(v, "compressionMethodSupported"))
        dict["frameStructure"] = getattr(v, "frameStructure")
        dict["cpType"] = getattr(v, "cpType")
        dict["cpLength"] = getattr(v, "cpLength")
        dict["cpLengthOther"] = getattr(v, "cpLengthOther")
        dict["offsetToAbsoluteFrequencyCenter"] = getattr(v, "offsetToAbsoluteFrequencyCenter")
        dict["numberOfPrbsPerScs"] = []
        for x in getattr(v, "numberOfPrbsPerScs"):
            dict["numberOfPrbsPerScs"].append(self.NumberOfPrbsPerScs_toDict(x))
        dict["ulFftSamplingOffsets"] = getattr(v, "ulFftSamplingOffsets")[:]
        dict["eaxcid"] = self.EaxcId_toDict(getattr(v, "eaxcid"))
        dict["nonTimeManagedDelayEnabled"] = getattr(v, "nonTimeManagedDelayEnabled")
        return dict

    def RxPath_RxArrayCarrierConf_toDict(self, v):
        dict = {}
        dict["absoluteFrequencyCenter"] = getattr(v, "absoluteFrequencyCenter")
        dict["centerOfChannelBandwidth"] = getattr(v, "centerOfChannelBandwidth")
        dict["channelBandwidth"] = getattr(v, "channelBandwidth")
        dict["active"] = getattr(v, "active")
        dict["downlinkRadioFrameOffset"] = getattr(v, "downlinkRadioFrameOffset")
        dict["downlinkSfnOffset"] = getattr(v, "downlinkSfnOffset")
        dict["gainCorrection"] = getattr(v, "gainCorrection")
        dict["nTaOffset"] = getattr(v, "nTaOffset")
        return dict

    def RxPath_toDict(self, v):
        dict = {}
        dict["validIndicator"] = getattr(v, "validIndicator")
        dict["staticLowLevelRxEndpointName"] = getattr(v, "staticLowLevelRxEndpointName")
        dict["lowLevelRxEndpointConf"] = getattr(v, "lowLevelRxEndpointConf")
        dict["rxArrayCarrierConf"] = getattr(v, "rxArrayCarrierConf")
        dict["processingElementConf"] = self.ProcessingElementConf_toDict(getattr(v, "processingElementConf"))
        return dict

    def TxRxPathStateChangeReq_toDict(self, v):
        dict = {}
        dict["state"] = getattr(v, "state")
        dict["staticLowLevelTxEndpointNames"] = getattr(v, "staticLowLevelTxEndpointNames")
        dict["staticLowLevelRxEndpointNames"] = getattr(v, "staticLowLevelRxEndpointNames")
        return dict

    def TxRxPathStateChangeRsp_toDict(self, v):
        dict = {}
        dict["status"] = getattr(v, "status")
        return dict

    def TxRxPathConfigReq_toDict(self, v):
        dict = {}
        dict["staticLowLevelTxEndpointNames"] = getattr(v, "staticLowLevelTxEndpointNames")
        dict["staticLowLevelRxEndpointNames"] = getattr(v, "staticLowLevelRxEndpointNames")
        return dict

    def TxRxPathConfigRsp_toDict(self, v):
        dict = {}
        dict["errorOccurredDuringConfiguration"] = getattr(v, "errorOccurredDuringConfiguration")
        return dict

    def TxRxPathPrepareAndValidateReq_toDict(self, v):
        dict = {}
        dict["txPath"] = []
        for x in getattr(v, "txPath"):
            dict["txPath"].append(self.TxPath_toDict(x))
        dict["rxPath"] = []
        for x in getattr(v, "rxPath"):
            dict["rxPath"].append(self.RxPath_toDict(x))
        return dict

    def TxRxPathPrepareAndValidateRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def RegisterEventListenerInd_toDict(self, v):
        dict = {}
        dict["clientName"] = getattr(v, "clientName")
        dict["event"] = getattr(v, "event")
        return dict

    def AntCalCapabilitiesReq_toDict(self, v):
        dict = {}
        return dict

    def AntCalCapabilitiesData_toDict(self, v):
        dict = {}
        dict["selfCalSupport"] = getattr(v, "selfCalSupport")
        dict["numberOfCalSymbolsPerBlockDL"] = getattr(v, "numberOfCalSymbolsPerBlockDL")
        dict["numberOfCalSymbolsPerBlockUL"] = getattr(v, "numberOfCalSymbolsPerBlockUL")
        dict["intervalBetweenCalBlocks"] = getattr(v, "intervalBetweenCalBlocks")
        dict["numberOfCalBlocksPerStepDL"] = getattr(v, "numberOfCalBlocksPerStepDL")
        dict["numberOfCalBlocksPerStepUL"] = getattr(v, "numberOfCalBlocksPerStepUL")
        dict["intervalBetweenCalSteps"] = getattr(v, "intervalBetweenCalSteps")
        dict["numberOfCalSteps"] = getattr(v, "numberOfCalSteps")
        return dict

    def AntCalCapabilitiesRsp_toDict(self, v):
        dict = {}
        dict["antCalCapabilitiesData"] = self.AntCalCapabilitiesData_toDict(getattr(v, "antCalCapabilitiesData"))
        dict["validIndicator"] = getattr(v, "validIndicator")
        return dict

    def AntCalStartInfo_toDict(self, v):
        dict = {}
        dict["symbolBitmaskDL"] = getattr(v, "symbolBitmaskDL")
        dict["symbolBitmaskUL"] = getattr(v, "symbolBitmaskUL")
        dict["slotBitmaskDL"] = getattr(v, "slotBitmaskDL")
        dict["slotBitmaskUL"] = getattr(v, "slotBitmaskUL")
        dict["frameBitmaskDL"] = getattr(v, "frameBitmaskDL")
        dict["frameBitmaskUL"] = getattr(v, "frameBitmaskUL")
        dict["calibrationStepSize"] = getattr(v, "calibrationStepSize")
        dict["calibrationStepNumber"] = getattr(v, "calibrationStepNumber")
        dict["startSFN"] = getattr(v, "startSFN")
        return dict

    def AntCalStartReq_toDict(self, v):
        dict = {}
        dict["antCalStartInfo"] = self.AntCalStartInfo_toDict(getattr(v, "antCalStartInfo"))
        return dict

    def AntCalStartRsp_toDict(self, v):
        dict = {}
        dict["status"] = getattr(v, "status")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def AntCalValidateReq_toDict(self, v):
        dict = {}
        dict["selfCalAllowed"] = getattr(v, "selfCalAllowed")
        return dict

    def AntCalValidateRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def AntCalApplyReq_toDict(self, v):
        dict = {}
        dict["selfCalAllowed"] = getattr(v, "selfCalAllowed")
        return dict

    def AntCalApplyRsp_toDict(self, v):
        dict = {}
        dict["ok"] = getattr(v, "ok")
        dict["errorMsg"] = getattr(v, "errorMsg")
        return dict

    def BeamformingConfigReq_toDict(self, v):
        dict = {}
        return dict

    def BeamformingParameters_toDict(self, v):
        dict = {}
        dict["maxNumberOfBeamIds"] = getattr(v, "maxNumberOfBeamIds")
        dict["initialBeamId"] = getattr(v, "initialBeamId")
        return dict

    def BeamformingType_FrequencyDomainBeams_toDict(self, v):
        dict = {}
        dict["beamformingParameters"] = self.BeamformingParameters_toDict(getattr(v, "beamformingParameters"))
        dict["compressionMethod"] = self.CompMethodSupported_toDict(getattr(v, "compressionMethod"))
        dict["additionalCompressionMethodSupported"] = []
        for x in getattr(v, "additionalCompressionMethodSupported"):
            dict["additionalCompressionMethodSupported"].append(self.CompMethodSupported_toDict(x))
        return dict

    def BeamformingType_TimeDomainBeams_toDict(self, v):
        dict = {}
        dict["beamformingParameters"] = self.BeamformingParameters_toDict(getattr(v, "beamformingParameters"))
        dict["frequencyGranularity"] = getattr(v, "frequencyGranularity")
        dict["timeGranularity"] = getattr(v, "timeGranularity")
        dict["compressionMethod"] = self.CompMethodSupported_toDict(getattr(v, "compressionMethod"))
        dict["additionalCompressionMethodSupported"] = []
        for x in getattr(v, "additionalCompressionMethodSupported"):
            dict["additionalCompressionMethodSupported"].append(self.CompMethodSupported_toDict(x))
        return dict

    def BeamformingType_HybridBeams_toDict(self, v):
        dict = {}
        dict["beamformingParameters"] = self.BeamformingParameters_toDict(getattr(v, "beamformingParameters"))
        dict["frequencyGranularity"] = getattr(v, "frequencyGranularity")
        dict["timeGranularity"] = getattr(v, "timeGranularity")
        dict["compressionMethod"] = self.CompMethodSupported_toDict(getattr(v, "compressionMethod"))
        dict["additionalcompressionmethodsupported"] = []
        for x in getattr(v, "additionalcompressionmethodsupported"):
            dict["additionalcompressionmethodsupported"].append(self.CompMethodSupported_toDict(x))
        return dict

    def BeamformingType_toDict(self, v):
        dict = {}
        dict["frequency"] = getattr(v, "frequency")
        dict["time"] = getattr(v, "time")
        dict["hybrid"] = getattr(v, "hybrid")
        return dict

    def BeamformingProperties_toDict(self, v):
        dict = {}
        dict["beamId"] = getattr(v, "beamId")
        dict["beamType"] = getattr(v, "beamType")
        dict["beamGroupId"] = getattr(v, "beamGroupId")
        dict["coarseFineBeamCapabilityBasedRelation"] = getattr(v, "coarseFineBeamCapabilityBasedRelation")[:]
        dict["neighbourBeamsCapabilityBased"] = getattr(v, "neighbourBeamsCapabilityBased")[:]
        dict["validIndicator"] = getattr(v, "validIndicator")
        return dict

    def BeamInformation_toDict(self, v):
        dict = {}
        dict["numberOfBeamformingProperties"] = getattr(v, "numberOfBeamformingProperties")
        dict["beamformingProperties"] = []
        for x in getattr(v, "beamformingProperties"):
            dict["beamformingProperties"].append(self.BeamformingProperties_toDict(x))
        return dict

    def BeamformingCapabilitiesGroup_toDict(self, v):
        dict = {}
        dict["capabilitiesGroup"] = getattr(v, "capabilitiesGroup")
        dict["bandNumber"] = getattr(v, "bandNumber")
        dict["txArray"] = getattr(v, "txArray")
        dict["rxArray"] = getattr(v, "rxArray")
        dict["rtBfWeightsUpdateSupport"] = getattr(v, "rtBfWeightsUpdateSupport")
        dict["beamformingType"] = self.BeamformingType_toDict(getattr(v, "beamformingType"))
        dict["numberOfBeams"] = getattr(v, "numberOfBeams")
        dict["beamInformation"] = self.BeamInformation_toDict(getattr(v, "beamInformation"))
        dict["validIndicator"] = getattr(v, "validIndicator")
        return dict

    def BeamformingConfigRsp_toDict(self, v):
        dict = {}
        dict["capabilitiesGroups"] = []
        for x in getattr(v, "capabilitiesGroups"):
            dict["capabilitiesGroups"].append(self.BeamformingCapabilitiesGroup_toDict(x))
        return dict

    def RxWindowData_toDict(self, v):
        dict = {}
        dict["eaxcId"] = getattr(v, "eaxcId")
        dict["count"] = getattr(v, "count")
        return dict

    def RxWindowStatsReq_toDict(self, v):
        dict = {}
        dict["measObj"] = getattr(v, "measObj")
        return dict

    def RxWindowStatsRsp_toDict(self, v):
        dict = {}
        dict["rxWindowData"] = []
        for x in getattr(v, "rxWindowData"):
            dict["rxWindowData"].append(self.RxWindowData_toDict(x))
        return dict

    def CUPlaneCtrlIn_toDict(self, v):
        dict = {}
        dict["getRadioConfReq"] = self.GetRadioConfReq_toDict(getattr(v, "getRadioConfReq"))
        dict["registerEventListenerInd"] = self.RegisterEventListenerInd_toDict(getattr(v, "registerEventListenerInd"))
        dict["txRxPathPrepareAndValidateReq"] = self.TxRxPathPrepareAndValidateReq_toDict(getattr(v, "txRxPathPrepareAndValidateReq"))
        dict["txRxPathConfigReq"] = self.TxRxPathConfigReq_toDict(getattr(v, "txRxPathConfigReq"))
        dict["txRxPathStateChangeReq"] = self.TxRxPathStateChangeReq_toDict(getattr(v, "txRxPathStateChangeReq"))
        dict["antCalCapabilitiesReq"] = self.AntCalCapabilitiesReq_toDict(getattr(v, "antCalCapabilitiesReq"))
        dict["antCalStartReq"] = self.AntCalStartReq_toDict(getattr(v, "antCalStartReq"))
        dict["antCalValidateReq"] = self.AntCalValidateReq_toDict(getattr(v, "antCalValidateReq"))
        dict["antCalApplyReq"] = self.AntCalApplyReq_toDict(getattr(v, "antCalApplyReq"))
        dict["beamformingConfigReq"] = self.BeamformingConfigReq_toDict(getattr(v, "beamformingConfigReq"))
        dict["rxWindowStatsReq"] = self.RxWindowStatsReq_toDict(getattr(v, "rxWindowStatsReq"))
        return dict

    def CUPlaneCtrlOut_toDict(self, v):
        dict = {}
        dict["errorInd"] = getattr(v, "errorInd")
        dict["getRadioConfRsp"] = self.GetRadioConfRsp_toDict(getattr(v, "getRadioConfRsp"))
        dict["txRxPathPrepareAndValidateRsp"] = self.TxRxPathPrepareAndValidateRsp_toDict(getattr(v, "txRxPathPrepareAndValidateRsp"))
        dict["txRxPathConfigRsp"] = self.TxRxPathConfigRsp_toDict(getattr(v, "txRxPathConfigRsp"))
        dict["txRxPathStateChangeRsp"] = self.TxRxPathStateChangeRsp_toDict(getattr(v, "txRxPathStateChangeRsp"))
        dict["antCalCapabilitiesRsp"] = self.AntCalCapabilitiesRsp_toDict(getattr(v, "antCalCapabilitiesRsp"))
        dict["antCalStartRsp"] = self.AntCalStartRsp_toDict(getattr(v, "antCalStartRsp"))
        dict["antCalValidateRsp"] = self.AntCalValidateRsp_toDict(getattr(v, "antCalValidateRsp"))
        dict["antCalApplyRsp"] = self.AntCalApplyRsp_toDict(getattr(v, "antCalApplyRsp"))
        dict["beamformingConfigRsp"] = self.BeamformingConfigRsp_toDict(getattr(v, "beamformingConfigRsp"))
        dict["rxWindowStatsRsp"] = self.RxWindowStatsRsp_toDict(getattr(v, "rxWindowStatsRsp"))
        return dict

    def GetRadioConf(self):
        _req = cuplanectrl_service_pb2.GetRadioConfReq()
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.getRadioConfReq.CopyFrom(_req)
        debug(_inMsg)

    def TxRxPathStateChange(self, state, staticLowLevelTxEndpointNames, staticLowLevelRxEndpointNames):
        _req = cuplanectrl_service_pb2.TxRxPathStateChangeReq()
        _req.state = state
        for _x in staticLowLevelTxEndpointNames:
            _req.staticLowLevelTxEndpointNames.append(_x)
        for _x in staticLowLevelRxEndpointNames:
            _req.staticLowLevelRxEndpointNames.append(_x)
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.txRxPathStateChangeReq.CopyFrom(_req)
        debug(_inMsg)

    def TxRxPathConfig(self, staticLowLevelTxEndpointNames, staticLowLevelRxEndpointNames):
        _req = cuplanectrl_service_pb2.TxRxPathConfigReq()
        for _x in staticLowLevelTxEndpointNames:
            _req.staticLowLevelTxEndpointNames.append(_x)
        for _x in staticLowLevelRxEndpointNames:
            _req.staticLowLevelRxEndpointNames.append(_x)
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.txRxPathConfigReq.CopyFrom(_req)
        debug(_inMsg)

    def TxRxPathPrepareAndValidate(self, txPath, rxPath):
        _req = cuplanectrl_service_pb2.TxRxPathPrepareAndValidateReq()
        for _x in txPath:
            _req.txPath.append(self.TxPath_fromDict(_x))
        for _x in rxPath:
            _req.rxPath.append(self.RxPath_fromDict(_x))
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.txRxPathPrepareAndValidateReq.CopyFrom(_req)
        debug(_inMsg)

    def RegisterEventListener(self, clientName, event):
        _req = cuplanectrl_service_pb2.RegisterEventListenerInd()
        _req.clientName = clientName
        _req.event = event
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.registerEventListenerInd.CopyFrom(_req)
        debug(_inMsg)

    def AntCalCapabilities(self):
        _req = cuplanectrl_service_pb2.AntCalCapabilitiesReq()
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.antCalCapabilitiesReq.CopyFrom(_req)
        debug(_inMsg)

    def AntCalStart(self, antCalStartInfo):
        _req = cuplanectrl_service_pb2.AntCalStartReq()
        _req.antCalStartInfo.CopyFrom(self.AntCalStartInfo_fromDict(antCalStartInfo))
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.antCalStartReq.CopyFrom(_req)
        debug(_inMsg)

    def AntCalValidate(self, selfCalAllowed):
        _req = cuplanectrl_service_pb2.AntCalValidateReq()
        _req.selfCalAllowed = selfCalAllowed
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.antCalValidateReq.CopyFrom(_req)
        debug(_inMsg)

    def AntCalApply(self, selfCalAllowed):
        _req = cuplanectrl_service_pb2.AntCalApplyReq()
        _req.selfCalAllowed = selfCalAllowed
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.antCalApplyReq.CopyFrom(_req)
        debug(_inMsg)

    def BeamformingConfig(self):
        _req = cuplanectrl_service_pb2.BeamformingConfigReq()
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.beamformingConfigReq.CopyFrom(_req)
        debug(_inMsg)

    def RxWindowStats(self, measObj):
        _req = cuplanectrl_service_pb2.RxWindowStatsReq()
        _req.measObj = measObj
        _inMsg = cuplanectrl_service_pb2.CUPlaneCtrlIn()
        _inMsg.rxWindowStatsReq.CopyFrom(_req)
        debug(_inMsg)

